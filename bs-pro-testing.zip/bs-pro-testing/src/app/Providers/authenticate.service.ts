import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';


@Injectable()
export class AuthenticateService {

  constructor(public http: Http) { }

   public adalConfig(): any {
        return {
            tenant: '85c997b9-f494-46b3-a11d-772983cf6f11',
            clientId: '8dffe536-122e-4394-a3df-ac82293438f4',
            // redirectUri: "http://localhost:3000/",
            // postLogoutRedirectUri: window.location.origin + '/'
        };
    }

}
