import { Injectable } from '@angular/core';
import { GetClientFormDataService } from './get-client-form-data.service';
import { Http, Response, Headers,RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class DataFuncionalService {
 
  constructor(private MyserviceInj:GetClientFormDataService,private http:Http) { 
    console.log("hello reached inside functional service");
    console.log(MyserviceInj);
  }
   saveBasicProject() {
     console.log("our pushing method---------");
        const body = JSON.stringify(this.MyserviceInj.BasicFormObj);
        console.log(body);
        const headers = new Headers({'Content-type':'application/json'});
      
      this.http.post('http://localhost:8000/app/project',body, {headers:headers}).subscribe(() => console.log('success!'),error=> console.error("error"));
    }

    saveTech() {
      console.log("our pushing test method---------");
        const body = JSON.stringify(this.MyserviceInj.techFormObj);
        console.log(body);
        const headers = new Headers({'Content-type':'application/json'});
      
      this.http.post('http://localhost:8000/app/tech',body, {headers:headers}).subscribe(() => console.log('success!'),error=> console.error("error"));
    }

    saveTest() {
      console.log("our pushing tech method---------");
        const body = JSON.stringify(this.MyserviceInj.testFormObj);
        console.log(body);
        const headers = new Headers({'Content-type':'application/json'});
      
      this.http.post('http://localhost:8000/app/testing',body, {headers:headers}).subscribe(() => console.log('success!'),error=> console.error("error"));
    }

    getBasicData() {
      console.log("inside getdata");
      // console.log(this.http.get('http://localhost:8000/app/user').map((response:Response) => {response.json()}));
      return this.http.get('http://localhost:8000/app/project').map((res:Response) => res.json());
    }

}
