import { Injectable } from '@angular/core';

@Injectable()
export class GetClientFormDataService {

  constructor() { }
  BasicFormObj:any = {
    projName:String,
    propId:String,
    nexusId:String,
    igAccount:String,
    bidOwner:String,
    bidMinds:String
   }

   techFormObj:any = {
     projId:String,
     frontEnd:String,
     backEnd:String,
     dbEnd:String
   }

   testFormObj:any = {
     projId:String,
     unitTest:String,
     eteTest:String,
     perfTest:String,
     secTest:String,
     accessibility:String,
     multiCapa:String
   }

}
