import { Component, OnInit } from '@angular/core';
import { DataFuncionalService } from '../Services/data-funcional.service';

@Component({
  selector: 'app-confirm',
  templateUrl: './confirm.component.html',
  styleUrls: ['./confirm.component.css']
})
export class ConfirmComponent implements OnInit {

  constructor(private Myserv:DataFuncionalService) { 
    console.log("--------------------");
    console.log(Myserv);
     
  }

  ngOnInit() {
    // this.Myserv.getBasicData();
  }

  pushData() {
    console.log("inside pushdata");
    this.Myserv.saveBasicProject();
    this.Myserv.saveTech();
    this.Myserv.saveTest();
   
  }

}
