import { Component, OnInit } from '@angular/core';


// declare let jsPDF;

@Component({
  selector: 'app-detailed',
  templateUrl: './detailed.component.html',
  styleUrls: ['./detailed.component.css']
})
export class DetailedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
