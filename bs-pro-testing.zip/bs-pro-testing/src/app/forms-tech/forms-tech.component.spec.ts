//3 errors

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormsTechComponent } from './forms-tech.component';

describe('FormsTechComponent', () => {
//   let component: FormsTechComponent;
//   let fixture: ComponentFixture<FormsTechComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ FormsTechComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(FormsTechComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });


it('should have projId as string', () => {
    const component = new FormsTechComponent(null);
    expect(component.techObj.projId('P1234')).toBe('P1234');
  });

  it('should have frontEnd as string', () => {
    const component = new FormsTechComponent(null);
    expect(component.techObj.frontEnd('angular2')).toBe('angular2');
  });

  it('should have backEnd as string', () => {
    const component = new FormsTechComponent(null);
    expect(component.techObj.backEnd('mongoDB')).toBe('mongoDB');
  });

});
