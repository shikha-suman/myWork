import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forms-upload',
  templateUrl: './forms-upload.component.html',
  styleUrls: ['./forms-upload.component.css']
})
export class FormsUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
