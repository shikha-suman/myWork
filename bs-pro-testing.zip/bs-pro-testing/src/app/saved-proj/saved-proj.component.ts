import { Component, OnInit } from '@angular/core';
import { DataFuncionalService } from '../Services/data-funcional.service';


@Component({
  selector: 'app-saved-proj',
  templateUrl: './saved-proj.component.html',
  styleUrls: ['./saved-proj.component.css']
})
export class SavedProjComponent implements OnInit {
  basicData:any = [];
  constructor(private myServ:DataFuncionalService) { }

  ngOnInit() {
    this.myServ.getBasicData().subscribe(resEmployeeData =>{ this.basicData = resEmployeeData;console.log(this.basicData)});
  }

}
