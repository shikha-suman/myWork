{
    "very simple": 2,
    "simple": 4,
    "simple medium": 8,
    "medium": 10,
    "medium complex": 14,
    "complex": 20,
    "very-complex": 28

}