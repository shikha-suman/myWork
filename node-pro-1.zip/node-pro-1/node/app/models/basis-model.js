const mongoose = require('mongoose');
const BasisSchema = mongoose.Schema({
    numUsers: String,
    numPages: String,
    numDevices: String,
    actors: String,
    accessPoint: String,
    browserSupport: String,
    deviceSupport: String,
    authMech: String,
    frontDev: String,
    backServices: String,
    db: String,
    serverOS: String,
    numUI: String,
    unitTest: String,
    endTest: String,
    securityTest: String,
    perfTest: String,
    accessibility: String,
    Multilingual: String
});


console.log("here in model");




const Basis = mongoose.model('Basis', BasisSchema);

var BasisModel = {
    getAllBasis: getAllBasis,
    addBasis: addBasis,
    updateBasis: updateBasis,
    deleteBasis: deleteBasis
}

function getAllBasis(callback) {
    Basis.find({}, function(err, resu) {
        // res.send("all the data");
        if (err) {
            callback(err, null);
        }
        console.log("hello");

        callback(null, resu);
    });
}

function addBasis(bas, callback) {

    var basis1 = new Complexity(bas);
    basis1.save(function(err, result) {
        if (err) {
            callback(err, null);

        }
        callback(null, result);

    });
}


function updateBasis(id, bas, callback) {
    Basis.update({ _id: id }, bas, null, function(err, result) {
        if (err) {
            callback(err, null);
        }
        callback(null, result);
    });
}

function deleteBasis(id, callback) {

    Basis.remove({ _id: id }, function(err, result) {
        if (err) {
            callback(err, null);
        }
        callback(null, result);

    });
}


module.exports = BasisModel;