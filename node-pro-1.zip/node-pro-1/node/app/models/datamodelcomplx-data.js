{
    "very simple": 1,
    "simple": 3,
    "simple medium": 5,
    "medium": 8,
    "medium complex": 10,
    "complex": 14,
    "very-complex": 18

}