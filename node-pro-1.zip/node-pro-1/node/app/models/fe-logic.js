{
    "very simple": 2,
    "simple": 4,
    "simple medium": 6,
    "medium": 8,
    "medium complex": 12,
    "complex": 14,
    "very-complex": 16

}