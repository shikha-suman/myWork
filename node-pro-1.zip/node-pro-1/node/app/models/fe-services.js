{
    "very simple": 4,
    "simple": 8,
    "simple medium": 12,
    "medium": 14,
    "medium complex": 16,
    "complex": 20,
    "very-complex": 24

}