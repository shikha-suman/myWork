{
    "very simple": 6,
    "simple": 10,
    "simple medium": 14,
    "medium": 18,
    "medium complex": 24,
    "complex": 30,
    "very-complex": 38

}