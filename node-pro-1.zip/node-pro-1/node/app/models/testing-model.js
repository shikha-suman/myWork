const mongoose = require('mongoose');
const TestingSchema = mongoose.Schema({
     projId:String,
     unitTest:String,
     eteTest:String,
     perfTest:String,
     secTest:String,
     accessibility:String,
     multiCapa:String
});

console.log("here in model");

// const personSchema = mongoose.Schema({
//     puppy:String,
//     tommy:String,
//     baby:String
// });


const Testing = mongoose.model('Testing',TestingSchema);

var testingModel = {
   getAllTesting:getAllTesting,
   addTesting:addTesting,
   updateTesting:updateTesting,
   deleteTesting:deleteTesting
}

function getAllTesting(callback) {
      Testing.find({},function(err, resu){   // here touching database.....
       // res.send("all the data");
          if(err) {
          callback (err,null);            // callback send data back to service
        }
        console.log("hello");
        // console.log(resu);
        callback(null,resu);
    });
}

function addTesting(user,callback) {
        
        var pp = new Testing(user);
        pp.save(function(err,result){
        if(err) {
            callback (err,null);
          //return err;
        }
         callback(null,result);
       //return result;


    });
}


function updateTesting(id,user,callback) {
        console.log("before", new Date());
        Testing.update({_id:id}, user, null, function(err,result){
        if(err) {
            callback (err,null);
          //return err;
        }
         console.log("after", new Date());
         callback(null,result);
       //return result;


    });
}

function deleteTesting(id,callback) {
    
    Testing.remove({_id:id}, function(err,result){
        if(err) {
            callback(err,null);
        }
        callback(null,result);
       
    });
}


module.exports = testingModel;

//const Person = module.exports = mongoose.model('Person',personSchema);
//  User.find({},function(err,result){
//         //res.send("update the user");
//         console.log(result);
//     });

// module.exports.getUserById = function(id, callback) {
//     User.findById(id, callback);
// }


// module.exports.getUserByName = function(username, callback) {
//     const query = {username: username}
//     User.findOne(query, callback);
// }

// module.exports.addUser = function(newUser,callback) {
//     bcrypt.getSalt(10, (err, salt)=>{
//         bcrypt.hash(newUser.password,salt,(err, salt)=>{
//             if(err) throw err;
//             newUser.password = hash;
//             newUser.save(callback);
//         });
//     });
// }