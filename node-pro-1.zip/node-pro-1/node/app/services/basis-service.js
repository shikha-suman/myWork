var BasisModel = require("../models/basis-model.js");


console.log("here in service");

var BasisService = {
    getAllBasis: getAllBasis,
    addBasis: addBasis,
    updateBasis: updateBasis,
    deleteBasis: deleteBasis
}

function addBasis(basisData, callback) {
    BasisModel.addBasis(basisData, function(err, res) {
        console.log("res in service-------", res);
        if (!err)
        // return res;
        {
            console.log("posting----------");
            callback(null, res);
        } else {
            console.log("not posting----------");
            callback(err, null);
        }
        // return err;

    });
}


function updateBasis(id, basisData, callback) {
    BasisModel.updateBasis(id, basisData, function(err, res) {
        console.log("res in service-------", res);
        if (!err)
        // return res;
        {
            console.log("posting----------");
            callback(null, res);
        } else {
            console.log("not posting----------");
            callback(err, null);
        }
        // return err;

    });
}

function deleteBasis(id, callback) {
    BasisModel.deleteBasis(id, function(err, res) {
        //console.log("res in service-------", res);
        if (!err)
        // return res;
        {
            console.log("deleting----------");
            callback(null, res);
        } else {
            console.log("not deleting----------");
            callback(err, null);
        }
    });
}



function getAllBasis(callback) {
    BasisModel.getAllBasis(function(err, resu) { // calling model get user with callback
        if (!err) {
            console.log("wow----------");
            callback(null, resu); // send data back to route
        } else {
            callback(err, null);
        }

    });
}


module.exports = BasisService;