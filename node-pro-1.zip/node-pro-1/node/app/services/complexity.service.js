var ComplexityModel = require("../models/complexity-model.js");


console.log("here in service");

var ComplexityService = {
   getAllComplexity:getAllComplexity,
   addComplexity:addComplexity,
   updateComplexity:updateComplexity,
   deleteComplexity:deleteComplexity
}
//var Person = require("../models/user-model.js");

function addComplexity(userData,callback) {
    ComplexityModel.addComplexity(userData, function (err, res) {
        console.log("res in service-------", res);
        if (!err)
           // return res;
           {
               console.log("posting----------");
               callback (null, res);
           }
            
        else {
            console.log("not posting----------");
            callback (err, null);
        }
           // return err;
        
    });
}


function updateComplexity(id,userData,callback) {
      ComplexityModel.updateComplexity(id,userData, function (err, res) {
        console.log("res in service-------", res);
        if (!err)
           // return res;
           {
               console.log("posting----------");
               callback (null, res);
           }
            
        else {
            console.log("not posting----------");
            callback (err, null);
        }
           // return err;
        
    });
}

function deleteComplexity(id,callback) {
    ComplexityModel.deleteComplexity(id,function(err, res) {
        //console.log("res in service-------", res);
        if (!err)
           // return res;
           {
               console.log("deleting----------");
               callback (null, res);
           }
            
        else {
            console.log("not deleting----------");
            callback (err, null);
        }
    });
}




// module.exports.updateUser = function(req,res) {
//     console.log("inside node")
//     console.log(req.params.id);

//     User.update({_id:req.params.id}, req.body, null, function(err,result){
//        // res.send("update the user");
//        console.log("hey update");
//        res.json(result);
//     });
// }

// module.exports.deleteUser = function(req,res) {
//     console.log("hey  delete");
//    // console.log("my --------------------------------------------",req);
    // User.remove({_id:req.params.id}, function(err,result){
    //     console.log("removed");
    //      res.json(result);
    // });
// }

function getAllComplexity(callback) {
    ComplexityModel.getAllComplexity(function (err, resu) { // calling model get user with callback
        if (!err) {
            console.log("wow----------");
            callback (null, resu);           // send data back to route
        } 
        else {
            callback (err, null);
        }
            
    });
}


module.exports = ComplexityService;

