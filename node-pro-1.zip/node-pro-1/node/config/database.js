module.exports = {
    database: 'webtechdevops.centralindia.cloudapp.azure.com:51003/yugDB'
   // database:'mongodb://yug:12345@ds019876.mlab.com:19876/yugdb'
}

