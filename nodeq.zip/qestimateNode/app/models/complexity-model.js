const mongoose = require('mongoose');
const ComplexitySchema = mongoose.Schema({
    projId:String,
    Dataentery:String,
    serviceCall:String,
    validations:String,
    entryPoints:String,
    userControls:String,
    componentReq:String,
    userAction:String,
    searchOption:String,
    filterOption:String
});


console.log("here in model");

// const personSchema = mongoose.Schema({
//     puppy:String,
//     tommy:String,
//     baby:String
// });


const Complexity = mongoose.model('Complexity',ComplexitySchema);

var ComplexityModel = {
   getAllComplexity:getAllComplexity,
   addComplexity:addComplexity,
   updateComplexity:updateComplexity,
   deleteComplexity:deleteComplexity
}

function getAllComplexity(callback) {
      Complexity.find({},function(err, resu){   // here touching database.....
       // res.send("all the data");
          if(err) {
          callback (err,null);            // callback send data back to service
        }
        console.log("hello");
        // console.log(resu);
        callback(null,resu);
    });
}

function addComplexity(user,callback) {
        
        var pp = new Complexity(user);
        pp.save(function(err,result){
        if(err) {
            callback (err,null);
          //return err;
        }
         callback(null,result);
       //return result;


    });
}


function updateComplexity(id,user,callback) {
        console.log("before", new Date());
        Complexity.update({_id:id}, user, null, function(err,result){
        if(err) {
            callback (err,null);
          //return err;
        }
         console.log("after", new Date());
         callback(null,result);
       //return result;


    });
}

function deleteComplexity(id,callback) {
    
    Complexity.remove({_id:id}, function(err,result){
        if(err) {
            callback(err,null);
        }
        callback(null,result);
       
    });
}


module.exports = ComplexityModel;

//const Person = module.exports = mongoose.model('Person',personSchema);
//  User.find({},function(err,result){
//         //res.send("update the user");
//         console.log(result);
//     });

// module.exports.getUserById = function(id, callback) {
//     User.findById(id, callback);
// }


// module.exports.getUserByName = function(username, callback) {
//     const query = {username: username}
//     User.findOne(query, callback);
// }

// module.exports.addUser = function(newUser,callback) {
//     bcrypt.getSalt(10, (err, salt)=>{
//         bcrypt.hash(newUser.password,salt,(err, salt)=>{
//             if(err) throw err;
//             newUser.password = hash;
//             newUser.save(callback);
//         });
//     });
// }