const mongoose = require('mongoose');
const projectSchema = mongoose.Schema({
    // projName:String,
    // propId:String,
    // nexusId:String,
    // igAccount:String,
    // bidOwner:String,
    // bidMinds:String,
    // phase:String
    noOfUser:String,
    noOfPages:String,
    noOfDevice:String,
    actors:String,
    accessPoint:String,
    browserSupport:String,
    deviceSupport:String,
    AuthMech:String,
    frontEnd:String,
    backEnd:String,
    dbEnd:String,
    serverOS:String,
    noOfUi:String,
    unitFrame:String,
    endFrame:String,
    security:String,
    performanceT:String,
    accessReq:String,
    multiCapa:String,
    phase:String,
    projId:String
});


console.log("here in project model");

// const personSchema = mongoose.Schema({
//     puppy:String,
//     tommy:String,
//     baby:String
// });


const Project = mongoose.model('Project',projectSchema);

var projectModel = {
   getAllProject:getAllProject,
   addProject:addProject,
   updateProject:updateProject,
   deleteProject:deleteProject
}

function getAllProject(callback) {
      Project.find({},function(err, resu){   // here touching database.....
       // res.send("all the data");
          if(err) {
          callback (err,null);            // callback send data back to service
        }
        console.log("hello");
        // console.log(resu);
        callback(null,resu);
    });
}

function addProject(user,callback) {
        
        var pp = new Project(user);
        console.log(pp);
        console.log("add project called-----------");
        pp.save(function(err,result){
        if(err) {
            callback (err,null);
          //return err;
        }
         callback(null,result);
       //return result;


    });
}


function updateProject(id,user,callback) {
        console.log("before", new Date());
        Project.update({_id:id}, user, null, function(err,result){
        if(err) {
            callback (err,null);
          //return err;
        }
         console.log("after", new Date());
         callback(null,result);
       //return result;


    });
}

function deleteProject(id,callback) {
    
    Project.remove({_id:id}, function(err,result){
        if(err) {
            callback(err,null);
        }
        callback(null,result);
       
    });
}


module.exports = projectModel;

//const Person = module.exports = mongoose.model('Person',personSchema);
//  User.find({},function(err,result){
//         //res.send("update the user");
//         console.log(result);
//     });

// module.exports.getUserById = function(id, callback) {
//     User.findById(id, callback);
// }


// module.exports.getUserByName = function(username, callback) {
//     const query = {username: username}
//     User.findOne(query, callback);
// }

// module.exports.addUser = function(newUser,callback) {
//     bcrypt.getSalt(10, (err, salt)=>{
//         bcrypt.hash(newUser.password,salt,(err, salt)=>{
//             if(err) throw err;
//             newUser.password = hash;
//             newUser.save(callback);
//         });
//     });
// }