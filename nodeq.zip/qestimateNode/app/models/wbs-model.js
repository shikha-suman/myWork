const mongoose = require('mongoose');
const WbsSchema = mongoose.Schema({
    noOfUsers:String,
    browserSupport:String,
    noOfpages:String
});

console.log("here in model");

// const personSchema = mongoose.Schema({
//     puppy:String,
//     tommy:String,
//     baby:String
// });


const Wbs = mongoose.model('Wbs',WbsSchema);

var WbsModel = {
   getAllWbs:getAllWbs,
   addWbs:addWbs,
   updateWbs:updateWbs,
   deleteWbs:deleteWbs
}

function getAllWbs(callback) {
      Wbs.find({},function(err, resu){   // here touching database.....
       // res.send("all the data");
          if(err) {
          callback (err,null);            // callback send data back to service
        }
        console.log("hello");
        // console.log(resu);
        callback(null,resu);
    });
}

function addWbs(user,callback) {
        
        var pp = new Wbs(user);
        pp.save(function(err,result){
        if(err) {
            callback (err,null);
          //return err;
        }
         callback(null,result);
       //return result;


    });
}


function updateWbs(id,user,callback) {
        console.log("before", new Date());
        Wbs.update({_id:id}, user, null, function(err,result){
        if(err) {
            callback (err,null);
          //return err;
        }
         console.log("after", new Date());
         callback(null,result);
       //return result;


    });
}

function deleteWbs(id,callback) {
    
    Wbs.remove({_id:id}, function(err,result){
        if(err) {
            callback(err,null);
        }
        callback(null,result);
       
    });
}


module.exports = WbsModel;

//const Person = module.exports = mongoose.model('Person',personSchema);
//  User.find({},function(err,result){
//         //res.send("update the user");
//         console.log(result);
//     });

// module.exports.getUserById = function(id, callback) {
//     User.findById(id, callback);
// }


// module.exports.getUserByName = function(username, callback) {
//     const query = {username: username}
//     User.findOne(query, callback);
// }

// module.exports.addUser = function(newUser,callback) {
//     bcrypt.getSalt(10, (err, salt)=>{
//         bcrypt.hash(newUser.password,salt,(err, salt)=>{
//             if(err) throw err;
//             newUser.password = hash;
//             newUser.save(callback);
//         });
//     });
// }