const testingService = require('../services/testing.service');

console.log("here in project---");

function init(router) {
  console.log("in init form");
    router.route('/testing')
        .get(getAllTesting)
        .post(addTesting);
    router.route('/testing/:id')
        .delete(deleteTesting)
        .put(updateTesting); 
}


/* GET users listing. */
// router.get('/', function(req, res, next) {
//   res.send('respond with a resource');
// });


function getAllTesting(req,res) {
  console.log("reached here");
  testingService.getAllTesting(function(err,result){   /// calling service get user 
     if(err)
      res.send(err);
    else{
      console.log("result is--------------------------",result);  // displaying data...
       res.send(result);
    }

  })
}

function addTesting(req,res) {
  var userData=req.body;
  testingService.addTesting(userData,function(err,result){
        if(err) {
          res.json(err);
        }
        // console.log("hey save");
       console.log("post result is------------------",result);
       //console.log(res);
       res.json(result);

    });
}


function updateTesting(req,res) {
   var userData=req.body;
   var id = req.params.id;
   console.log("id--------",id);
   testingService.updateTesting(id,userData,function(err,result){
        if(err) {
          res.json(err);
        }
        // console.log("hey save");
       console.log("update result is------------------",result);
       //console.log(res);
       res.json(result);

    });
}


function deleteTesting(req,res) {
  var delId = req.params.id;
  console.log(delId+"------");
   testingService.deleteTesting(delId,function(err,result){
        if(err) {
          res.json(err);
        }
        // console.log("hey save");
       console.log("delete result is------------------",result);
       //console.log(res);
       res.json(result);

    });
}


// router.post("/message",Users.createUser) {
//     //res.send("response for post");
//     console.log("router post-------");
// }
// router.put("/update/:id",Users.updateUser) {
//      console.log("router put-------");
// }
// router.delete("/delete/:id",Users.deleteUser) {
//      console.log("router delete-------");
// }
// router.get("/employee",Users.getAllUser) {
//     console.log("router get-------");
// }


module.exports.init = init;



