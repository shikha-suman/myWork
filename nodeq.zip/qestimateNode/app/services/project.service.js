var projectModel = require("../models/project-model.js");


console.log("here in project service");

var projectService = {
   getAllProject:getAllProject,
   addProject:addProject,
   updateProject:updateProject,
   deleteProject:deleteProject
}
//var Person = require("../models/user-model.js");

function addProject(userData,callback) {
    console.log("add project service");
    projectModel.addProject(userData, function (err, res) {
        console.log("res in service-------", res);
        if (!err)
           // return res;
           {
               console.log("posting----------");
               callback (null, res);
           }
            
        else {
            console.log("not posting----------");
            callback (err, null);
        }
           // return err;
        
    });
}


function updateProject(id,userData,callback) {
      projectModel.updateProject(id,userData, function (err, res) {
        console.log("res in service-------", res);
        if (!err)
           // return res;
           {
               console.log("posting----------");
               callback (null, res);
           }
            
        else {
            console.log("not posting----------");
            callback (err, null);
        }
           // return err;
        
    });
}

function deleteProject(id,callback) {
    projectModel.deleteProject(id,function(err, res) {
        //console.log("res in service-------", res);
        if (!err)
           // return res;
           {
               console.log("deleting----------");
               callback (null, res);
           }
            
        else {
            console.log("not deleting----------");
            callback (err, null);
        }
    });
}




// module.exports.updateUser = function(req,res) {
//     console.log("inside node")
//     console.log(req.params.id);

//     User.update({_id:req.params.id}, req.body, null, function(err,result){
//        // res.send("update the user");
//        console.log("hey update");
//        res.json(result);
//     });
// }

// module.exports.deleteUser = function(req,res) {
//     console.log("hey  delete");
//    // console.log("my --------------------------------------------",req);
    // User.remove({_id:req.params.id}, function(err,result){
    //     console.log("removed");
    //      res.json(result);
    // });
// }

function getAllProject(callback) {
    projectModel.getAllProject(function (err, resu) { // calling model get user with callback
        if (!err) {
            console.log("wow");
            callback (null, resu);           // send data back to route
        } 
        else {
            callback (err, null);
        }
            
    });
}


module.exports = projectService;

