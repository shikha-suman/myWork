var WbsModel = require("../models/wbs-model.js");


console.log("here in service");

var WbsService = {
   getAllWbs:getAllWbs,
   addWbs:addWbs,
   updateWbs:updateWbs,
   deleteWbs:deleteWbs
}
//var Person = require("../models/user-model.js");

function addWbs(userData,callback) {
    WbsModel.addWbs(userData, function (err, res) {
        console.log("res in service-------", res);
        if (!err)
           // return res;
           {
               console.log("posting----------");
               callback (null, res);
           }
            
        else {
            console.log("not posting----------");
            callback (err, null);
        }
           // return err;
        
    });
}


function updateWbs(id,userData,callback) {
      WbsModel.updateWbs(id,userData, function (err, res) {
        console.log("res in service-------", res);
        if (!err)
           // return res;
           {
               console.log("posting----------");
               callback (null, res);
           }
            
        else {
            console.log("not posting----------");
            callback (err, null);
        }
           // return err;
        
    });
}

function deleteWbs(id,callback) {
    WbsModel.deleteWbs(id,function(err, res) {
        //console.log("res in service-------", res);
        if (!err)
           // return res;
           {
               console.log("deleting----------");
               callback (null, res);
           }
            
        else {
            console.log("not deleting----------");
            callback (err, null);
        }
    });
}




// module.exports.updateUser = function(req,res) {
//     console.log("inside node")
//     console.log(req.params.id);

//     User.update({_id:req.params.id}, req.body, null, function(err,result){
//        // res.send("update the user");
//        console.log("hey update");
//        res.json(result);
//     });
// }

// module.exports.deleteUser = function(req,res) {
//     console.log("hey  delete");
//    // console.log("my --------------------------------------------",req);
    // User.remove({_id:req.params.id}, function(err,result){
    //     console.log("removed");
    //      res.json(result);
    // });
// }

function getAllWbs(callback) {
    WbsModel.getAllWbs(function (err, resu) { // calling model get user with callback
        if (!err) {
            console.log("wow----------");
            callback (null, resu);           // send data back to route
        } 
        else {
            callback (err, null);
        }
            
    });
}


module.exports = WbsService;

