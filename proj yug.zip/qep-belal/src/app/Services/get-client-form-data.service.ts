import { Injectable } from '@angular/core';

@Injectable()
export class GetClientFormDataService {

  constructor() { }
  BasicFormObj:any = {
    projName:String,
    propId:String,
    nexusId:String,
    igAccount:String,
    bidOwner:String,
    bidMinds:String,
    phase:String
   }

   techFormObj:any = {
     projId:String,
     frontEnd:String,
     backEnd:String,
     dbEnd:String
   }

   testFormObj:any = {
     projId:String,
     unitTest:String,
     eteTest:String,
     perfTest:String,
     secTest:String,
     accessibility:String,
     multiCapa:String
   }

   complexityObj:any = {
    projId:"12345",
    dataentry:"11",
    serviceCall:"4",
    validations:"20",
    entryPoints:"2",
    userControls:"6",
    componentReq:"6",
    userAction:"1",
    searchOption:"4",
    filterOption:"4"
   }

}
