export interface ITask {
    projName:String,
    propId:String,
    nexusId:String,
    igAccount:String,
    bidOwner:String,
    bidMinds:String
}