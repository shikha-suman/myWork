
import { Component, OnInit } from '@angular/core';
import { GetClientFormDataService } from '../Services/get-client-form-data.service';

declare let jsPDF;

@Component({
  selector: 'app-detailed',
  templateUrl: './detailed.component.html',
  styleUrls: ['./detailed.component.css']
})
export class DetailedComponent implements OnInit {

   basicData:any = [];
   testData:any = [];
   techData:any = [];
   complexityData:any = [];
  constructor(private dataFunc:GetClientFormDataService) {


     this.basicData = dataFunc.BasicFormObj;
     this.testData = dataFunc.testFormObj;
     this.techData = dataFunc.techFormObj;
     this.complexityData = dataFunc.complexityObj
   // console.log(dataFunc.BasicFormObj)

  
  
  }

   

  ngOnInit() {
    // this.dataFunc.getBasicData().subscribe(resEmployeeData =>{ this.basicData = resEmployeeData;});
    // this.dataFunc.getTestData().subscribe(resEmployeeData =>{ this.testData = resEmployeeData;});
    // this.dataFunc.getTechData().subscribe(resEmployeeData =>{ this.techData = resEmployeeData;});
    // this.dataFunc.getCompexityData().subscribe(resEmployeeData =>{ this.complexityData = resEmployeeData;});
     // var el = document.getElementById('graph');
   //  console.log("heyyyy",this.basicData);

     
  }


    onChange(deviceValue) {
       if(deviceValue == "pdf_download") {
         console.log("reached here");
            
          var doc = new jsPDF();
          var col = ["Details", "Values"];
          var rows = [];

       for(var key in this.basicData){
        var temp = [key, this.basicData[key]];
        rows.push(temp);
       }
         for(var key in this.testData){
        var temp = [key, this.testData[key]];
        rows.push(temp);
       }
         for(var key in this.techData){
        var temp = [key, this.techData[key]];
        rows.push(temp);
       }
         for(var key in this.complexityData){
        var temp = [key, this.complexityData[key]];
        rows.push(temp);
       }
        doc.autoTable(col, rows);
        doc.save('Test.pdf');
       }
      console.log(deviceValue);
    }

}
