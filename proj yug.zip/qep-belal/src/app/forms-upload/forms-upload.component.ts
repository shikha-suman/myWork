import { Component, OnInit } from '@angular/core';
declare let XLS;
@Component({
  selector: 'app-forms-upload',
  templateUrl: './forms-upload.component.html',
  styleUrls: ['./forms-upload.component.css']
})
export class FormsUploadComponent implements OnInit {
  file: File;
  parseExcel;
  constructor() { }

  ngOnInit() {
  }
  myFunc(obj) {
     var fileToLoad = obj;
 //  console.log();
  }
   
  onChange(oEvent: EventTarget) {
    //     let eventObj: MSInputMethodContext = <MSInputMethodContext> event;
    //     let ptarget: HTMLInputElement = <HTMLInputElement> eventObj.target;
    //     let files: FileList = ptarget.files;
    //     this.file = files[0];
    //     console.log(this.file);

    // this.parseExcel = function(file){
    // var reader = new FileReader();
    // reader.onload = function(){
    //     var data = event.target.result;
    //     //console.log(data);
    //     // var workbook = XLSX.read(data, {type : 'binary'});

    //     // workbook.SheetNames.forEach(function(sheetName){
    //     //     // Here is your object
    //     //     var XL_row_object = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
    //     //     var json_object = JSON.stringify(XL_row_object);
    //     //     console.log(json_object);

    //     // })

    // };


    // }





    // var oFile = oEvent.target.files[0];
    // var sFilename = oFile.name;
    // // Create A File Reader HTML5
    // var reader = new FileReader();

    // // Ready The Event For When A File Gets Selected
    // reader.onload = function(e) {
    //     var data = e.target.result;
    //     var cfb = XLS.CFB.read(data, {type: 'binary'});
    //     var wb = XLS.parse_xlscfb(cfb);
    //     // Loop Over Each Sheet
    //     wb.SheetNames.forEach(function(sheetName) {
    //         // Obtain The Current Row As CSV
    //         var sCSV = XLS.utils.make_csv(wb.Sheets[sheetName]);   
    //         var oJS = XLS.utils.sheet_to_row_object_array(wb.Sheets[sheetName]);   

    //        // $("#my_file_output").html(sCSV);
    //         console.log(oJS)
    //     });
    // };

    // // Tell JS To Start Reading The File.. You could delay this if desired
    // reader.readAsBinaryString(oFile);



  }
}
