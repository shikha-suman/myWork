import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-land-page',
  templateUrl: './land-page.component.html',
  styleUrls: ['./land-page.component.css']
})
export class LandPageComponent implements OnInit {

  constructor() { 
//  var doc = new jsPDF();
//         doc.text(20, 20, 'Hello world!');
//         doc.text(20, 30, 'This is client-side Javascript, pumping out a PDF.');
//         doc.addPage();
//         doc.text(20, 20, 'Do you like that?');

//         // Save the PDF
//         doc.save('Test.pdf');

}

  ngOnInit() {
  }

}
