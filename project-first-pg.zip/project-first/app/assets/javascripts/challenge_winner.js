(function() {
    var $;

    $ = jQuery;

    $(document).on('ready', function() {
        console.log("challenge winner");
        $("#atleast_1_winner").hide();
        $(".pagination").hide();

        // $(".winner:checked").each(function() {
        //     var val = this.value.slice(0,-1);
        //     var winner = "<p id='winner" +this.value[0] +"'>" + val + "</p>";
        //     $("#declareWinners").append(winner);
        //     val = parseInt($("#selectedCount").html()) + 1 ;
        //     $("#selectedCount").html(val);
        // });


        $("#submitWinners").click(function(){
            var user_ids = [];
            var challenge_id = window.location.pathname.split('/')[2];
            if($(".maindisplay_white").length == 0) {
                $("#atleast_1_winner").show();
            }
            else {
                $(".maindisplay_white").each(function() {
                    console.log(this.getAttribute('data-id'));
                    user_ids.push(this.getAttribute('data-id'));
                });
                console.log(user_ids);
                // user_ids[0]=1;
                // user_ids[1]=2;
                var data = {
                    user_ids: user_ids
                };
                var url = "/challenge/"+ challenge_id + "/winners";
                console.log(data);
                $.ajax({
                    type: "PUT",
                    url: url,
                    data: data,
                    success: function(data) {
                        console.log(data);
                        if(data.message == "Success") {
                            alert("Winners Declared");
                            location.reload();
                        }
                        else if(data.message == "Not Completed") {
                            alert("Challenge Not Over Yet");
                        }
                        else {
                            alert(data.message);
                        }
                    }
                });
            }
        });






// $("#control").click(function(){ 
//    // changed class name
//   $("#maindisplay").toggleClass('maindisplay_white');
// });



//  $(".buttonWinner").click(function () {
//                  // changed class name
//                  $("#maindisplay").toggleClass('maindisplay_white');
//              });


    $(document).on('click', '.buttonWinner', function() {
        console.log(this.value);
        console.log($(this).text());
        if($(this).text() == "SELECT WINNER") {
            if(parseInt($("#selectedCount").html()) >= parseInt($("#actualCount").html())) {
                    alert("Already full");
                }
            else {
                $("#atleast_1_winner").hide();
                    var val = this.value.slice(0,-1);
                    var winner = "<p id='winner" +this.value[0] +"'>" + val + "</p>";
                    $("#declareWinners").append(winner);
                    val = parseInt($("#selectedCount").html()) + 1 ;
                    $("#selectedCount").html(val);

                    $(this).text(function(i, v){
               return v === 'UNSELECT WINNER' ? 'SELECT WINNER' : 'UNSELECT WINNER'
            });
             x= "#"+this.value;
             console.log($(x));
            $(x).toggleClass('maindisplay_white');
            
            }
        }
        else if($(this).text() == "UNSELECT WINNER") {
            var winnerId = "#winner" + this.value[0];
                $(winnerId).remove();
                val = parseInt($("#selectedCount").html()) - 1 ;
                $("#selectedCount").html(val);


                $(this).text(function(i, v){
               return v === 'UNSELECT WINNER' ? 'SELECT WINNER' : 'UNSELECT WINNER'
            });
            x= "#"+this.value
             console.log($(x))
            $(x).toggleClass('maindisplay_white');
        }

        
    });
    
    });

}).call(this);