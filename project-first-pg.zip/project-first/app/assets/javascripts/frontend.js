// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, vendor/assets/javascripts,
// or any plugin's vendor/assets/javascripts directory can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file.
//
// Read Sprockets README (https://github.com/rails/sprockets#sprockets-directives) for details
// about supported directives.
//
// Make sure we include SplashScreen first so it loads first
//= require frontend/lib/splashscreen
//= require angular/angular
//= require angular/angular-animate
//= require angular/angular-resource
//= require angular/angular-sanitize
//= require angular-ui/angular-ui-router
//= require ionic/ionic
//= require ionic/ionic-angular
//= require ionicuirouter/ionicUIRouter
//= require frontend/lib/angular-polyfill
//= require_tree ./frontend