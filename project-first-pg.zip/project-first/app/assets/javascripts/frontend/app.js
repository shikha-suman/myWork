/**
 * My P&G Office - App
 */

//TODO: Add lazy loading: https://github.com/paveisistemas/ionic-image-lazy-load or http://geeklearning.io/lazy-load-your-images-in-your-ionic-app/
//TODO: Preload image before screens: http://mcgivery.com/preload-images-ionic/

var myApp = angular.module('app', ['ionic', 'ionicLazyLoad', 'ion-datetime-picker', 'chart.js', 'ionic-modal-select', 'homeRedesign', 'serviceRequest', 'app.controllers', 'pgAsk', 'pgGamification', 'sensing',
    'app.routes', 'app.directives', 'app.services', 'app.filters']);

//CONSTANTS
myApp.constant("APP_CONFIG", {
    BASE_URL: "/api/v1/",
    AUTHENTICATE: true,
    TITLE: "My P&G Office",
    VERSION: "v1.00b",
    GRACE_PERIOD_MS: 750,
    MENU_BUTTON_DEFAULTS: [  //title should match the name field in Features table
        {id: 1, title: "Retail Directory", visible: true, state: "vendors", icon: "ion-pg-icon-new ion-pg-retail-new"},
        {
            id: 2,
            title: "Building Info",
            visible: true,
            state: "buildingInfo",
            icon: "ion-pg-icon-new ion-pg-building-new"
        },
        {
            id: 3,
            title: "Vibrant Living",
            visible: true,
            state: "vibrantLiving",
            icon: "ion-pg-icon-new ion-pg-vibrant-new"
        },
        // {id: 4, title: "Deals & Events", visible: true, state: "dealsEvents", icon: "ion-pg-deals_and_events"},
        {
            id: 5,
            title: "Room Finder",
            visible: true,
            state: "roomFinder",
            icon: "ion-pg-icon-new ion-pg-room-new",
            api_value: "room_finder_url"
        },
        {
            id: 6,
            title: "Facilities Assistance",
            visible: true,
            state: "serviceRequests",
            icon: "ion-pg-icon-new ion-pg-service-new"
        },
        {id: 7, title: "P&G Dining", visible: true, state: "dining", icon: "ion-pg-icon-new ion-pg-dine-new"},
        {
            id: 8,
            title: "Parking & Transport",
            visible: true,
            state: "parkingTransport",
            icon: "ion-pg-icon-new ion-pg-parking-new"
        },
        {
            id: 9,
            title: "Concur",
            visible: true,
            state: "concur",
            class: "concur-icon",
            api_value: "concur_url"
        }, {
            id: 11,
            title: "PG Ask",
            visible: true,
            state: "pgAsk",
            icon: "ion-pg-icon-new ion-pg-ask-new"

        }, {
            id: 12,
            title: "PG Sensing",
            visible: true,
            state: "pgSensing",
            icon: "ion-pg-icon-new ion-pg-sensing-new"

        },
        {
            id: 14,
            title: "PG Challenge",
            visible: true,
            state: "GameHomePage",
            icon: "ion-pg-icon-new ion-pg-game-new"

        }

    ],
    MENU_BUTTON_DEFAULT_ORDER: [
        5, 6, 11, 14, 12, 7, 3, 2, 8, 1, 9
    ],
    VENDOR_TYPES: [
        {value: 0, name: 'business_services'},
        {value: 1, name: 'retail'},
        {value: 2, name: 'dining'}
    ],
    // Note: This list and app/models/contact.rb#8 must be key in sync.
    CONTACT_TYPES: [
        {id: 1, name: 'Concierge', type: 'concierge', icon: 'ion-pg-reception'},
        {id: 2, name: 'Emergency', type: 'emergency', icon: 'ion-pg-emergency-v2'},
        {id: 3, name: 'Facility Management', type: 'facility_management', icon: 'ion-pg-facility_mgmt'},
        {id: 4, name: 'Health Services', type: 'health_services', icon: 'ion-pg-health_services-bold'},
        {id: 5, name: 'Reception', type: 'reception', icon: 'ion-pg-reception'},
        {id: 6, name: 'Security', type: 'security', icon: 'ion-pg-security-bold'},
        {id: 7, name: 'Site Address', type: 'site_address', icon: 'ion-pg-site_address-V2'},
        {id: 8, name: 'Mailroom', type: 'mailroom', icon: 'ion-pg-mailroom'},
        {id: 9, name: 'Employee Care Kiosk', type: 'employee_care_kiosk', icon: 'ion-pg-employee_care_kiosk'},
        {id: 10, name: 'Café', type: 'cafe', icon: 'ion-pg-cafe'}
    ],
    // Note: This list and app/models/amenity.rb#4 must be key in sync.
    AMENITY_TYPES: [
        {id: 1, name: 'ATMs', type: 'atms', icon: 'ion-pg-atm-v2'},
        // REMOVED: {id: 2, name: 'Employee Extras', type: 'employee_extras', icon: 'ion-pg-employee_extras'},
        {id: 3, name: 'Employee Wellness', type: 'employee_wellness', icon: 'ion-pg-employee_wellness'},
        {id: 4, name: 'Meeting Spaces', type: 'meeting_spaces', icon: 'ion-pg-meeting_spaces'},
        {id: 5, name: 'Privacy Rooms', type: 'privacy_rooms', icon: 'ion-pg-privacy_rooms'},
        {id: 6, name: 'Emergency', type: 'emergency', icon: 'ion-pg-emergency-v2'},
        {id: 7, name: 'Pantry', type: 'pantry', icon: 'ion-pg-pantry'},
        {
            id: 8,
            name: 'Lockers and Utility Rooms',
            type: 'lockers_and_utility_rooms',
            icon: 'ion-pg-lockers_and_utility_rooms'
        }
    ],
    SHOW_PENDING_SURVEY: true
});


myApp.constant('$ionicLoadingConfig', {
    template: '<ion-spinner icon="ios"></ion-spinner>'
});

//CONFIG (runs 1st)
myApp.config(['$httpProvider', '$ionicConfigProvider', '$logProvider', '$sceProvider', '$locationProvider', 'SESSION', function ($httpProvider, $ionicConfigProvider, $logProvider, $sceProvider, $locationProvider, SESSION) {

    var msie = document.documentMode;
    if (msie) {
        if (!$httpProvider.defaults.headers.get) {
            $httpProvider.defaults.headers.get = {};
        }
        $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
        $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
        $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
    }

    //Remove swipe for back globally (causes issues)
    $ionicConfigProvider.views.swipeBackEnabled(false);

    $ionicConfigProvider.views.maxCache(8);//0 will effectively disable any caching of views

    // Loose back button text and icon globally
    $ionicConfigProvider.backButton.previousTitleText(false).text('');

    //Align nav title in center on both platforms
    $ionicConfigProvider.navBar.alignTitle('center');

    //Make toggle & checkboxes switches the same on both platforms
    $ionicConfigProvider.form.toggle('large');
    $ionicConfigProvider.form.checkbox('circle');

    //Enable refresher - "By default, Ionic 1.2 will use native scrolling on all platforms." ion-refresher is based on jsScrolling. If you want ion-refresher you should enable jsScrolling. You can do it by adding $ionicConfigProvider.scrolling.jsScrolling(true); in your app config
    //Whether to use JS or Native scrolling. Defaults to native scrolling. Setting this to true has the same effect as setting each ion-content to have overflow-scroll='false'
    $ionicConfigProvider.scrolling.jsScrolling(true);

    //Disable / enable debug traces - set to false for production
    var willShowDebug = SESSION.ENVIRONMENT != "production";
    $logProvider.debugEnabled(willShowDebug);

    $locationProvider.html5Mode({
        enabled: true,
        requireBase: true
    });

}]);

//GLOBAL EVENTS (runs 2nd)
myApp.run(['$ionicPlatform', '$rootScope', '$state', '$log', '$http', '$window', '$location', 'IonicUtilsService', 'UserService', 'BuildingService', 'Analytics', 'APP_CONFIG', 'SESSION', function ($ionicPlatform, $rootScope, $state, $log, $http, $window, $location, IonicUtilsService, UserService, BuildingService, Analytics, APP_CONFIG, SESSION) {

    $log.debug('myApp.run');

    //Injected session from rails
    $log.debug('$ionicPlatform.ready');
    $log.debug('SESSION:' + SESSION.API_TOKEN);
    $log.debug('USER:' + SESSION.USER_ID);

    //Init Google Analytics
    if (SESSION.ENVIRONMENT == "staging") {
        // $window.ga('create', 'UA-86437075-1', 'auto');//Omobono
        $window.ga('create', 'UA-101266875-2', 'auto');//Mindtree
    } else if (SESSION.ENVIRONMENT == "production") {
        $window.ga('create', 'UA-77277423-2', 'auto');//JLL
    }

    //Make all calls with token in Authorization Header
    $http.defaults.headers.common.Authorization = 'Token token=' + SESSION.API_TOKEN;
    $http.defaults.headers.common['Content-Type'] = 'application/json'; // x-www-form-urlencoded';

    //Check before router redirects
    $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState, fromParams) {

        //Handle external links
        if (toState.external && angular.isDefined(BuildingService.selectedBuilding)) {

            event.preventDefault();

            $log.debug('$stateChangeStart: ' + BuildingService.selectedBuilding[toState.api_node]);

            var url = BuildingService.selectedBuilding[toState.api_node];
            try {
                //Do we need to show external alert?
                if (toState.showAlert == true) {
                    IonicUtilsService.showExternalLinkPrompt(url, toState.externalServiceName);
                } else {

                    //Its a menu button link - don't show alert
                    var eventName = 'home-' + toState.externalServiceName + '-button';
                    var eventSlug = eventName.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');

                    //category, action, label, value
                    Analytics.sendEvent(eventSlug, url, BuildingService.selectedBuilding.name, BuildingService.selectedBuilding.id);

                    //Now open window
                    $window.open(url, '_blank');
                }

            } catch (e) {
                $log.warn("error getting BuildingService.selectedBuilding[toState.api_node]");
            }
        }

        //Check if we need to show splash
        if (toState.name != "splash" && UserService.isAllDataLoaded() == false) {
            event.preventDefault();
            $log.debug("Redirect to splash");
            $state.go("splash");
        }
    });

    $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
        Analytics.sendPageView($location.path(), toState.name);

        if (BuildingService.selectedBuilding)
            Analytics.sendEvent('pageView', $location.path(), BuildingService.selectedBuilding.name, BuildingService.selectedBuilding.id);
    });

    //Show external dialogue for all external anchor tags
    $window.onclick = function (e) {

        function isExternal(url) {
            function domain(url) {
                return url.replace('http://', '').replace('https://', '').split('/')[0];
            };

            // Email links should be considered "internal" so they don't show a warning or open in a new tab
            if (url.indexOf('mailto:') == 0 || url.indexOf('tel:') == 0) {

                //Send Analytics - category, action, label, value
                var category = url.indexOf('mailto:') == 0 ? "email-button" : "telephone-button";
                var action = url.indexOf('mailto:') == 0 ? "compose-email" : "make-call";
                Analytics.sendEvent(category, action, url, BuildingService.selectedBuilding.id);

                return false;
            }

            var current_domain = domain(url);
            $log.debug('domain is', current_domain);

            if (current_domain == 'www.pg.com') {
                return false;
            }
            else {
                // Otherwise evaluate whether or not this is on the same domain (local link)
                return domain(location.href) !== current_domain;
            }
        };

        if (e.target && e.target.href) {
            var isExternal = isExternal(e.target.href);
            $log.debug("Is external URL? " + isExternal);
            if (isExternal) {
                e.preventDefault();
                IonicUtilsService.showExternalLinkPrompt(e.target.href);
            }
        }

    };

}]);

//ANGULAR HELPER METHODS (extensions)
ionic.Platform.isBrowser = function () {
    return !(ionic.Platform.isWebView() || ionic.Platform.isIOS() || ionic.Platform.isAndroid() || ionic.Platform.isWindowsPhone());
};

angular.isUndefinedOrNull = function (val) {
    return angular.isUndefined(val) || val === null || val === '';
};

angular.isDefinedAndNotNull = function (val) {
    return angular.isDefined(val) && val !== null && val !== '';
};

/**
 * Check for nested object
 *
 * @usage: var test = {level1:{level2:{level3:'level3'}} };
 * checkNestedValueExists(test, 'level1', 'level2', 'level3'); // true
 * checkNestedValueExists(test, 'level1', 'level2', 'foo'); // false
 */
angular.checkNestedValueExists = function (obj /*, level1, level2, ... levelN*/) {
    var args = Array.prototype.slice.call(arguments, 1);

    for (var i = 0; i < args.length; i++) {
        if (!obj || !obj.hasOwnProperty(args[i])) {
            return false;
        }
        obj = obj[args[i]];
    }
    return true;
};

function isExternalHyperlink(url) {
    return /\b(http|https)/.test(url);
}

(function () {
    Math.clamp = function (val, min, max) {
        return Math.min(Math.max(min, val), max);
    }
})();



