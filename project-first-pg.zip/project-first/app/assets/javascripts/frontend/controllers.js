/**
 * My P&G Office - Controllers
 */

angular.module('app.controllers', [])

    .controller('splashCtrl', ['$scope','$rootScope', '$state', '$timeout', '$log', '$ionicHistory', 'APP_CONFIG', 'UserService', 'MenuButtonService', 'BuildingService', 'IonicUtilsService', function ($scope, $rootScope, $state, $timeout, $log, $ionicHistory, APP_CONFIG, UserService, MenuButtonService, BuildingService, IonicUtilsService) {

        var STATE = {};
        STATE.ERROR = 'error';
        STATE.TERMS = 'terms';
        STATE.SELECT = 'select';

        $scope.appVersion = APP_CONFIG.VERSION;
        $scope.appTitle = APP_CONFIG.TITLE;
        $scope.onboardingState = STATE.ERROR;

        function navigateTo(stateName) {

            // using the $ionicHistory to hide the back button on next view - http://ionicframework.com/docs/nightly/api/service/$ionicHistory/
            $ionicHistory.nextViewOptions({
                disableAnimate: true,
                disableBack: true,//The next view should forget its back view, and set it to null.
                historyRoot: true //The next view should become the root view in its history stack.
            });

            $state.go(stateName);
        }

        $scope.$on('$ionicView.beforeEnter', function () {
            UserService.callJSON().then(function (response) {
                $log.debug('Success');
                $scope.regions = response.regions.data.regions;
                $rootScope.local_regions = $scope.regions;
                //console.log('Regions rootscope in controller',$rootScope.local_regions);
            }, function (error) {
                $scope.statusText = "An error occurred:";
                $log.warn(error);
            });
            $scope.selectedRegionId = UserService.region_id;
            $scope.selectedCountryId = UserService.country_id;
            $scope.selectedBuildingId = UserService.building_id;
            $scope.selectedFloorId = UserService.floor_id;


            // $scope.buildings = BuildingService.buildings;
            $scope.building = BuildingService.selectedBuilding;
            $scope.appTitle = APP_CONFIG.TITLE;
            $scope.appVersion = APP_CONFIG.VERSION;
            $scope.menuButtons = MenuButtonService.buttons;


            //Get user object - (this sets selected building if set)
            UserService.getUser().then(function (response) {

                if (UserService.isOnboardingComplete()) {
                    //Download selected building data
                    $scope.getBuildingData(response.user.building_id);
                } else {
                    $scope.onboardingState = STATE.TERMS;
                    SplashScreen.fadeAfterDelay();
                }

            }, function (errorText) {
                $scope.statusText = errorText;
                $scope.onboardingState = STATE.ERROR;
                SplashScreen.fadeAfterDelay();
            });

        });
        //  var shouldClear = true;
        // $scope.datalist = BuildingFactory.getLocationData(shouldClear);
        // console.log(this.datalist);
        $scope.getBuildingData = function (userBuildingId, doOnboarding) {

            $log.debug('getBuildingData ', userBuildingId);

            IonicUtilsService.showLoadingWithTitle('Loading building data');

            BuildingService.getBuildingByIdFromRemote(userBuildingId).then(function (response) {
                $log.debug('Success: getBuildingByIdFromRemote ', response);
                $scope.statusText = "";

                $timeout(function () {

                    IonicUtilsService.hideLoading();

                    if (doOnboarding) {
                        navigateTo("onboarding");
                    } else {
                        navigateTo("homeRedesign");
                    }

                }, APP_CONFIG.GRACE_PERIOD_MS);


            }, function (error) {
                $scope.statusText = error.message;
                $scope.onboardingState = STATE.ERROR;
                SplashScreen.fadeAfterDelay();
                $log.warn(error);
            });

        };

        $scope.userDisagrees = function ($event) {
            UserService.logOut();
        };

        //Once user agrees get buildings and user stuff
        $scope.userAgrees = function ($event) {
            //Go to select buildings
            $scope.buildings = BuildingService.buildings;
            $scope.data = {};
            $scope.data.selectedBuildingId = undefined;
            $scope.onboardingState = STATE.SELECT;
        };

        //$scope.selectBuilding = function (buildingId) {

        // UserService.updateSelectedBuildingById(buildingId).then(function (response) {
        //$log.debug('Success: updated building_id for user on the backend.');
        // Set the building for this user and move on
        // UserService.user.building_id = buildingId;
        //Download building data and show onboarding
        //$scope.getBuildingData(buildingId, true);
        //}, function (error) {
        // $scope.statusText = "An error occurred: updateSelectedBuildingById";
        // $scope.onboardingState = STATE.ERROR;
        //  $log.warn(error);
        //  SplashScreen.fadeAfterDelay();
        // });

        // };
        $scope.selectBuilding = function (userBuildingId) {
            $log.debug('Update selected building by ID' + userBuildingId);

            //If we have the current building just close
            // if (userBuildingId == BuildingService.selectedBuilding.id) {
            //     $log.debug('Building already selected');
            //     $scope.modal.hide();
            //     return false;
            // }

            IonicUtilsService.showLoadingWithTitle('Updating building');

            //Update user and load in new building
            UserService.updateSelectedBuildingById($scope.data.selectedRegionId, $scope.data.selectedCountryId, userBuildingId, $scope.data.selectedFloorId).then(function successCallback(response) {
                //$scope.getBuildingData(userBuildingId);
                UserService.user.building_id = userBuildingId;
                //Download building data and show onboarding
                UserService.user.country_id = $scope.data.selectedCountryId;
                UserService.user.building_id = $scope.data.selectedBuildingId;
                UserService.user.floor_id = $scope.data.selectedFloorId;
                UserService.user.region_id = $scope.data.selectedRegionId;
                // $scope.selectedCountryId
                // $scope.selectedBuildingId
                // $scope.selectedFloorId
                // $scope.selectedRegionId
                $scope.getBuildingData(userBuildingId, true);
                //Analytics.sendEvent("save-button", "building-selection-modal", userBuildingId);
            }, function (error) {
                $scope.statusText = "An error occurred: updateSelectedBuildingById";
                $scope.onboardingState = STATE.ERROR;
                $log.warn(error);
                SplashScreen.fadeAfterDelay();
            });

        };
        $scope.selectedRegion = function (shouldClear) {

            $scope.data.selectedBuildingId = null;
            $scope.data.selectedFloorId = null;
            $scope.data.selectedCountryId = null;
            $scope.data.selectedCountryName = null;
            $scope.data.selectedBuildingName = null;
            $scope.data.selectedFloorName = null;

            angular.forEach($scope.regions, function (region) {
                if ($scope.data.selectedRegionId == region.id) {
                    $scope.data.selectedRegionName = region.name;
                    $scope.countries = region.countries;
                    $scope.toggleGroup('Region');
                    $scope.toggleGroup('Country');

                }

            });
        };

        $scope.selectedCountry = function () {


            $scope.data.selectedBuildingId = null;
            $scope.data.selectedFloorId = null;
            $scope.data.selectedBuildingName = null;
            $scope.data.selectedFloorName = null;

            angular.forEach($scope.countries, function (country) {
                if ($scope.data.selectedCountryId == country.id) {
                    $scope.data.selectedCountryName = country.name;

                    $scope.buildings = country.buildings;

                    $scope.toggleGroup('Country');
                    $scope.toggleGroup('Building');
                }

            });
        };

        $scope.selectedBuilding = function () {

            $scope.data.selectedFloorId = null;
            $scope.data.selectedFloorName = null;

            angular.forEach($scope.buildings, function (building) {
                if ($scope.data.selectedBuildingId == building.id) {
                    $scope.data.selectedBuildingName = building.name;
                    $scope.floors = building.floors;
                    $scope.toggleGroup('Building');
                    $scope.toggleGroup('Floor');
                }
            });
        };

        $scope.selectedFloor = function () {

            angular.forEach($scope.floors, function (floor) {
                if ($scope.data.selectedFloorId == floor.id) {
                    $scope.data.selectedFloorName = floor.name;
                }
            });


        };

        $scope.toggleGroup = function (group) {
            if ($scope.isGroupShown(group)) {
                $scope.shownGroup = null;
            } else {
                $scope.shownGroup = group;
            }
        };
        $scope.isGroupShown = function (group) {

            return $scope.shownGroup === group;

        };
        $scope.$on('$destroy', function () {
            if (angular.isDefined($scope.modal)) {
                $scope.modal.remove();
            }
        });

    }])

    .controller('homeCtrl', ['$scope', '$stateParams', '$state', '$log', '$timeout', '$ionicPopover', '$ionicHistory', '$ionicModal', 'BuildingService', 'AnnouncementsService', 'MenuButtonService', 'WeatherIconService', 'UserService', 'IonicUtilsService', 'DealsAndEventsTabService', 'pgSensingService', 'APP_CONFIG', function ($scope, $stateParams, $state, $log, $timeout, $ionicPopover, $ionicHistory, $ionicModal, BuildingService, AnnouncementsService, MenuButtonService, WeatherIconService, UserService, IonicUtilsService, DealsAndEventsTabService, pgSensingService, APP_CONFIG) {

        function getWeatherMessage() {

            if (angular.isUndefined($scope.building) || $scope.building.weather.cod != "200") {
                return "";
            }

            try {
                return $scope.building.city + ", " + parseInt($scope.building.weather.list[0].main.temp) + "°, " + $scope.building.weather.list[0].weather[0].description;
            } catch (e) {
                $log.warn("error returning getWeatherMessage()");
            }
        };

        /* Unused now but will get a PNG icon from API */
        function getWeatherIconURL() {
            if (angular.isUndefined($scope.building) || $scope.building.weather.cod != "200") {
                return "";
            }
            return "https://openweathermap.org/img/w/" + $scope.building.weather.list[0].weather[0].icon + ".png";//"01n"
        };

        function getWeatherIconClass() {
            var iconClass = '';
            try {
                var iconCode = $scope.building.weather.list[0].weather[0].icon;
                iconClass = WeatherIconService.getIconClassNameByWeatherCode(iconCode);
            } catch (e) {
                $log.warn("error returning getWeatherIconClass()");
            }
            return iconClass;
        };

        //Setup popover
        $ionicPopover.fromTemplateUrl('templates/partials/home-popover.html', {
            scope: $scope
        }).then(function (popover) {
            $scope.popover = popover;
        });

        $scope.openHomePopover = function ($event) {
            $scope.popover.show($event);
        };

        $scope.closePopover = function () {
            if (angular.isDefined($scope.popover)) {
                $scope.popover.hide();
            }
        };

        $scope.popoverGotoView = function (path, arg) {
            $scope.popover.hide();
            $state.go(path, arg);
        };

        /**
         * Broken this out from ui-sref so we can check number of records
         * and jump straight to detail state if only one exists
         * @param stateName
         */
        $scope.navigateTo = function (stateName) {
            //TODO: How do we do this for all subscreens cleanly?
            if (stateName == 'dining') {
                var internalVendors = BuildingService.getInternalVendors();
                if (internalVendors.length == 1) {
                    $state.go("vendorDetail", { id: internalVendors[0].id });
                    return;
                }
            }

            $state.go(stateName);
        };

        //Cleanup the popover when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.popover.remove();
        });

        $scope.showOnboarding = function (forceOpen) {

            $log.debug('Do onboarding? ' + UserService.isOnboardingComplete());

            if (UserService.isOnboardingComplete()) {
                return;
            }

            // using the $ionicHistory to hide the back button on next view - http://ionicframework.com/docs/nightly/api/service/$ionicHistory/
            $ionicHistory.nextViewOptions({
                disableAnimate: false,
                disableBack: true
            });

            $state.go('onboarding');
        };

        $scope.updateWeather = function () {
            $scope.weatherMessage = getWeatherMessage();
            $scope.weatherIconClass = getWeatherIconClass();
        };

        $scope.$on('$ionicView.loaded', function () {
            //$scope.welcomeMessage = WelcomeMessageService.getMessage();
        });

        //This event is emitted when the slider is initialized. It provides access to an instance of the slider.
        $scope.$on("$ionicSlides.sliderInitialized", function (event, data) {
            // grab an instance of the slider
            $scope.slider = data.slider;
        });

        $scope.$on('$ionicView.beforeEnter', function () {
            $log.debug("HomeCtrl $ionicView.beforeEnter");
            $scope.menuButtons = MenuButtonService.init();
            $scope.building = BuildingService.selectedBuilding;
            $scope.buildings = BuildingService.buildings;
            $scope.numNotifications = AnnouncementsService.getUnReadCount();
            $scope.updateWeather();
            $scope.showOnboarding();
            $scope.checkProfileUpdated();
            $scope.checkPendingSurveys();
            $scope.buildingHeroImageUrl = $scope.building['hero_image_x' + IonicUtilsService.getDevicePixelResolution()];
        });

        $scope.checkPendingSurveys = function () {
            pgSensingService.getAllSurveys().then(function (response) {
                var pendingSurveys = response;
                $scope.surveyLength = pendingSurveys.push.length + pendingSurveys.generic.length;
                if (pendingSurveys.push.length)
                    $scope.showPendingSurveys(true, pendingSurveys.push[0]);
                else if (APP_CONFIG.SHOW_PENDING_SURVEY && pendingSurveys.generic.length)
                    $scope.showPendingSurveys(false, pendingSurveys.generic[0].id);
            });
        };

        $scope.$on('$ionicView.enter', function () {
            SplashScreen.fadeAfterDelay();
            DealsAndEventsTabService.resetDefaultTab();//reset the tabs in service so when we navigate to deals & events we get the default tab
        });

        //See API: http://idangero.us/swiper/api/#.WBDUvOErLKk
        $scope.sliderOptions = {
            loop: false,
            effect: 'slide',
            speed: 500, //animation speed
            paginationClickable: true,//allow user to click on pagination
            //pagination: false, //this turn pagination off if included regardless of value?!
            grabCursor: true
        };
        $scope.checkProfileUpdated = function () {
            if (!UserService.isMobileNumberUpdated()) {
                $scope.updateProfile();
            }

        }
        $scope.updateProfile = function () {

            var templateURL, modalName;

            templateURL = 'templates/partials/update-mobile.html';
            modalName = "building-selection";
            $scope.data = {
                message: null,
                success: null
            }

            $ionicModal.fromTemplateUrl(templateURL, {
                backdropClickToClose: false,
                hardwareBackButtonClose: false,
                scope: $scope,
                animation: 'slide-in-up' //animation types https://forum.ionicframework.com/t/modal-animations/449/9
            }).then(function (modal) {
                $scope.modal = modal;
                $scope.modal.show();
            });

        };

        $scope.showPendingSurveys = function (hasPushedSurvey, surveyId) {

            var templateURL, modalName;

            templateURL = 'templates/partials/pending-surveys.html';
            $scope.data = {
                name: UserService.user.first_name,
                hasPushedSurvey: hasPushedSurvey,
                surveyId: surveyId
            }

            $ionicModal.fromTemplateUrl(templateURL, {
                backdropClickToClose: false,
                hardwareBackButtonClose: false,
                scope: $scope,
                animation: 'slide-in-up meetup-feedback meetup-survey-modal'
            }).then(function (modal) {
                $scope.modal = modal;
                $scope.modal.show();
            });

        };
        $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
            if (angular.isDefined($scope.modal)) {
                $scope.modal.remove();
            }
        });
        $scope.takeSurvey = function (surveyId, hasPushedSurvey) {
            $scope.modal.hide();
            if (hasPushedSurvey)
                $state.go('surveyDetail', { surveyId: surveyId });
            else {
                $state.go('pgSensing');
            }
        };

        $scope.ignoreSurvey = function () {
            APP_CONFIG.SHOW_PENDING_SURVEY = false;
            $scope.closeModal();
        };

        $scope.closeModal = function () {
            if (angular.isDefined($scope.modal)) {
                $scope.modal.hide();
            }
        };
        $scope.updateMobile = function (telephone, subscribe) {
            $log.debug('updateMobile ' + telephone);
            IonicUtilsService.showLoadingWithTitle('Updating Mobile number');

            UserService.updateMobileNumber(telephone, subscribe).then(function (response) {
                IonicUtilsService.hideLoading();

                $scope.data.message = response.message;
                $scope.data.success = response.success;

                $timeout(function () {

                    if (response.success) {
                        $scope.modal.hide();
                    }

                }, 1000);

            });
        };

    }])

    .controller('onboardingCtrl', ['$scope', '$stateParams', '$state', '$window', '$ionicHistory', '$ionicSlideBoxDelegate', 'BuildingService', 'UserService', 'APP_CONFIG', function ($scope, $stateParams, $state, $window, $ionicHistory, $ionicSlideBoxDelegate, BuildingService, UserService, APP_CONFIG) {

        //Onboarding

        //This event is emitted when the slider is initialized. It provides access to an instance of the slider.
        $scope.$on("$ionicSlides.sliderInitialized", function (event, data) {
            // grab an instance of the slider
            $scope.slider = data.slider;
            //number slides console.log($scope.slider.slides.length);
        });

        //This event is emitted when a slide change begins
        $scope.$on("$ionicSlides.slideChangeStart", function (event, data) {
            $scope.slideChanged(data.slider.activeIndex);
        });

        //This event is emitted when a slide change completes
        $scope.$on("$ionicSlides.slideChangeEnd", function (event, data) {
            $scope.slideChanged(data.slider.activeIndex);
        });


        //http://ionicframework.com/docs/api/service/$ionicSlideBoxDelegate/
        $scope.nextSlide = function () {
            $scope.slider.slideNext();
        };

        $scope.previousSlide = function () {
            $scope.slider.slidePrev();
        };

        // Called to navigate to the main app
        var startApp = function (neverShowAgain) {

            $ionicHistory.nextViewOptions({
                disableAnimate: false,
                disableBack: true
            });

            // Set a flag that we finished the tutorial
            // onboarding_complete should be false to trigger save
            UserService.setOnboardingComplete();
            // Jump to home screen immediately, so make onboarding_complete true regardless
            UserService.user.onboarding_complete = 1;
            $state.go('homeRedesign');
        };

        // Our default left/right buttons
        var rightButton =
            {
                title: 'Next',
                tap: function (e) {
                    $scope.nextSlide();
                }
            };

        var leftButton =
            {
                title: '',
                tap: function (e) {
                    angular.noop;
                }
            };

        var backButton =
            {
                title: 'Back',
                tap: function (e) {
                    $scope.previousSlide();
                }
            };

        var startButton =
            {
                title: 'Start',
                tap: function (e) {
                    startApp();
                }
            };

        // Bind the left and right buttons to the scope
        $scope.leftButton = leftButton;
        $scope.rightButton = rightButton;

        // Called each time the slide changes
        $scope.slideChanged = function (index) {

            // Check if we should update the left buttons
            if (index > 0) {
                // If this is not the first slide, give it a back button
                $scope.leftButton = backButton;
            } else {
                // This is the first slide, use the default left buttons
                $scope.leftButton = leftButton;
            }

            // If this is the last slide, set the right button to
            // move to the app
            if (index == $scope.slider.slides.length - 1) {
                $scope.rightButton = startButton;
            } else {
                // Otherwise, use the default buttons
                $scope.rightButton = rightButton;
            }
        };

        $scope.close = function () {
            startApp();
        };

        $scope.$on('$ionicView.loaded', function () {
            $scope.onboardingCompleted = UserService.isOnboardingComplete();
            $scope.buildings = BuildingService.buildings;
            $scope.building = BuildingService.selectedBuilding;
            $scope.appTitle = APP_CONFIG.TITLE;
            $scope.data = {};
            $scope.data.selectedBuildingId = BuildingService.selectedBuilding.id;
            //See http://idangero.us/swiper/api/#.V-p3ZpMrLKl for options
            $scope.data.sliderOptions = {
                loop: false,
                direction: 'horizontal',
                effect: 'slide',//Could be "slide", "fade", "cube", "coverflow" or "flip"
                speed: 500
                //grabCursor: true,
                //nested: true
            };
            $scope.buildingId = BuildingService.selectedBuilding.id;
        });

    }])

    .controller('settingsCtrl', ['$scope', '$stateParams', '$state', '$ionicScrollDelegate', '$log', '$timeout', '$ionicModal', '$ionicLoading', 'MenuButtonService', 'BuildingService', 'UserService', 'IonicUtilsService', 'Analytics', 'APP_CONFIG', function ($scope, $stateParams, $state, $ionicScrollDelegate, $log, $timeout, $ionicModal, $ionicLoading, MenuButtonService, BuildingService, UserService, IonicUtilsService, Analytics, APP_CONFIG) {

        /*
         - Customize Menu (yes, we'd like it to come back)
         - Building Selection
         - Announcements
         */

        //Setup Modal

        $scope.openModal = function (type) {

            var templateURL, modalName;

            switch (type) {
                case "profile":
                    $scope.data = {
                        phone: UserService.user.phone,
                        send_sms_announcements: UserService.user.send_sms_announcements,
                        selectedBuildingId: $scope.selectedBuildingId,
                        selectedRegionId: $scope.selectedRegionId,
                        selectedCountryId: $scope.selectedCountryId,
                        selectedFloorId: $scope.selectedFloorId,
                        success: false,
                        message: ''
                    };
                    $scope.message = '';
                    templateURL = 'templates/partials/profile-modal.html';
                    modalName = "building-selection";
                    break;

                // case "buildings":
                //     $scope.data = {
                //         selectedBuildingId: BuildingService.selectedBuilding.id
                //     };
                //     templateURL = 'templates/partials/choose-building-modal.html';
                //     modalName = "building-selection";
                //     break;
                case "announcements":
                    $scope.data = {
                        phone: UserService.user.phone,
                        send_sms_announcements: UserService.user.send_sms_announcements,
                        success: false,
                        message: ''
                    };
                    $scope.message = '';
                    templateURL = 'templates/partials/user-modal.html';
                    modalName = "announcements";
                    break;
                case "customise-menu":
                    $scope.buttons = angular.copy($scope.menuButtons);
                    templateURL = 'templates/partials/customise-menu-modal.html';
                    modalName = "home-buttons";
                    break;
                default:
                    $log.warn('Not a valid type: ' + type);
            }

            Analytics.sendPageView("/settings/" + modalName, modalName);

            $ionicModal.fromTemplateUrl(templateURL, {
                scope: $scope,
                animation: 'slide-in-up'//animation types https://forum.ionicframework.com/t/modal-animations/449/9
            }).then(function (modal) {
                if (type === 'profile') {
                    $timeout(function () {
                        $scope.selectedRegion(false);
                        $scope.selectedCountry(false);
                        $scope.selectedBuilding(false);
                        $scope.selectedFloor(false);
                        if (angular.isDefined($scope.modal)) {
                            $scope.modal.hide();
                        }
                        $scope.modal = modal;
                        $scope.modal.show();
                    }, APP_CONFIG.GRACE_PERIOD_MS);
                }
                else {
                    if (angular.isDefined($scope.modal)) {
                        $scope.modal.hide();
                    }
                    $scope.modal = modal;
                    $scope.modal.show();
                }
            });

        };

        $scope.closeModal = function () {
            if (angular.isDefined($scope.modal)) {
                $scope.modal.hide();
            }
        };

        // Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            if (angular.isDefined($scope.modal)) {
                $scope.modal.remove();
            }
        });

        $scope.saveMenuButtons = function () {

            $log.debug('Save menu buttons');

            //Check if anything has been changed -- too hard as angular adds scope references

            IonicUtilsService.showLoadingWithTitle('Saving home button preferences');

            //Create order ids and persist
            var buttonOrderArr = MenuButtonService.saveButtonOrderArray(angular.copy($scope.buttons));

            $log.debug('Convert to JSON: ' + angular.toJson(buttonOrderArr));

            UserService.updatePreferences(buttonOrderArr).then(function (success) {

                $timeout(function () {
                    IonicUtilsService.hideLoading();
                    $scope.menuButtons = MenuButtonService.buttons;
                    $scope.closeModal();
                    Analytics.sendEvent("save-button", "home-buttons-modal", angular.toJson(buttonOrderArr));
                }, APP_CONFIG.GRACE_PERIOD_MS);

            }, function (error) {
                $log.warn('An error occurred updating menu button orders');
            });

        };

        $scope.cancelButtonOrder = function () {
            $scope.closeModal();
            $scope.menuButtons = MenuButtonService.availableButtons;
            Analytics.sendEvent("cancel-button", "home-buttons-modal");
        };

        $scope.resetDefaultButtons = function () {
            $scope.menuButtons = MenuButtonService.getDefaultButtons();
            $scope.buttons = angular.copy($scope.menuButtons);
        };

        $scope.moveItem = function (item, fromIndex, toIndex) {
            $scope.buttons.splice(fromIndex, 1);
            $scope.buttons.splice(toIndex, 0, item);
        };

        $scope.getBuildingData = function (buildingId) {
            $log.debug('getBuildingData ', buildingId);

            BuildingService.getBuildingByIdFromRemote(buildingId).then(function (response) {
                $log.debug('Success: getBuildingByIdFromRemote ', response);

                $scope.building = BuildingService.selectedBuilding;

                $timeout(function () {
                    IonicUtilsService.hideLoading();
                    $scope.modal.hide();
                }, APP_CONFIG.GRACE_PERIOD_MS);


            }, function (error) {
                $log.warn(error);
            });

        };

        $scope.checkplus = function (event) {

            if (event.keyCode <= 48 && event.keyCode >= 59) {
                event.preventDefault();
            }
            if (event.key === 'e' || event.key === 'E' || event.key === '+' || event.key ==='-') {
                event.preventDefault();
            }

        }

        $scope.selectBuilding = function (userBuildingId) {
            $log.debug('Update selected building by ID' + userBuildingId);

            //If we have the current building just close
            // if (userBuildingId == BuildingService.selectedBuilding.id) {
            //     $log.debug('Building already selected');
            //     $scope.modal.hide();
            //     return false;
            // }


            if (!$scope.data.phone && $scope.data.send_sms_announcements) {
                $scope.data.message = "Enter mobile number to receive sms announcement";
                $scope.data.success = false;
            }
            else if (!$scope.data.phone) {
                $scope.data.message = "Mobile number should have more than 8 characters";
                $scope.data.success = false;
            }
            else {
                IonicUtilsService.showLoadingWithTitle('Updating profile');
                //Update user and load in new building
                UserService.updateProfile($scope.data.selectedRegionId, $scope.data.selectedCountryId, userBuildingId, $scope.data.selectedFloorId, $scope.data.phone, $scope.data.send_sms_announcements).then(function successCallback(response) {
                    $scope.getBuildingData(userBuildingId);
                    UserService.user.phone = $scope.data.phone;
                    UserService.user.send_sms_announcements = $scope.data.send_sms_announcements;
                    $scope.selectedCountryId = $scope.data.selectedCountryId;
                    $scope.selectedBuildingId = $scope.data.selectedBuildingId;
                    $scope.selectedFloorId = $scope.data.selectedFloorId;
                    $scope.selectedRegionId = $scope.data.selectedRegionId;
                    Analytics.sendEvent("save-button", "building-selection-modal", userBuildingId);
                    $scope.data.message = "Profile Successfully Updated";
                    $scope.data.success = true;
                    UserService.getUser().then(function (response){
                      BuildingService.setSelectedBuildingById(response.user.building_id);  
                    });
                }, function errorCallback(error) {
                    $log.warn(error);
                });
            }

        };

        $scope.saveSMSPrefs = function (telephone, subscribe) {
            $log.debug('saveSMSPrefs ' + subscribe + ' ' + telephone);

            IonicUtilsService.showLoadingWithTitle('Updating SMS preferences');

            Analytics.sendEvent("save-button", "receive-sms-announcements", subscribe);

            UserService.subscribeForSMS(telephone, subscribe).then(function (response) {

                IonicUtilsService.hideLoading();

                $scope.data.message = response.message;
                $scope.data.success = response.success;

                $timeout(function () {

                    if (response.success) {
                        $scope.modal.hide();
                    }

                }, APP_CONFIG.GRACE_PERIOD_MS);

            });
        };

        $scope.logOut = function () {
            IonicUtilsService.showLogOutPrompt();
        };

        // Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            if (angular.isDefined($scope.modal)) {
                $scope.modal.remove();
            }
        });

        $scope.$on('$ionicView.beforeEnter', function () {
            IonicUtilsService.showLoadingWithTitle('Loading Profile...');
            UserService.callJSON().then(function (response) {
                IonicUtilsService.hideLoading();
                $log.debug('Success');
                $scope.regions = response.regions.data.regions;
            }, function (error) {
                $scope.statusText = "An error occurred:";
                $log.warn(error);
            });
            $scope.selectedCountryId = UserService.user.country_id;
            $scope.selectedBuildingId = UserService.user.building_id;
            $scope.selectedFloorId = UserService.user.floor_id;
            $scope.selectedRegionId = UserService.user.region_id;

            // $scope.buildings = BuildingService.buildings;
            $scope.building = BuildingService.selectedBuilding;
            $scope.appTitle = APP_CONFIG.TITLE;

            $scope.menuButtons = MenuButtonService.buttons;
        });
        // $scope.datalist = BuildingFactory.getLocationData(shouldClear);
        // console.log(this.datalist);
        $scope.selectedRegion = function (shouldClear) {

            if (shouldClear) {
                $scope.data.selectedBuildingId = null;
                $scope.data.selectedFloorId = null;
                $scope.data.selectedCountryId = null;
                $scope.data.selectedCountryName = null;
                $scope.data.selectedBuildingName = null;
                $scope.data.selectedFloorName = null;
            }
            angular.forEach($scope.regions, function (region) {
                if ($scope.data.selectedRegionId == region.id) {
                    $scope.data.selectedRegionName = region.name;
                    $scope.countries = region.countries;
                    $scope.toggleGroup('Region');
                    $scope.toggleGroup('Country');

                }

            });
        };

        $scope.selectedCountry = function (shouldClear) {

            if (shouldClear) {
                $scope.data.selectedBuildingId = null;
                $scope.data.selectedFloorId = null;
                $scope.data.selectedBuildingName = null;
                $scope.data.selectedFloorName = null;
            }
            angular.forEach($scope.countries, function (country) {
                if ($scope.data.selectedCountryId == country.id) {
                    $scope.data.selectedCountryName = country.name;

                    $scope.buildings = country.buildings;

                    $scope.toggleGroup('Country');
                    $scope.toggleGroup('Building');
                }

            });
        };

        $scope.selectedBuilding = function (shouldClear) {
            if (shouldClear) {
                $scope.data.selectedFloorId = null;
                $scope.data.selectedFloorName = null;
            }

            angular.forEach($scope.buildings, function (building) {
                if ($scope.data.selectedBuildingId == building.id) {
                    $scope.data.selectedBuildingName = building.name;
                    $scope.floors = building.floors;
                    $scope.toggleGroup('Building');
                    $scope.toggleGroup('Floor');
                }
            });
        };

        $scope.selectedFloor = function () {

            angular.forEach($scope.floors, function (floor) {
                if ($scope.data.selectedFloorId == floor.id) {

                    $scope.data.selectedFloorName = floor.name;

                }
            });


        };

        $scope.toggleGroup = function (group) {

            if ($scope.isGroupShown(group)) {
                $scope.shownGroup = null;
            } else {

                $scope.shownGroup = group;
                $ionicScrollDelegate.resize();
            }

        };

        $scope.isGroupShown = function (group) {

            return $scope.shownGroup === group;

        };

    }])

    .controller('informationCtrl', ['$scope', '$stateParams', '$state', '$window', '$ionicHistory', 'BuildingService', 'APP_CONFIG', function ($scope, $stateParams, $state, $window, $ionicHistory, BuildingService, APP_CONFIG) {

        /*
         - How to use My P&G Office
         - About My P&G Office
         - About P&G
         - Privacy Policy & Terms of Use

         */
        $scope.showOnboarding = function () {
            // using the $ionicHistory to hide the back button on next view - http://ionicframework.com/docs/nightly/api/service/$ionicHistory/
            $ionicHistory.nextViewOptions({
                disableAnimate: false,
                disableBack: true
            });
            $state.go('onboarding');
        };

        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.buildings = BuildingService.buildings;
            $scope.building = BuildingService.selectedBuilding;
            $scope.appTitle = APP_CONFIG.TITLE;
            $scope.appVersion = APP_CONFIG.VERSION;
        });

    }])

    .controller('buildingInfoCtrl', ['$scope', '$stateParams', '$state', '$log', '$ionicHistory', 'BuildingService', 'APP_CONFIG', function ($scope, $stateParams, $state, $log, $ionicHistory, BuildingService, APP_CONFIG) {

        /**
         * Work out where we came from to set the correct state
         * Not sure why this needs to happen but  back button is not working properly.
         * Using parent state with abstract does not work either.
         * Using ion-nav-view within ion-view doesn't work either
         */
        $scope.$on('$ionicView.beforeEnter', function () {
            //Check if its  back nav
            var history = $ionicHistory.viewHistory();

            //Navigating using back button, insure correct tab is selected
            if (!angular.isUndefinedOrNull(history.forwardView)) {
                if (!angular.isUndefinedOrNull(history.forwardView.stateName)) {
                    var lastStateName = $ionicHistory.viewHistory().forwardView.stateName;
                    $state.go('buildingInfo.' + lastStateName);
                }
            } else {
                $state.go('buildingInfo.amenities');
            }

            $scope.building = BuildingService.selectedBuilding;
            $scope.contacts = $scope.building.contacts;

            //Get available types for contacts and amenities
            var buildingInfoTypes = BuildingService.getAvailableBuildingInfoTypes();

            $log.debug('buildingInfoTypes');
            $log.debug(buildingInfoTypes);

            $scope.amenityTypes = buildingInfoTypes.amenityTypes;
            $scope.contactTypes = buildingInfoTypes.contactTypes;

        });

    }])

    .controller('contactsCtrl', ['$scope', '$stateParams', '$filter', 'BuildingService', function ($scope, $stateParams, $filter, BuildingService) {
        //Filter by type
        $scope.type = $stateParams.type;
        $scope.typeName = $stateParams.typeName;
        $scope.icon = $stateParams.icon;

        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.contacts = BuildingService.selectedBuilding.contacts.filter(function (contact) {
                return (contact.type == $scope.type);
            });
        });
    }])

    .controller('contactDetailCtrl', ['$scope', '$stateParams', 'contact', function ($scope, $stateParams, contact) {
        $scope.contact = contact;
    }])

    .controller('amenitiesCtrl', ['$scope', '$stateParams', '$log', '$state', '$filter', '$ionicHistory', 'BuildingService', 'IonicUtilsService', function ($scope, $stateParams, $log, $state, $filter, $ionicHistory, BuildingService, IonicUtilsService) {

        $scope.type = $stateParams.type;
        $scope.typeName = $stateParams.typeName;
        $scope.icon = $stateParams.icon;

        $scope.typeCount = 0;
        $scope.amenities = BuildingService.selectedBuilding.amenities.filter(function (amenity) {
            //if(amenity.type == $scope.type){
            //    $scope.typeCount++;
            //    $scope.amenity = amenity;
            //}
            return (amenity.type == $scope.type);
        });

        //$scope.$on('$ionicView.beforeEnter', function () {
        //
        //    //$scope.amenityURL = "amenities({'type':amenityType.type,'typeName':amenityType.name, 'icon':amenityType.icon})";
        //    $log.debug("$scope.typeCount:" + $scope.typeCount);
        //
        //    //If only one amenity listed then go straight to it's detail view
        //    if($scope.typeCount == 1 && $scope.amenity){
        //        //$ionicHistory.nextViewOptions({
        //        //    disableBack: true //The next view should forget its back view, and set it to null.
        //        //});
        //        $state.go('amenity', {'id':$scope.amenity.id});
        //    }
        //});
    }])

    .controller('amenityDetailCtrl', ['$scope', '$stateParams', '$sce', 'amenity', 'IonicUtilsService', function ($scope, $stateParams, $sce, amenity, IonicUtilsService) {
        $scope.amenity = amenity;
        $scope.dpr = IonicUtilsService.getDevicePixelResolution();
        //$scope.description = $sce.trustAsHtml($scope.amenity.description);
    }])

    .controller('vendorsCtrl', ['$scope', '$stateParams', '$log', '$timeout', '$ionicPopover', 'BuildingService', 'IonicUtilsService', 'VendorSortFilterService', 'Analytics', function ($scope, $stateParams, $log, $timeout, $ionicPopover, BuildingService, IonicUtilsService, VendorSortFilterService, Analytics) {

        $scope.sortBy = function (fieldSortStr) {
            $scope.orderByValue = fieldSortStr;//A-z = "name"
            VendorSortFilterService.setOrderByValue(fieldSortStr);//save in service
            Analytics.sendEvent("retailer-order-by-button", fieldSortStr);
            $timeout(function () {
                $scope.closePopover();
            }, 500);
        };

        $scope.filterBy = function (filterObj) {
            $scope.filterOn = filterObj;
            VendorSortFilterService.setFilterOnValue(filterObj);//save in service
        };

        $scope.toggleTabName = function (name) {
            if ($scope.data.activeButton == name) {
                $scope.data.activeButton = null;
                $scope.filterOn = { in_house: false };
            } else {
                $scope.data.activeButton = name;
                $scope.filterOn = { type: name, in_house: false };
            }
            $scope.filterBy($scope.filterOn);
            Analytics.sendEvent("retailer-filter-by-button", angular.isDefined($scope.filterOn.type) ? "on" : "off", name);

        };

        //Setup popover
        $ionicPopover.fromTemplateUrl('templates/partials/vendors-popover.html', {
            scope: $scope
        }).then(function (popover) {
            $scope.popover = popover;
        });

        $scope.openPopover = function ($event) {
            $scope.popover.show($event);
        };

        $scope.closePopover = function () {
            $scope.popover.hide();
        };

        $scope.$on('$ionicView.loaded', function () {
            //Set filter and sort defaults
            VendorSortFilterService.setFilterOnValue({ in_house: false });
            VendorSortFilterService.setOrderByValue('name');
        });

        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.data = {};
            $scope.data.activeButton = null;
            $scope.orderByValue = VendorSortFilterService.getOrderByValue();//'-deals_count';//deals
            $scope.filterOn = VendorSortFilterService.getFilterOnValue();
            $scope.toggleTabName($scope.filterOn.type);
            $scope.filterBy($scope.filterOn);
            $scope.vendors = BuildingService.selectedBuilding.vendors;
            $scope.dpr = IonicUtilsService.getDevicePixelResolution();
        });

    }])

    .controller('vendorDetailCtrl', ['$scope', '$stateParams', '$log', '$window', '$timeout', 'IonicUtilsService', 'UserService', 'Analytics', 'APP_CONFIG', 'vendor', function ($scope, $stateParams, $log, $window, $timeout, IonicUtilsService, UserService, Analytics, APP_CONFIG, vendor) {

        $scope.vendor = vendor;

        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.dpr = IonicUtilsService.getDevicePixelResolution();
            $scope.likeClicked = UserService.getUserLikesVendorId(vendor.id);
        });

        $scope.incrementLike = function () {

            //IonicUtilsService.showLoadingWithTitle('Updating like');

            //Toggle
            $scope.likeClicked = !$scope.likeClicked;

            //Update likes in that vendor
            if ($scope.likeClicked) {
                $scope.vendor.vendor_likes_count += 1;
            } else {
                $scope.vendor.vendor_likes_count -= 1;
            }

            UserService.likeVendor($scope.likeClicked, $scope.vendor).then(function (response) {
                if (response.success) {
                    $log.debug(response);
                    Analytics.sendEvent("like-button", $scope.likeClicked ? "liked" : "unliked", $scope.vendor.name, $scope.vendor.id);
                }

                /*
                 $timeout(function () {
                 IonicUtilsService.hideLoading();
                 }, APP_CONFIG.GRACE_PERIOD_MS);
                 */

            });
        };

        $scope.openWebsite = function (url) {
            IonicUtilsService.showExternalLinkPrompt(url, $scope.vendor.type == 'dining' ? 'dining' : null);
        };

    }])

    .controller('dealsEventsCtrl', ['$scope', '$stateParams', '$state', '$log', '$filter', 'UserService', 'BuildingService', 'IonicUtilsService', 'DealsAndEventsTabService', function ($scope, $stateParams, $state, $log, $filter, UserService, BuildingService, IonicUtilsService, DealsAndEventsTabService) {

        $scope.onSelectTab = function (showDeals) {
            $scope.showDeals = !showDeals;
            $scope.items = showDeals ? $scope.deals : $scope.events;
            DealsAndEventsTabService.setTab(showDeals ? "deals" : "events");
        };

        $scope.showItem = function (item) {
            var stateName = $scope.showDeals ? 'event' : 'deal';
            $state.go(stateName, { 'id': item.id });
        };

        $scope.$on('$ionicView.beforeEnter', function () {

            //Marks all deals as redeemed or not
            UserService.updateDealsState();

            //Mark all events as attended or not
            UserService.updateEventAttendingState();

            $scope.dpr = IonicUtilsService.getDevicePixelResolution();

            //Vendor Id is optionally passed through $state
            var vendorId = $stateParams.vendorId;

            $scope.deals = BuildingService.selectedBuilding.deals.filter(function (deal) {
                if (!angular.isUndefinedOrNull(vendorId)) {
                    return (deal.type == 'vendor' && deal.vendor_id == vendorId);
                }
                return (deal.type == 'vendor');
            });

            $scope.events = BuildingService.selectedBuilding.events.filter(function (event) {
                if (!angular.isUndefinedOrNull(vendorId)) {
                    return (event.type == 'vendor' && event.vendor_id == vendorId);
                }
                return (event.type == 'vendor');
            });

            //selectedTab is store in the TabService but overridden if we just navigated from main menu
            var tabToSelect = DealsAndEventsTabService.getTab();
            $scope.onSelectTab(tabToSelect == "deals");


        });
    }])

    .controller('dealCtrl', ['$scope', '$stateParams', '$timeout', '$log', 'IonicUtilsService', '$ionicHistory', 'UserService', 'Analytics', 'APP_CONFIG', 'deal', function ($scope, $stateParams, $timeout, $log, IonicUtilsService, $ionicHistory, UserService, Analytics, APP_CONFIG, deal) {

        $scope.deal = deal;

        $scope.dpr = IonicUtilsService.getDevicePixelResolution();

        $scope.redeemDeal = function (dealId) {
            //IonicUtilsService.showLoadingWithTitle('Redeeming');
            UserService.redeemDeal($scope.deal).then(
                function (response) {

                    $log.debug("UserService.redeemDealById");
                    $log.debug(response);

                    //Post Analytics
                    Analytics.sendEvent("deal-redeem-button", "redeem-deal", $scope.deal.name, $scope.deal.id);

                    /*
                     $timeout(function () {
                     IonicUtilsService.hideLoading().then(function () {
                     // TODO: Hook this up to the deals service
                     });
                     }, APP_CONFIG.GRACE_PERIOD_MS);
                     */

                },
                function (error) {

                }
            );
            $scope.deal.redeemed = true;
            UserService.user.deal_redemptions.push({ 'deal_id': dealId });
            $ionicHistory.goBack();
        };

    }])

    .controller('eventCtrl', ['$scope', '$stateParams', '$timeout', '$log', '$window', '$ionicPopup', 'IonicUtilsService', 'UserService', 'Analytics', 'APP_CONFIG', 'event', '$ionicScrollDelegate', function ($scope, $stateParams, $timeout, $log, $window, $ionicPopup, IonicUtilsService, UserService, Analytics, APP_CONFIG, event, $ionicScrollDelegate) {

        $scope.event = event;
        $scope.dpr = IonicUtilsService.getDevicePixelResolution();
        function isEventFull() {
            return angular.isDefinedAndNotNull($scope.event.capacity) && ($scope.event.capacity - $scope.event.event_attendances_count == 0);
        }
        $scope.showPopup = function () {
            $scope.data = {}
            // Custom popup
            var myPopup = $ionicPopup.confirm({
                template: '<p class="padding-top">By clicking ‘Attend?’, you agree that your profile could be shared with the 3rd party vendor for registration purposes.</p>',
                scope: $scope,
                buttons: [
                    {
                        text: 'Cancel',
                        onTap: function (e) {
                            Analytics.sendEvent("RSVP-prompt", "Accept", $scope.event.name, $scope.event.id);
                        }
                    },
                    {
                        text: '<b>OK</b>',
                        type: 'button-positive',
                        onTap: function (e) {
                            Analytics.sendEvent("RSVP-prompt", "Decline", $scope.event.name, $scope.event.id);
                            $scope.updateAttendance();
                        }
                    }
                ]
            });
            // myPopup.then(function(res) {
            //  console.log('Tapped!', res);
            //});
        };
        //eventrecurring array
        $scope.eventList = function (eid, chk) {
            if (chk == undefined)
                chk = false;
            if ($scope.recurringEventList.length > 0) {
                for (var b = 0; b < $scope.recurringEventList.length; b++) {
                    if ($scope.recurringEventList[b].id == eid) {
                        $scope.recurringEventList[b].isChecked = chk;
                    }
                }
            }
            if (event.id == eid) {
                event.isChecked = chk;

            }
        };
        $scope.attendArray = [];
        $scope.destroyArray = [];
        $scope.updateAttendance = function (bool) {
            $scope.attendArray = [];
            $scope.destroyArray = [];
            var attending = !$scope.event.attending;
            IonicUtilsService.showLoadingWithTitle('Updating attendance');
            if ($scope.recurringEventList.length > 0) {
                for (var i = 0; i < $scope.recurringEventList.length; i++) {
                    var present = false;
                    for (var j = 0; j < UserService.user.event_attendances.length; j++) {
                        if ($scope.recurringEventList[i].id == UserService.user.event_attendances[j].event_id) {
                            present = true;
                            break;
                        }
                    }
                    if (!present && ($scope.recurringEventList[i].isChecked == true)) {
                        $scope.attendArray.push($scope.recurringEventList[i].id);
                    }
                    else if (present && ($scope.recurringEventList[i].isChecked == false)) {
                        $scope.destroyArray.push($scope.recurringEventList[i].id);
                    }
                }
            }
            if ($scope.attendArray.length > 0) {
                UserService.attendEvent($scope.attendArray).then(function (response) {
                    if (response.success) {
                        //Upadating event attendances count
                        var index = $scope.attendArray.indexOf(event.id);
                        if (index != -1) {
                            $scope.event.event_attendances_count = response.event_attendances_count[index];
                        }
                        for (var x = 0; x < $scope.attendArray.length; x++) {
                            for (var y = 0; y < $scope.recurringEventList.length; y++) {
                                if ($scope.recurringEventList[y].id == $scope.attendArray[x]) {
                                    var indexArray = $scope.attendArray.indexOf($scope.attendArray[x]);
                                    if (indexArray != -1) {
                                        $scope.recurringEventList[y].event_attendances_count = response.event_attendances_count[indexArray];
                                    }
                                }
                            }
                        }
                        //updating the attended data to user Attandaces
                        for (var i = 0; i < $scope.attendArray.length; i++) {
                            UserService.user.event_attendances.push({ 'event_id': $scope.attendArray[i] });
                        }
                        attendingData();
                    }
                    else {
                        console.log("Error in Attend Events");
                    }
                });
            }

            if ($scope.destroyArray.length > 0) {
                UserService.unattendEvent($scope.destroyArray).then(function (response) {
                    if (response.success) {
                        //Updating event attendances count
                        var index = $scope.destroyArray.indexOf(event.id);
                        if (index != -1) {
                            $scope.event.event_attendances_count = response.event_attendances_count[index];
                        }
                        for (var x = 0; x < $scope.destroyArray.length; x++) {
                            for (var y = 0; y < $scope.recurringEventList.length; y++) {
                                if ($scope.recurringEventList[y].id == $scope.destroyArray[x]) {
                                    var indexArrayDel = $scope.destroyArray.indexOf($scope.destroyArray[x]);
                                    if (indexArrayDel != -1) {
                                        $scope.recurringEventList[y].event_attendances_count = response.event_attendances_count[indexArrayDel];
                                    }
                                }
                            }
                        }
                        //  Delete the event from the user's event attendances array
                        new_event_attendances = [];
                        for (var i = 0; i < UserService.user.event_attendances.length; i++) {
                            var presentData = false;
                            for (var j = 0; j < $scope.destroyArray.length; j++) {
                                if (!angular.isUndefinedOrNull(UserService.user.event_attendances[i].event_id) && UserService.user.event_attendances[i].event_id == $scope.destroyArray[j]) {
                                    presentData = true;
                                }
                            }
                            if (!presentData) {
                                new_event_attendances.push(UserService.user.event_attendances[i]);
                            }
                        }

                        UserService.user.event_attendances = new_event_attendances;
                        attendingData();
                    }
                    else {
                        console.log("Error in Destroy Events");
                    }
                });
            }
            IonicUtilsService.hideLoading();
            // attendingData();    
            // $state.go('event/'+ event.id);       
        }
        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.dpr = IonicUtilsService.getDevicePixelResolution();
            // Loop through user.event_attendances (as per announcements and deals)
            eventRecuring();
            attendingData();
            $scope.event.attending = UserService.isAttendingEventWithId($scope.event.id);
            $scope.eventIsFull = isEventFull();
        });
        $scope.addToCalendar = function () {
            // icsURL = "http://localhost:3000/api/v1/events/319";
            $scope.addCalendar = [];
            if ($scope.recurringEventList.length > 0) {
                for (var j = 0; j < $scope.recurringEventList.length; j++) {
                    for (var i = 0; i < UserService.user.event_attendances.length; i++) {
                        if ($scope.recurringEventList[j].id == UserService.user.event_attendances[i].event_id) {
                            $scope.addCalendar.push($scope.recurringEventList[j].id);
                            //var icsURL = $scope.recurringEventList[j].icalendar;
                            // window.location = icsURL;
                        }
                    }
                }
                console.log("inside recurring" + $scope.addCalendar);
            }
            if (!event.in_the_past) {
                for (var i = 0; i < UserService.user.event_attendances.length; i++) {
                    if (event.id == UserService.user.event_attendances[i].event_id) {
                        $scope.addCalendar.push(event.id);
                        //var icsURL = $scope.recurringEventList[j].icalendar;
                        // window.location = icsURL;
                    }
                }
            }
            var icsURL = window.location.protocol + "//" + window.location.host + "/api/v1/events/calendars?event_ids=" + $scope.addCalendar;
            $log.debug("Open ICS at: " + icsURL);
            window.location = icsURL;
        };
        $scope.groups = [];
        for (var i = 0; i < 1; i++) {
            $scope.groups[i] = {
                name: i,
                items: []
            };
            //for dropdown values starts
            for (var j = 0; j < 3; j++) {
                $scope.groups[i].items.push(i + "-" + j);
            }
            //dropdown value ends
        }
        /*
         * if given group is the selected group, deselect it
         * else, select the given group
         */
        $scope.toggleGroup = function (group) {
            if ($scope.isGroupShown(group)) {
                $scope.shownGroup = null;
            } else {
                $scope.shownGroup = group;
                $scope.actionHide = $scope.actionHide;
                $ionicScrollDelegate.resize();
            }
        };
        $scope.isGroupShown = function (group) {
            return $scope.shownGroup === group;
        };
        var eventRecuring = function () {

            //IonicUtilsService.showLoadingWithTitle('Loading events.....');
            $scope.recurringEventList = [];
            $scope.finaldata = [];
            UserService.recurEvent().then(function (response) {
                $scope.recurringDataList = response.data.events;
                    angular.forEach($scope.recurringDataList, function (event) {
                    event.isChecked = false;
                    if ($scope.event.id == event.id) {
                        // $scope.selectedData = [];
                        $scope.parentEvent = $scope.event.start_at;
                        $scope.parentID = $scope.event.id;
                        for (var k = 0; k < UserService.user.event_attendances.length; k++) {
                            if (UserService.user.event_attendances[k].event_id == event.id) {
                                //$scope.selectedData.push(event);
                                //console.log("Selected Data:" + $scope.selectedData);
                                event.isChecked = true;
                                k = UserService.user.event_attendances.length;
                                continue;
                            }
                            else {
                                event.isChecked = false;
                            }
                        }
                    if (event.events.length > 0) {
                        angular.forEach(event.events, function (recurEvents) {
                            //if ($scope.event.id == event.id) {
                                $scope.recurringEventList.push(recurEvents);
                                $scope.recurringEventList.isChecked = false;
                            //}
                        });
                        for (var j = 0; j < $scope.recurringEventList.length; j++) {
                            for (var i = 0; i < UserService.user.event_attendances.length; i++) {
                                if (UserService.user.event_attendances[i].event_id == $scope.recurringEventList[j].id)                               {
                                    $scope.recurringEventList[j].isChecked = true;
                                    i = UserService.user.event_attendances.length;
                                    continue;
                                }
                                else {
                                    $scope.recurringEventList[j].isChecked = false;
                                }
                            }
                        }
                        }
                        //merging parent and child events
                        $scope.finaldata = $scope.recurringEventList;
                        $scope.finaldata.push(event);
                        $ionicScrollDelegate.resize();
                        //console.log($scope.finaldata);
                        attendingData();
                    }
                });
            });
            //IonicUtilsService.hideLoading();
        };
        var attendingData = function () {
            //IonicUtilsService.showLoadingWithTitle('Loading....');
            $scope.selectedData = [];
            if ($scope.finaldata.length > 0) {
                //console.log(UserService.user.event_attendances);
                for (var j = 0; j < $scope.finaldata.length; j++) {
                    for (var i = 0; i < UserService.user.event_attendances.length; i++) {
                        if (UserService.user.event_attendances[i].event_id == $scope.finaldata[j].id) {
                            if($scope.selectedData.indexOf($scope.finaldata[j]) == -1) {
                                $scope.selectedData.push($scope.finaldata[j]);
                            }
                        }
                    }
                }
            //IonicUtilsService.hideLoading();
            }
        }
    }])

    .controller('vibrantLivingCtrl', ['$scope', '$stateParams', '$state', '$log', '$filter', '$timeout', '$ionicModal',
        '$ionicPopover', 'BuildingService', 'UserService', 'IonicUtilsService', 'VendorSortFilterService', 'Analytics',
        function ($scope, $stateParams, $state, $log, $filter, $timeout, $ionicModal, $ionicPopover, BuildingService,
            UserService, IonicUtilsService, VendorSortFilterService, Analytics) {

            $scope.showInformation = function (bool) {
                if (bool) {
                    $ionicModal.fromTemplateUrl('templates/partials/vibrant-living-modal.html', {
                        scope: $scope,
                        animation: 'slide-in-up'//animation types https://forum.ionicframework.com/t/modal-animations/449/9
                    }).then(function (modal) {
                        $scope.modal = modal;
                        $scope.modal.show();
                    });
                } else if (angular.isDefined($scope.modal)) {
                    $scope.modal.hide();
                }
            };

            //Setup popover
            $ionicPopover.fromTemplateUrl('templates/partials/events-filter-popover.html', {
                scope: $scope
            }).then(function (popover) {
                $scope.popover = popover;
            });

            $scope.openPopover = function ($event) {
                $scope.popover.show($event);
            };

            $scope.closePopover = function () {
                $scope.popover.hide();
            };

            $scope.sortBy = function (fieldSortStr) {
                Analytics.sendEvent("Deals&Events", "SortBy", fieldSortStr, 'NA');
                $scope.orderByValue = fieldSortStr;//A-z = "name"
                VendorSortFilterService.setOrderByValue(fieldSortStr);
                $timeout(function () {
                    $scope.closePopover();
                }, 500);
            };

            // Cleanup the modal and popup when we're done with it!
            $scope.$on('$destroy', function () {
                if (angular.isDefined($scope.modal)) {
                    $scope.modal.remove();
                }

                if (angular.isDefined($scope.popover)) {
                    $scope.popover.remove();
                }
            });

            //$scope.$on('$ionicView.beforeEnter', function () {
            //    var contentArr = BuildingService.selectedBuilding.contents.filter(function (content) {
            //        return (content.identifier == 'vibrant_living');
            //    });
            //
            //    if(contentArr.length > 0){
            //        $scope.vlContent = contentArr[0];
            //    }
            //
            //    $scope.vlEvents = BuildingService.selectedBuilding.events.filter(function (event) {
            //        return (event.type == 'vibrant_living');
            //    });
            //
            //    $scope.vlDeals = BuildingService.selectedBuilding.deals.filter(function (deal) {
            //        return (deal.type == 'vibrant_living');
            //    });
            //
            //    //Show information on first run
            //    if(!window.localStorage['haveShownInformation']){
            //        window.localStorage['haveShownInformation'] = true;
            //        $scope.showInformation(true);
            //    }
            //    //Default sort by date
            //    $scope.orderByValue = 'start_at';
            //
            //    $log.debug("VL has " + $scope.vlDeals.length + " deals");
            //    $log.debug($scope.vlDeals);
            //
            //});

            $scope.onSelectTab = function (showDeals) {
                $scope.showDeals = !showDeals;
                $scope.items = showDeals ? $scope.deals : $scope.events;
            };

            $scope.showItem = function (item) {
                var stateName = $scope.showDeals ? 'event' : 'deal';
                $state.go(stateName, { 'id': item.id });
            };

            $scope.$on('$ionicView.beforeEnter', function () {

                var contentArr = BuildingService.selectedBuilding.contents.filter(function (content) {
                    return (content.identifier == 'vibrant_living');
                });

                if (contentArr.length > 0) {
                    $scope.vlContent = contentArr[0];
                    $scope.dpr = IonicUtilsService.getDevicePixelResolution();
                }

                //Marks all deals as redeemed or not
                UserService.updateDealsState();

                //Mark all events as attended or not
                UserService.updateEventAttendingState();

                $scope.deals = BuildingService.selectedBuilding.deals;
                $scope.events = BuildingService.selectedBuilding.events;

                //Check for event attending status from backend and update object
                angular.forEach($scope.events,function (event, index) {
                    UserService.isAttendingEventRecurring(event.id).then(function (response) {
                        //console.log(response);
                        $scope.events[index]["eventattending"] = response.is_attending;
                    })
                })

                //selectedTab is optionally passed through $state
                var tabToSelect = $stateParams.selectedTab == 'deals' ? true : false;
                $scope.onSelectTab(tabToSelect);

                //Show information on first run
                if (!window.localStorage['haveShownInformation']) {
                    window.localStorage['haveShownInformation'] = true;
                    $scope.showInformation(true);
                }
                //Default sort by date
                $scope.orderByValue = 'name';

                $scope.buildingId = BuildingService.selectedBuilding.id;
                $scope.campaign_name = BuildingService.selectedBuilding.campaign_name;
            });

        }])

    .controller('parkingCtrl', ['$scope', '$stateParams', '$sce', '$log', '$window', 'BuildingService', 'IonicUtilsService', function ($scope, $stateParams, $sce, $log, $window, BuildingService, IonicUtilsService) {

        $scope.getDirections = function () {
            IonicUtilsService.showExternalLinkPrompt($scope.directionsURL, 'Google Maps');
        };

        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.local_transport = $sce.trustAsHtml(BuildingService.selectedBuilding.local_transport);
            $scope.parking_nearby = $sce.trustAsHtml(BuildingService.selectedBuilding.parking_nearby);
            $scope.parking_onsite = $sce.trustAsHtml(BuildingService.selectedBuilding.parking_onsite);
            $scope.parking_bikeracks = $sce.trustAsHtml(BuildingService.selectedBuilding.parking_bikeracks);
            $scope.parking_carcharging = $sce.trustAsHtml(BuildingService.selectedBuilding.parking_carcharging);
            $scope.gMapsStaticURI = BuildingService.getGoogleStaticMapURI();
            $scope.building = BuildingService.selectedBuilding;
            $scope.directionsURL = BuildingService.getBuildingAddressForGMapsAPI();
        });
    }])


    //ponits ertail gamification starts


    .controller('GameScorePageCtrl', ['$scope', '$filter', '$state', '$stateParams', function ($scope, $filter, $state, $stateParams) {

    }])

    //ends
    .controller('diningCtrl', ['$scope', '$stateParams', '$filter', 'BuildingService', 'IonicUtilsService', function ($scope, $stateParams, $filter, BuildingService, IonicUtilsService) {

        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.internalVendors = BuildingService.getInternalVendors();
            $scope.dpr = IonicUtilsService.getDevicePixelResolution();
        });

    }])

    .controller('taxicabsCtrl', ['$scope', '$stateParams', 'BuildingService', function ($scope, $stateParams, BuildingService) {

        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.taxicabs = BuildingService.selectedBuilding.taxicabs;
        });

    }])

    .controller('announcementsCtrl', ['$scope', '$stateParams', '$log', 'AnnouncementsService', 'UserService', 'BuildingService', function ($scope, $stateParams, $log, AnnouncementsService, UserService, BuildingService) {

        $scope.$on('$ionicView.beforeEnter', function () {
            AnnouncementsService.getUnReadCount();//this also updates announcements with 'read flag'
            $scope.announcements = BuildingService.selectedBuilding.announcements;
        });

        $scope.doRefresh = function () {

            /* Commented out as not in use
             UserService.refreshUserAndBuilding()
             .then(function(response) {
             $log.debug(response);
             $scope.announcements = BuildingService.selectedBuilding.announcements;
             AnnouncementsService.getUnReadCount();//this also updates announcements with 'read flag'
             }, function(error) {
             $log.error(error)
             })
             .finally(function() {
             // Stop the ion-refresher from spinning
             $scope.$broadcast('scroll.refreshComplete');
             })*/
        };

    }])

    .controller('announcementCtrl', ['$scope', '$stateParams', '$timeout', '$log', 'announcement', 'AnnouncementsService', 'IonicUtilsService', 'UserService', 'APP_CONFIG', function ($scope, $stateParams, $timeout, $log, announcement, AnnouncementsService, IonicUtilsService, UserService, APP_CONFIG) {

        $scope.announcement = announcement;

        $scope.$on('$ionicView.beforeEnter', function () {

            if (!$scope.announcement.read) {
                // IonicUtilsService.showLoadingWithTitle('Updating read status');

                AnnouncementsService.markAnnouncementAsRead($scope.announcement).then(function () {
                    $timeout(function () {
                        // IonicUtilsService.hideLoading();
                        $log.debug('Success: updated announcement as being viewed.');
                    }, APP_CONFIG.GRACE_PERIOD_MS);
                });

                // FIXME: The announcement view PUT should be decoupled from this action
                UserService.user.announcement_views.push($scope.announcement.id);
            }
        });

    }]);


//Watch
//http://ionicframework.com/docs/api/directive/ionNavView/
//If you don't want to disable caching (cache-view="false"), but want specific code to be called each time a view is entered, you can use this in your controller:
/*
 Ionic View Events

 $ionicView.loaded --> The view has loaded. This event only happens once per view being created and added to the DOM. If a view leaves but
 is cached, then this event will not fire again on a subsequent viewing. The loaded event is good place to put your setup
 code for the view; however, it is not the recommended event to listen to when a view becomes active.

 $ionicView.enter --> The view has fully entered and is now the active view.
 This event will fire, whether it was the first load or a cached view.

 $ionicView.leave --> The view has finished leaving and is no longer the
 active view. This event will fire, whether it is cached or destroyed.

 $ionicView.beforeEnter --> The view is about to enter and become the active view.

 $ionicView.beforeLeave --> The view is about to leave and no longer be the active view.

 $ionicView.afterEnter --> The view has fully entered and is now the active view.

 $ionicView.afterLeave --> The view has finished leaving and is no longer the active view.

 $ionicView.unloaded --> The view’s controller has been destroyed, and its element has been
 removed from the DOM.

 */
