/**
 * My P&G Office - Directives
 */

angular.module('app.directives', [])
    /**
     * Simple copyright directive to display
     * © 2015
     */
    .directive('copyright', [function () {
        return {
            restrict: 'E', //E = element, A = attribute, C = class, M = comment
            template: '<span>&copy; {{year}}</span>',
            link: function (scope, element, attrs) {
                scope.year = new Date().getFullYear();
            }
        }
    }])

    /**
     * CSS Background Image
     * **/
    .directive('backgroundImage', [function(){
        return function(scope, element, attrs){
            attrs.$observe('backgroundImage', function(url) {
                element.css({
                    'background-image': 'url("' + url +'")',
                    'background-size' : 'cover',
                    'background-position': '50% 50%',
                    'background-repeat' : 'no-repeat'
                });
            });
        };
    }])

/* * Preview the image in Service Ticket

 */
    .directive("fileinput", [function() {
        return {
            scope: {
                fileinput: "=",
                filepreview: "="
            },
            link: function(scope, element, attributes) {
                element.bind("change", function(changeEvent) {
                    scope.fileinput = changeEvent.target.files[0];
                    var reader = new FileReader();
                    reader.onload = function(loadEvent) {
                        scope.$apply(function() {
                            scope.filepreview = loadEvent.target.result;
                        });
                    }
                    reader.readAsDataURL(scope.fileinput);
                });
            }
        }
    }]);

/*.directive('toggleClass', [function () {

    return {
        restrict: 'A',
        controller: 'eventCtrl',

        link: function (scope, element) {
            element.click(function () {
                if (element.attr('ng-empty') === 'ng-not-empty') {
                    angular.element(element).addClass('ng-not-empty');
                } else {
                    angular.element(element).removeClass('ng-not-empty');

                }
            });
        }
    };

}]);*/


