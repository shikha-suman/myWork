angular.module('homeRedesign.controllers', [])

    .controller('homeRedesignCtrl', ['$window', '$scope', '$ionicPlatform', '$stateParams', '$state', '$log', '$timeout', '$ionicPopover', '$ionicHistory',
        '$ionicModal', '$ionicLoading', 'BuildingService', 'AnnouncementsService', 'MenuButtonService', 'WeatherIconService',
        'UserService', 'IonicUtilsService', 'DealsAndEventsTabService', 'pgSensingService', 'pgAskService',
        'serviceRequestService', 'openChallengesService', 'APP_CONFIG', 'Analytics',
        function ($window, $scope, $ionicPlatform, $stateParams, $state, $log, $timeout, $ionicPopover, $ionicHistory, $ionicModal, $ionicLoading,
                  BuildingService, AnnouncementsService, MenuButtonService, WeatherIconService, UserService,
                  IonicUtilsService, DealsAndEventsTabService, pgSensingService, pgAskService, serviceRequestService,
                  openChallengesService, APP_CONFIG, Analytics) {
            $scope.homeSlides = [
                {
                    name: 'pgAsk',
                    shouldShow: false,
                    template: 'templates/partials/home.ask.html'
                }, {
                    name: 'serviceRequests',
                    shouldShow: false,
                    template: 'templates/partials/home.assistance.html'
                }, {
                    name: 'GameHomePage',
                    shouldShow: false,
                    template: 'templates/partials/home.challenge.html'
                }, {
                    name: 'deals',
                    shouldShow: false,
                    template: 'templates/partials/home.deals.html'
                }, {
                    name: 'events',
                    shouldShow: false,
                    template: 'templates/partials/home.events.html'
                }
            ];
            $scope.shouldShowChallenges = false;
            $scope.shouldShowDeals = false;
            $scope.shouldShowEvents = false;
            $scope.shouldShowAssistance = false;
            $scope.shouldShowAsk = false;
            $scope.sendGAFeedbackIntent = function () {
                Analytics.sendEvent("Menu Controls", "Feedback intent", UserService.user.buildings[0].name, UserService.user.building_id);
            };
            function getWeatherMessage() {

                if (angular.isUndefined($scope.building) || $scope.building.weather.cod != "200") {
                    return "";
                }

                try {
                    return $scope.building.city + ", " + parseInt($scope.building.weather.list[0].main.temp) + "°, " + $scope.building.weather.list[0].weather[0].description;
                } catch (e) {
                    $log.warn("error returning getWeatherMessage()");
                }
            };

            /* Unused now but will get a PNG icon from API */
            function getWeatherIconURL() {
                if (angular.isUndefined($scope.building) || $scope.building.weather.cod != "200") {
                    return "";
                }
                return "https://openweathermap.org/img/w/" + $scope.building.weather.list[0].weather[0].icon + ".png";//"01n"
            };

            function getWeatherIconClass() {
                var iconClass = '';
                try {
                    var iconCode = $scope.building.weather.list[0].weather[0].icon;
                    iconClass = WeatherIconService.getIconClassNameByWeatherCode(iconCode);
                } catch (e) {
                    $log.warn("error returning getWeatherIconClass()");
                }
                return iconClass;
            };

            // $ionicPopover.fromTemplateUrl('templates/partials/home-popover.html', {
            //     scope: $scope
            // }).then(function (popover) {
            //     $scope.popover = popover;
            // });
            $ionicPopover.fromTemplateUrl('templates/partials/homemenu.html', {
                scope: $scope
            }).then(function (popover) {
                $scope.popover = popover;
            });

            $scope.openHomePopover = function ($event) {
                $scope.popover.show($event);
            };

            $scope.closePopover = function () {
                if (angular.isDefined($scope.popover)) {
                    $scope.popover.hide();
                }
            };

            $scope.popoverGotoView = function (path, arg) {
                $scope.popover.hide();
                $state.go(path, arg);
            };

            /**
             * Broken this out from ui-sref so we can check number of records
             * and jump straight to detail state if only one exists
             * @param stateName
             */
            $scope.navigateTo = function (stateName) {
                if (angular.isDefined($scope.popover)) {
                    $scope.popover.hide();
                }
                //TODO: How do we do this for all subscreens cleanly?
                if (stateName == 'dining') {
                    var internalVendors = BuildingService.getInternalVendors();
                    if (internalVendors.length == 1) {
                        $state.go("vendorDetail", {id: internalVendors[0].id});
                        return;
                    }
                }
                if (stateName === 'pgSensing')
                    Analytics.sendEvent("Menu Controls", "PG-sensing-intent", UserService.user.buildings[0].name, UserService.user.building_id);
                else if (stateName === 'roomFinder')
                    Analytics.sendEvent("Menu Controls", "Feedback intent", UserService.user.buildings[0].name, UserService.user.building_id);
                else if (stateName === 'concur')
                    Analytics.sendEvent("Menu Controls", "Find a Room", UserService.user.buildings[0].name, UserService.user.building_id);
                $state.go(stateName);
            };

            //Cleanup the popover when we're done with it!
            $scope.$on('$destroy', function () {
                $scope.popover.remove();
            });

            $scope.showOnboarding = function (forceOpen) {

                $log.debug('Do onboarding? ' + UserService.isOnboardingComplete());

                if (UserService.isOnboardingComplete()) {
                    return;
                }

                // using the $ionicHistory to hide the back button on next view - http://ionicframework.com/docs/nightly/api/service/$ionicHistory/
                $ionicHistory.nextViewOptions({
                    disableAnimate: false,
                    disableBack: true
                });

                $state.go('onboarding');
            };

            $scope.updateWeather = function () {
                $scope.weatherMessage = getWeatherMessage();
                $scope.weatherIconClass = getWeatherIconClass();
            };

            $scope.$on('$ionicView.loaded', function () {
                //$scope.welcomeMessage = WelcomeMessageService.getMessage();
                $scope.checkPopupSeen();
            });

            //This event is emitted when the slider is initialized. It provides access to an instance of the slider.
            $scope.$on("$ionicSlides.sliderInitialized", function (event, data) {
                // grab an instance of the slider
                $scope.slider = data.slider;
            });

            $scope.setSlide = function (slideName, isVisible) {
                $scope.homeSlides.forEach(function (slide) {
                    if (slide.name === slideName) {
                        slide.shouldShow = isVisible;
                    }
                })
            };

            $scope.$on('$ionicView.beforeEnter', function () {


                $log.debug("HomeCtrl $ionicView.beforeEnter");
                $scope.menuButtons = MenuButtonService.init();
                var facilitiesAssistance = false;
                var pgAsk = false;
                var vibrantLiving = false;
                $scope.pgSensing = false;
                var GameHomePage = false;
                var order = [];
                $scope.menuButtons.forEach(function (menuButton) {
                    if (menuButton.state === 'serviceRequests') {
                        order.push('serviceRequests');
                        facilitiesAssistance = true;
                    }
                    if (menuButton.state === 'pgAsk') {
                        pgAsk = true;
                        order.push('pgAsk')
                    }
                    if (menuButton.state === 'vibrantLiving') {
                        vibrantLiving = true;
                        order.push('deals');
                        order.push('events');
                    }
                    if (menuButton.state === 'GameHomePage') {
                        GameHomePage = true;
                        order.push('GameHomePage')
                    }
                    if (menuButton.state === 'pgSensing')
                        $scope.pgSensing = true;
                });
                $scope.homeSlides.sort(function (a, b) {
                    return order.indexOf(a.name) - order.indexOf(b.name);
                });
                if (facilitiesAssistance)
                    $scope.setSlide('serviceRequests', true);
                else
                    $scope.setSlide('serviceRequests', false);
                if (pgAsk)
                    $scope.setSlide('pgAsk', true);
                else
                    $scope.setSlide('pgAsk', false);
                $scope.building = BuildingService.selectedBuilding;
                $scope.buildings = BuildingService.buildings;
                $scope.numNotifications = AnnouncementsService.getUnReadCount();
                $scope.updateWeather();
                $scope.showOnboarding();
                $scope.checkProfileUpdated();
                $scope.buildingHeroImageUrl = $scope.building['hero_image_x' + IonicUtilsService.getDevicePixelResolution()];
                $scope.deals = BuildingService.selectedBuilding.deals;
                //Marks all deals as redeemed or not
                UserService.updateDealsState();
                //Mark all events as attended or not
                //UserService.updateEventAttendingState();

                var isdealavail = false;
                var $scopedeals = $scope.deals;
                    for (var i = 0, len = $scopedeals.length; i < len; i++) {
                        if (!$scopedeals[i].redeemed) {
                            isdealavail = true;
                            break;
                        }
                    }
                if ($scope.deals && $scope.deals.length && vibrantLiving && isdealavail) {
                    $scope.setSlide('deals', true);
                    var rankedDeals = [];
                    angular.forEach($scope.deals, function (item) {
                        if(!item.redeemed) {
                            rankedDeals.push({
                                item: item,
                                rank: 0.5 - $window.Math.random()
                            });
                        }
                    });
                    $scope.deals = rankedDeals;
                }
                else
                    $scope.setSlide('deals', false);
                $scope.events = BuildingService.selectedBuilding.events;
                if ($scope.events && $scope.events.length && vibrantLiving) {
                    $scope.setSlide('events', true);
                    var rankedEvents = [];
                    angular.forEach($scope.events, function (item) {
                        rankedEvents.push({
                            item: item,
                            rank: 0.5 - $window.Math.random()
                        });
                    });
                    $scope.events = rankedEvents;
                }
                else
                    $scope.setSlide('events', false);
                serviceRequestService.populateServiceTickets().then(function (response) {
                    var ServiceTickets = response.data;
                    $scope.service_list = ServiceTickets.service_requests;
                    if (!$scope.service_list) {
                        $scope.service_list = []
                    }
                });
                if (GameHomePage) {
                    openChallengesService.openChallenges().then(function (response) {
                        $scope.openChallenges = response.data.challenges;
                        if ($scope.openChallenges && $scope.openChallenges.length) {
                            $scope.setSlide('GameHomePage', true);
                        }
                        $scope.openChallengesPoints = response.data.points;
                        $scope.redeem = $scope.openChallengesPoints.redeem;
                        $scope.total = $scope.openChallengesPoints.total;
                        if ($scope.redeem == null) {
                            $scope.redeem = 0;
                        }
                        if ($scope.total == null) {
                            $scope.total = 0;
                        }
                        $scope.redeemable = $scope.total + $scope.redeem;
                    });
                }
                else {
                    $scope.setSlide('GameHomePage', false);
                }
            });

            $scope.checkPopupSeen = function () {
              // console.log("This is popup seen",UserService.user.popup_seen);
               if(UserService.user.popup_seen == false){
                //   console.log('inside');
                    var templateURL, modalName;

                templateURL = 'templates/partials/user-popup-seen.html';
                $scope.data = {
                    name: UserService.user.first_name,
                    building: UserService.user.buildings[0].name
                }

                $ionicModal.fromTemplateUrl(templateURL, {
                    scope: $scope,
                    animation: 'slide-in-up meetup-feedback meetup-survey-modal'
                }).then(function (modal) {
                    $scope.modal3 = modal;
                    $scope.modal3.show();
                });

               }
            }

            $scope.PopupSeen = function (){
                
                if (angular.isDefined($scope.modal3)) {
                    $scope.modal3.hide();
                }
                UserService.popup_mark_seen();
            }

            $scope.checkPendingSurveys = function () {
                pgSensingService.getAllSurveys().then(function (response) {
                    var pendingSurveys = response;
                    var menuButtons = [];
                    $scope.surveyLength = pendingSurveys.push.length + pendingSurveys.generic.length;
                    // $scope.menuButtons.forEach(function (menuButton) {
                    //     if (menuButton.state !== "pgSensing") {
                    //         menuButtons.push(menuButton)
                    //     }
                    //     else {
                    //         if ($scope.surveyLength) {
                    //             menuButtons.push(menuButton)
                    //         }
                    //     }
                    // });
                    // $scope.menuButtons = menuButtons;
                    if (pendingSurveys.push.length)
                        $scope.showPendingSurveys(true, pendingSurveys.push[0]);
                    else if (APP_CONFIG.SHOW_PENDING_SURVEY && pendingSurveys.generic.length)
                        $scope.showPendingSurveys(false, pendingSurveys.generic[0].id);
                });
            };

            $scope.$on('$ionicView.enter', function () {
                SplashScreen.fadeAfterDelay();
                DealsAndEventsTabService.resetDefaultTab();//reset the tabs in service so when we navigate to deals & events we get the default tab
            });

            //See API: http://idangero.us/swiper/api/#.WBDUvOErLKk
            $scope.sliderOptions = {
                loop: false,
                effect: 'slide',
                coverflow: {
                    slideShadows: false
                },
                speed: 500, //animation speed
                paginationClickable: true,//allow user to click on pagination
                //pagination: false, //this turn pagination off if included regardless of value?!
                grabCursor: true
            };
            $scope.checkProfileUpdated = function () {
                if (!UserService.isMobileNumberUpdated()) {
                    $scope.updateProfile();
                }
                else {
                    if ($scope.pgSensing)
                        $scope.checkPendingSurveys();
                }

            }
            $scope.updateProfile = function () {

                var templateURL, modalName;

                templateURL = 'templates/partials/update-mobile.html';
                modalName = "building-selection";
                $scope.data = {
                    message: null,
                    success: null
                }

                $ionicModal.fromTemplateUrl(templateURL, {
                    backdropClickToClose: false,
                    hardwareBackButtonClose: false,
                    scope: $scope,
                    animation: 'slide-in-up' //animation types https://forum.ionicframework.com/t/modal-animations/449/9
                }).then(function (modal) {
                    $scope.modal = modal;
                    $scope.modal.show();
                });

            };

            $scope.showPendingSurveys = function (hasPushedSurvey, surveyId) {

                var templateURL, modalName;

                templateURL = 'templates/partials/pending-surveys.html';
                $scope.data = {
                    name: UserService.user.first_name,
                    hasPushedSurvey: hasPushedSurvey,
                    surveyId: surveyId
                }

                $ionicModal.fromTemplateUrl(templateURL, {
                    backdropClickToClose: false,
                    hardwareBackButtonClose: false,
                    scope: $scope,
                    animation: 'slide-in-up meetup-feedback meetup-survey-modal'
                }).then(function (modal) {
                    $scope.modal2 = modal;
                    $scope.modal2.show();
                });

            };
            $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
                if (fromState.name === "homeRedesign" && toState.name === "splash") {
                    event.preventDefault();
                }
                if (angular.isDefined($scope.modal)) {
                    $scope.modal.remove();
                }
                if (angular.isDefined($scope.modal2)) {
                    $scope.modal2.remove();
                }
                if (angular.isDefined($scope.popover)) {
                    $scope.popover.hide();
                }
            });
            $scope.takeSurvey = function (surveyId, hasPushedSurvey) {
                Analytics.sendEvent("PG Sensing", 'Take a Survey intent', UserService.user.buildings[0].name, UserService.user.building_id);
                $scope.modal2.hide();
                if (hasPushedSurvey)
                    $state.go('surveyDetail', {surveyId: surveyId});
                else {
                    $state.go('pgSensing');
                }
            };

            $scope.ignoreSurvey = function () {
                APP_CONFIG.SHOW_PENDING_SURVEY = false;
                $scope.closeModal2();
            };

            $scope.closeModal = function () {
                if (angular.isDefined($scope.modal)) {
                    $scope.modal.hide();
                }
            };
            $scope.closeModal2 = function () {
                if (angular.isDefined($scope.modal2)) {
                    $scope.modal2.hide();
                }
            };
            $scope.updateMobile = function (telephone, subscribe) {
                $log.debug('updateMobile ' + telephone);
                IonicUtilsService.showLoadingWithTitle('Updating Mobile number');

                UserService.updateMobileNumber(telephone, subscribe).then(function (response) {
                    IonicUtilsService.hideLoading();

                    $scope.data.message = response.message;
                    $scope.data.success = response.success;

                    $timeout(function () {

                        if (response.success) {
                            $scope.modal.hide();
                            if ($scope.pgSensing)
                                $scope.checkPendingSurveys();
                        }

                    }, 1000);

                });
            };
            $scope.joinEvent = function () {
                Analytics.sendEvent("PG Ask", 'Join event', 'NA', 'NA');
                var key = document.getElementById('PgAskHome-input1-home').value.toUpperCase();
                if (key && key !== "") {
                    IonicUtilsService.showLoadingWithTitle('Loading...');
                    pgAskService.joinEvent(key).then(function (response) {
                        IonicUtilsService.hideLoading();
                        if (response.message) {
                            $ionicLoading.show({
                                template: "Error occured: <br>" + response.message,
                                noBackdrop: true,
                                duration: 2000
                            });
                        }
                        else if (response.meetup) {
                            $state.go('meetupDetail', {id: response.meetup.id, meetupDetails: response, key: key})
                        }
                    })
                }
            };

        }]);
