angular.module('homeRedesign', ['homeRedesign.controllers']);
