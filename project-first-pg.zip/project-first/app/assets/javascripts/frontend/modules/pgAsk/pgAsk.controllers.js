angular.module('pgAsk.controllers', [])
//PG ASK controller starts

    .controller('PgAskHomeCtrl', ['$rootScope', '$scope', '$filter', '$state', '$ionicHistory', '$ionicLoading', 'pgAskService', 'IonicUtilsService', 'Analytics',
        function ($rootScope, $scope, $filter, $state, $ionicHistory, $ionicLoading, pgAskService, IonicUtilsService, Analytics) {
            document.getElementById('PgAskHome-input1-main').value = "";
            $scope.joinEvent = function () {
                Analytics.sendEvent("PG Ask", 'Join event', 'NA', 'NA');
                var key = document.getElementById('PgAskHome-input1-main').value.toUpperCase();
                if (key && key !== "") {
                    IonicUtilsService.showLoadingWithTitle('Loading...');
                    pgAskService.joinEvent(key).then(function (response) {
                        IonicUtilsService.hideLoading();
                        if (response.message) {
                            $ionicLoading.show({
                                template: "Error occured: <br>" + response.message,
                                noBackdrop: true,
                                duration: 2000
                            });
                        }
                        else if (response.meetup) {
                            $state.go('meetupDetail', {id: response.meetup.id, meetupDetails: response, key: key})
                        }
                    })
                }
            };
            $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
                if (toState.resolve) {
                    IonicUtilsService.showLoadingWithTitle('Loading...');
                }
            });
            $scope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
                if (toState.resolve) {
                    IonicUtilsService.hideLoading();
                }
            });
            $scope.getZoneTime = function (date, timezone) {
                var zoneDate = new Date(date);
                var value = timezone.slice(1).split('.');
                if (timezone[0] === '+') {
                    zoneDate.setHours(zoneDate.getHours() - parseInt(value[0]));
                    zoneDate.setMinutes(zoneDate.getMinutes() - parseInt(value[1]));
                }
                else if (timezone[0] === '-') {
                    zoneDate.setHours(zoneDate.getHours() + parseInt(value[0]));
                    zoneDate.setMinutes(zoneDate.getMinutes() + parseInt(value[1]));
                }
                return zoneDate
            };
            $scope.$on('$ionicView.beforeEnter', function () {
                if (!$scope.created_meetups)
                    IonicUtilsService.showLoadingWithTitle('Loading Events');
                pgAskService.getAllMeetups().then(function (response) {
                    $scope.showNoAsk = true;
                    IonicUtilsService.hideLoading();
                    $scope.attended_meetups = [];
                    response.allMeetups.attended_meetups.map(function (meetup) {
                        if (meetup) {
                            meetup.start_at = $scope.getZoneTime(meetup.start_at, meetup.time_zone);
                            meetup.end_at = $scope.getZoneTime(meetup.end_at, meetup.time_zone);
                            $scope.attended_meetups.push(meetup)
                        }
                    });

                    $scope.created_meetups = [];
                    response.allMeetups.created_meetups.map(function (meetup) {
                        if (meetup) {
                            meetup.start_at = $scope.getZoneTime(meetup.start_at, meetup.time_zone);
                            meetup.end_at = $scope.getZoneTime(meetup.end_at, meetup.time_zone);
                            $scope.created_meetups.push(meetup)
                        }

                    });

                    $scope.CurrentDate = new Date();
                    $scope.ongoingMeetups = [];
                    $scope.created_meetups.map(function (meetup) {
                        if ($scope.CurrentDate > Date.parse(meetup.start_at) && $scope.CurrentDate < Date.parse(meetup.end_at)) {
                            meetup.event_type = 'ongoing';
                            $scope.ongoingMeetups.push(meetup)
                        }
                    });
                    $scope.upcomingMeetups = [];
                    $scope.created_meetups.map(function (meetup) {
                        if ($scope.CurrentDate < Date.parse(meetup.start_at)) {
                            meetup.event_type = 'upcoming';
                            $scope.upcomingMeetups.push(meetup)
                        }
                    });
                    $scope.combinedMeetup = $scope.upcomingMeetups.concat($scope.ongoingMeetups);
                    $scope.pastMeetups = [];
                    $scope.created_meetups.map(function (meetup) {
                        if ($scope.CurrentDate > Date.parse(meetup.start_at) && $scope.CurrentDate > Date.parse(meetup.end_at)) {
                            $scope.pastMeetups.push(meetup)
                        }
                    })

                });
                if ($ionicHistory && $ionicHistory.forwardView() &&
                    $ionicHistory.forwardView().stateId.split('type=').length === 2 &&
                    ($ionicHistory.forwardView().stateId.split('type=')[1] === "past" ||
                    $ionicHistory.forwardView().stateId.split('type=')[1] === "ongoing" ||
                    $ionicHistory.forwardView().stateId.split('type=')[1] === "upcoming")) {
                    $state.go('pgAsk.created');
                }
                else
                    $state.go('pgAsk.attended');
            });

            $scope.redirectCreate = function () {
                Analytics.sendEvent("PG Ask", 'Create event intent', 'NA', 'NA');
                $state.go("create-meetup");
            };
            $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {

                if (angular.isDefined($rootScope.modalCtrl)) {
                    $rootScope.modalCtrl.remove();
                }

                if (angular.isDefined($scope.confirmPopup)) {
                    $scope.confirmPopup.close();
                }
                var msie = document.documentMode;
                if (!msie) {
                    if (fromState.name === "pgAsk.created" && toState.name === "pgAsk" ||
                        fromState.name === "pgAsk.attended" && toState.name === "pgAsk") {
                        event.preventDefault();
                        $state.go('homeRedesign');
                    }
                }
            });

        }])

    .controller('MeetupDetailCtrl', ['$document', '$window', '$rootScope', '$scope', '$filter', '$state', '$ionicHistory', '$ionicPopup', '$ionicModal',
        '$stateParams', '$interval', '$ionicScrollDelegate', 'pgAskService', 'IonicUtilsService', 'meetup', 'Analytics',
        function ($document, $window, $rootScope, $scope, $filter, $state, $ionicHistory, $ionicPopup, $ionicModal, $stateParams, $interval,
                  $ionicScrollDelegate, pgAskService, IonicUtilsService, meetupDetail, Analytics) {
            $scope.fields = {
                'question': ''
            };
            $scope.question = {
                Fixed: false
            };
            $scope.showLikeLoading = {};
            $scope.eventEnded = false;
            $scope.pauseInterval = 0;
            $scope.showBlockLoading = {};
            $scope.eventEndedMsg = "";
            $scope.invalidateRefresh = false;
            $scope.eventEndedMsgs = ["This event has ended - no more questions can be answered at this time.",
                "This event has ended - no more questions can be raised at this time."];
            $scope.hasAskedQuestion = false;
            $scope.getScrollPosition = function () {

                var scrollTop = $ionicScrollDelegate.$getByHandle('mainScroll').getScrollPosition().top;
                if ($scope.joined && !$scope.is_organizer) {

                    if (scrollTop > 20) {

                        $scope.question.Fixed = true;
                    }
                    else {
                        $scope.question.Fixed = false;
                    }
                }

                $scope.$apply()
            };
            var refreshQuestions;
            $scope.stopRefreshQuestions = function () {
                if (angular.isDefined(refreshQuestions)) {
                    $interval.cancel(refreshQuestions);
                    refreshQuestions = undefined;
                }
            };
            $scope.getDiffDays = function () {
                var oneDay = 24 * 60 * 60 * 1000;
                var endDate = new Date($scope.meetup.end_at);
                var currentDate = new Date();
                return Math.round(Math.abs((currentDate.getTime() - endDate.getTime()) / (oneDay)));
            };
            $scope.getZoneTime = function (date, timezone) {
                var zoneDate = new Date(date);
                var value = timezone.slice(1).split('.');
                if (timezone[0] === '+') {
                    zoneDate.setHours(zoneDate.getHours() - parseInt(value[0]));
                    zoneDate.setMinutes(zoneDate.getMinutes() - parseInt(value[1]));
                }
                else if (timezone[0] === '-') {
                    zoneDate.setHours(zoneDate.getHours() + parseInt(value[0]));
                    zoneDate.setMinutes(zoneDate.getMinutes() + parseInt(value[1]));
                }
                return zoneDate
            };
            $scope.refreshQuestions = function () {
                refreshQuestions = $interval(function () {
                    if (!$scope.pauseInterval && !$scope.refreshInProgress) {
                        if ($scope.joined && $scope.type) {
                            $scope.refreshInProgress = true;
                            pgAskService.joinEvent($scope.key).then(function (response) {
                                $scope.refreshInProgress = false;
                                if (!$scope.pauseInterval) {
                                    if (!$scope.invalidateRefresh) {
                                        if (response.meetup) {
                                            $scope.meetup = response.meetup;
                                            $scope.setVotes();
                                        }
                                    }
                                    $scope.invalidateRefresh = false;
                                }
                            });
                        }
                        else {
                            $scope.refreshInProgress = true;
                            pgAskService.getMeetupById($scope.meetup.id).then(function (response) {
                                $scope.refreshInProgress = false;
                                if (!$scope.pauseInterval) {
                                    if (!$scope.invalidateRefresh) {
                                        if (response.meetup) {
                                            $scope.meetup = response.meetup;
                                            if (!$scope.type) {
                                                var questions = $scope.meetup.questions;
                                                $scope.meetup.questions = questions.filter(function (question) {
                                                    return question.is_active === true;
                                                });
                                            }
                                            $scope.setVotes();
                                        }
                                    }
                                    $scope.invalidateRefresh = false;
                                }
                            })
                        }
                    }
                }, 10000);
            };
            var diffDays;
            var currentDate = new Date();
            if ($stateParams.meetupDetails) {
                $scope.key = $stateParams.key;
                $scope.meetup = $stateParams.meetupDetails.meetup;
                $scope.meetup.start_at = $scope.getZoneTime($scope.meetup.start_at, $scope.meetup.time_zone);
                $scope.meetup.end_at = $scope.getZoneTime($scope.meetup.end_at, $scope.meetup.time_zone);
                $scope.is_organizer = $stateParams.meetupDetails.is_organizer;
                $scope.joined = true;
                $scope.type = 'joined';
                if ($scope.is_organizer && (currentDate < Date.parse($scope.meetup.start_at)))
                    $scope.showEdit = true;
                diffDays = $scope.getDiffDays();
                if (currentDate > Date.parse($scope.meetup.start_at) && currentDate > Date.parse($scope.meetup.end_at)) {
                    if ($scope.is_organizer) {
                        if (diffDays > 1) {
                            $scope.eventEnded = true;
                            $scope.eventEndedMsg = $scope.eventEndedMsgs[0];
                            $scope.joined = false;
                            $scope.type = 'attended';
                            $scope.is_organizer = false;
                        }
                    }
                    else {
                        $scope.eventEnded = true;
                        $scope.eventEndedMsg = $scope.eventEndedMsgs[1];
                        $scope.joined = false;
                        $scope.type = 'attended';
                    }
                }
            }
            else {
                $scope.joined = false;
                $scope.meetup = meetupDetail.meetup;
                $scope.meetup.start_at = $scope.getZoneTime($scope.meetup.start_at, $scope.meetup.time_zone);
                $scope.meetup.end_at = $scope.getZoneTime($scope.meetup.end_at, $scope.meetup.time_zone);
                if ($stateParams.type) {
                    $scope.type = $stateParams.type;
                    if ($scope.type === 'attended') {
                        var questions = $scope.meetup.questions;
                        $scope.meetup.questions = questions.filter(function (question) {
                            return question.is_active === true;
                        });
                        if (currentDate < Date.parse($scope.meetup.end_at)) {
                            $scope.joined = true;
                            $scope.type = undefined;
                        }
                        else {
                            $scope.eventEnded = true;
                            $scope.eventEndedMsg = $scope.eventEndedMsgs[1];
                        }
                        $scope.is_organizer = false;
                    }
                    else if ($scope.type === 'past') {
                        diffDays = $scope.getDiffDays();
                        if (diffDays > 1) {
                            $scope.type = 'attended';
                            $scope.is_organizer = false;
                            $scope.eventEnded = true;
                            $scope.eventEndedMsg = $scope.eventEndedMsgs[0];
                        }
                        else
                            $scope.is_organizer = meetupDetail.is_organizer;
                    }
                    else
                        $scope.is_organizer = meetupDetail.is_organizer;
                }
                else
                    $scope.is_organizer = meetupDetail.is_organizer;
            }
            if (angular.isDefined(refreshQuestions))
                $scope.stopRefreshQuestions();
            $scope.refreshQuestions();
            $scope.setVotes = function () {
                $scope.meetup.questions.map(function (question) {
                    if (!question.no_of_votes) {
                        question.no_of_votes = 0;
                    }
                });
            };
            $scope.setVotes();
            $scope.$on('$destroy', function () {
                $scope.stopRefreshQuestions();
            });

            $scope.sort_order = {};
            $scope.sortedBy = 'recent';
            $scope.editMeetup = function (meetup) {
                Analytics.sendEvent("PG Ask", 'Edit event intent', 'NA', 'NA');
                $state.go('edit-meetup', {meetup: meetup});
            };
            $scope.popular = function () {
                $scope.sort_order = function (p) {
                    return (!(p.answer && p.answer !== ''));
                };
                $scope.sortedBy = 'popular';
            };
            $scope.recent = function () {
                $scope.sort_order = {};
                $scope.sortedBy = 'recent';
            };
            $scope.presentationUnanswered = function () {
                $scope.sort_order = function (p) {
                   return (!p.is_answered); 
                };
                $scope.sortedBy = 'popular';
            }
            $scope.showFullQuestion = function (question) {

                if (question) {
                    $scope.activeQuestion = question;
                    $ionicModal.fromTemplateUrl('templates/partials/meetup-full-question.html', {
                        scope: $scope,
                        animation: 'slide-in-up'//animation types https://forum.ionicframework.com/t/modal-animations/449/9
                    }).then(function (modal) {
                        if (angular.isDefined($scope.modal)) {
                            $scope.modal.hide();
                        }
                        $scope.modal = modal;
                        $scope.modal.show();
                    });
                } else if (angular.isDefined($scope.modal)) {
                    $scope.modal.hide();
                }

            };
            $scope.askQuestion = function (question) {
                $scope.hasAskedQuestion = true;
                Analytics.sendEvent("PG Ask", 'Ask Question', $scope.meetup.title, 'NA');
                if ($scope.fields.question && $scope.fields.question !== "") {
                    $scope.fields.question = "";
                    IonicUtilsService.showLoadingWithTitle('Asking question');
                    $scope.pauseInterval++;
                    pgAskService.askQuestion($scope.meetup.id, question).then(function (response) {
                        if (response.question === question) {
                            pgAskService.getMeetupById($scope.meetup.id).then(function (response) {
                                $scope.pauseInterval--;
                                IonicUtilsService.hideLoading();
                                if (response.meetup) {
                                    $scope.meetup = response.meetup;
                                    var questions = $scope.meetup.questions;
                                    $scope.meetup.questions = questions.filter(function (question) {
                                        return question.is_active === true;
                                    });
                                    $scope.setVotes();
                                }
                            });
                        }
                    });
                }
            };
            $scope.shouldToggle = false;
            $scope.toggleAsk = function (shouldToggle) {
                if (shouldToggle)
                    $scope.shouldToggle = true;
                else $scope.shouldToggle = false;
            };
            $scope.answerQuestion = function (question, mode) {
                if (mode === 'presentation') {
                    if (question.answer && question.answer !== '')
                        $scope.data = {
                            question: question,
                            answer: question.answer,
                            is_answered: true
                        };
                    else
                        $scope.data = {
                            question: question,
                            answer: "Answered during session",
                            is_answered: true
                        };
                    question.answer = $scope.data.answer;
                    question.is_answered = $scope.data.is_answered;
                    IonicUtilsService.showLoadingWithTitle('Loading...');
                    pgAskService.answerMeetupQuestion($scope.meetup.id, $scope.data, mode).then(function (response) {
                       // console.log('Presentation Response.....',response);
                        question.answer = response.answer;
                        IonicUtilsService.hideLoading();
                        $scope.resetInterval();
                    });

                }
                // else if (mode === 'removeFromPresentation') {
                //     $scope.data = {
                //         question: question,
                //         answer: question.answer,
                //         is_answered: true
                //     };
                //     question.answer = $scope.data.answer;
                //     question.is_answered = $scope.data.is_answered;
                //     pgAskService.answerMeetupQuestion($scope.meetup.id, $scope.data, mode).then(function (response) {
                //         question.answer = response.answer;
                //     });
                //
                // }
                else if (mode === 'sendToPresentation') {
                    if (question.answer === "Answered during session")
                        $scope.data = {
                            question: question,
                            answer: '',
                            is_answered: false
                        };
                    else
                        $scope.data = {
                            question: question,
                            answer: question.answer,
                            is_answered: false
                        };
                    question.answer = $scope.data.answer;
                    question.is_answered = $scope.data.is_answered;
                    pgAskService.answerMeetupQuestion($scope.meetup.id, $scope.data, mode).then(function (response) {
                        question.answer = response.answer;
                        $scope.resetInterval();
                    });

                }
                else {
                    mode = 'other';
                    $scope.pauseInterval++;
                    $scope.data = {
                        question: question,
                        answer: question.answer
                    };
                    $scope.confirmPopup = $ionicPopup.alert({
                        title: '',
                        cssClass: 'meetup-answer-popup',
                        scope: $scope,
                        templateUrl: 'templates/partials/answer-meetup-question.html',
                        okText: 'Submit'
                    });
                    $scope.confirmPopup.then(function (res) {
                        if (res) {
                            question.answer = $scope.data.answer;
                            if (question.answer) {
                                pgAskService.answerMeetupQuestion($scope.meetup.id, $scope.data, mode).then(function (response) {
                                    question.answer = response.answer;
                                    $scope.pauseInterval--;
                                });
                            }
                            else {
                                $scope.pauseInterval--;
                            }
                        }
                    });
                }
                //Close the popup
                $scope.showFullQuestion(false);
            };

            $scope.resetInterval = function (){
                $scope.stopRefreshQuestions();
              //  console.log('Stop refreshing');
                $scope.refreshQuestions();
                //console.log('Refersh started');
            }

            $scope.seeAnswer = function (question) {
                $scope.pauseInterval++;
                $scope.data = {
                    question: question,
                    answer: question.answer
                };
                $scope.confirmPopup = $ionicPopup.alert({
                    title: '',
                    cssClass: 'meetup-answer-popup',
                    scope: $scope,
                    templateUrl: 'templates/partials/answer-meetup-question.html',
                    okText: 'Close'
                });
                $scope.confirmPopup.then(function (res) {
                    $scope.pauseInterval--;
                });
            };

            $scope.blockQuestions = [];
            $scope.toggleBlock = function (question) {
                if ($scope.blockQuestions.indexOf(question.id) === -1) {
                    $scope.blockQuestions.push(question.id);
                    if (question.is_active) {
                        question.is_active = false;
                        Analytics.sendEvent("PG Ask", 'Block', $scope.meetup.title, 'NA');
                    }
                    else {
                        question.is_active = true;
                        Analytics.sendEvent("PG Ask", 'Unblock', $scope.meetup.title, 'NA');
                    }
                    $scope.showBlockLoading[question.id] = true;
                    $scope.pauseInterval++;
                    pgAskService.blockQuestion($scope.meetup.id, question.id).then(function (response) {
                        if ($scope.refreshInProgress) {
                            $scope.invalidateRefresh = true;
                        }
                        $scope.showBlockLoading[question.id] = false;
                        $scope.pauseInterval--;
                        $scope.blockQuestions = $scope.blockQuestions.filter(function (item) {
                            return item !== question.id
                        });
                        if (response.is_active) {
                            question.is_active = true
                        }
                        else {
                            question.is_active = false
                        }
                    });
                }
            };

            $scope.toggleLike = function (question) {
                var elements = document.getElementsByClassName("like_" + question.id);

                if (!question.vote_id && elements[0].classList.contains('unlikeEventsAdmin')) {
                    // Array.prototype.forEach.call(elements, function (element) {
                    //     element.className = 'icon ion-pg-like likeEventsAdmin pointer like_' + question.id;
                    // });
                    // question.no_of_votes += 1;
                    Analytics.sendEvent("PG Ask", 'Like Button', $scope.meetup.title, 'NA');
                    $scope.showLikeLoading[question.id] = true;
                    $scope.pauseInterval++;
                    pgAskService.likeQuestion($scope.meetup.id, question.id).then(function (response) {
                        if ($scope.refreshInProgress) {
                            $scope.invalidateRefresh = true;
                        }
                        $scope.showLikeLoading[question.id] = false;
                        $scope.pauseInterval--;
                        if (response.message === "Creation Successfull") {
                            question.no_of_votes = response.no_of_votes;
                            question.vote_id = response.vote_id;
                        }
                    });
                }
                else {
                    if (elements[0].classList.contains('likeEventsAdmin') && question.vote_id) {
                        // Array.prototype.forEach.call(elements, function (element) {
                        //     element.className = 'icon ion-pg-like unlikeEventsAdmin pointer like_' + question.id;
                        // });
                        // question.no_of_votes -= 1;
                        Analytics.sendEvent("PG Ask", 'Unlike button', $scope.meetup.title, 'NA');
                        $scope.showLikeLoading[question.id] = true;
                        $scope.pauseInterval++;
                        pgAskService.unlikeQuestion($scope.meetup.id, question.id, question.vote_id).then(function (response) {
                            if ($scope.refreshInProgress) {
                                $scope.invalidateRefresh = true;
                            }
                            $scope.showLikeLoading[question.id] = false;
                            $scope.pauseInterval--;
                            if (response.message === "Deletion Successfull") {
                                question.no_of_votes = response.no_of_votes;
                                question.vote_id = null;
                            }

                        });
                    }


                }
            };
            var feedbackScope = $rootScope.$new(true);
            feedbackScope.selectedRating = 5;
            feedbackScope.feedback_question = $scope.meetup.feedback_question;
            feedbackScope.meetup_id = $scope.meetup.id;
            feedbackScope.meetup_title = $scope.meetup.title;
            feedbackScope.feedbackGraph = false;
            feedbackScope.labels = ['Loved it', 'Good', 'Fair', 'Average', 'Poor'];
            feedbackScope.series = ['Percent'];
            feedbackScope.options = {
                tooltips: {
                    callbacks: {
                        label: function (tooltipItem, data) {
                            var allData = data.datasets[tooltipItem.datasetIndex].data;
                            var tooltipData = allData[tooltipItem.index];
                            var total = 0;
                            for (var i in allData) {
                                total += allData[i];
                            }
                            var tooltipPercentage = Math.round((tooltipData / total) * 100);
                            return tooltipPercentage + '%';
                        }
                    }
                },
                scales: {
                    yAxes: [{
                        display: true,
                        ticks: {
                            beginAtZero: true,
                            max: 100
                        }
                    }]
                }
            };
            feedbackScope.ratingSelected = function (rating) {
                feedbackScope.selectedRating = rating;
            };
            feedbackScope.getFeedback = function () {
                Analytics.sendEvent("PG Ask", 'Feedback submit', feedbackScope.meetup_title, feedbackScope.selectedRating);
                IonicUtilsService.showLoadingWithTitle('Sending Feedback');
                pgAskService.meetupFeedback(feedbackScope.meetup_id, feedbackScope.selectedRating).then(function (response) {
                    pgAskService.getFeedback(feedbackScope.meetup_id).then(function (response) {
                        IonicUtilsService.hideLoading();
                        if (response.ratings) {
                            feedbackScope.feedbackGraph = true;
                            feedbackScope.feedbacks = response.percent;

                            feedbackScope.data = [
                                [feedbackScope.feedbacks[5], feedbackScope.feedbacks[4], feedbackScope.feedbacks[3], feedbackScope.feedbacks[2], feedbackScope.feedbacks[1]]
                            ];
                        }
                    });
                });

            };
            feedbackScope.closeModal = function () {
                if (angular.isDefined($rootScope.modalCtrl)) {
                    $rootScope.modalCtrl.hide();
                }
            };
            $scope.openModal = function () {

                $ionicModal.fromTemplateUrl('templates/partials/meetup-feedback.html', {
                    scope: feedbackScope,
                    animation: 'slide-in-up meetup-feedback',
                    focusFirstInput: true
                }).then(function (modal) {
                    $rootScope.modalCtrl = modal;
                    $rootScope.modalCtrl.show();
                });
            };
            $scope.showInformation = function (bool) {

                if (bool) {
                    $ionicModal.fromTemplateUrl('templates/partials/meetup-desc-modal.html', {
                        scope: $scope,
                        animation: 'slide-in-up'//animation types https://forum.ionicframework.com/t/modal-animations/449/9
                    }).then(function (modal) {
                        if (angular.isDefined($scope.modal)) {
                            $scope.modal.hide();
                        }
                        $scope.modal = modal;
                        $scope.modal.show();
                    });
                } else if (angular.isDefined($scope.modal)) {
                    $scope.modal.hide();
                }

            };
            $scope.$on("$ionicView.beforeLeave", function (event) {
                if (!$scope.meetup.feedback_id && $scope.joined && !$scope.is_organizer) {
                    if ($scope.hasAskedQuestion)
                        $scope.openModal();
                }
            });
            $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
                if (angular.isDefined($scope.modal)) {
                    $scope.modal.remove();
                }

                if (angular.isDefined($scope.confirmPopup)) {
                    $scope.confirmPopup.close();
                }
                if (fromState.name === "meetupDetail" && toState.name === "pgAsk.created" ||
                    fromState.name === "meetupDetail" && toState.name === "pgAsk.attended") {
                    event.preventDefault();
                    $ionicHistory.removeBackView();
                    $state.go('pgAsk');
                }
                if (toState.resolve) {
                    IonicUtilsService.showLoadingWithTitle('Loading...');
                }
            });
            $scope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
                if (toState.resolve) {
                    IonicUtilsService.hideLoading();
                }
            });
        }])

    // This controller name CreateEvent is for Creating a new Event //CheckEventCodeService
    .controller('CreateEvent', ['$scope', '$state', '$stateParams', '$ionicLoading', '$ionicPopup', '$ionicHistory', '$http', '$timeout', 'check_event_code_service', 'CreateEventService', 'IonicUtilsService', 'PGAskConstant', 'Analytics', function ($scope, $state, $stateParams, $ionicLoading, $ionicPopup, $ionicHistory, $http, $timeout, check_event_code_service, CreateEventService, IonicUtilsService, PGAskConstant, Analytics) {
        $scope.model = {name: 'Model Name'};
        $scope.form = {};
        $scope.master = {};
        $scope.isEdit = false;
        $scope.shouldCheckEventCode = true;
        $scope.fields = {
            'title': '',
            'description': '',
            'startdate': '',
            'enddate': '',
            //'starttime': '',
            //'endtime': '',
            'timezone': {
                name: "Select Timezone",
                value: ""
            },
            'eventcode': '',
            // 'hostkey': '',
            'question': ''
        };

        $scope.selectableNames = PGAskConstant.TIME_ZONES;

        $scope.selectTimezone = function () {
            var currentTime = new Date();
            var zoneOffset;
            var gmt = '';
            var currentTimezone = currentTime.getTimezoneOffset();
            currentTimezone = (currentTimezone / 60) * -1;
            var zoneMinute = currentTimezone.toString().split('.')[1];
            if (zoneMinute === '5')
                zoneOffset = '30';
            else if (zoneMinute === '75')
                zoneOffset = '45';
            else
                zoneOffset = '00';
            if (currentTimezone !== 0) {
                gmt += currentTimezone > 0 ? '+' : '';
                gmt += currentTimezone.toString().split('.')[0] + '.' + zoneOffset;
            }
            else
                gmt += "0.00";
            $scope.fields.timezone = $scope.selectableNames.find(function (timezone) {
                return timezone.value === gmt;
            });
            if (!$scope.fields.timezone) {
                $scope.fields.timezone = {
                    name: "Select Timezone",
                    value: ""

                }
            }
        };
        $scope.selectTimezone();
        $scope.check_code = function (fields) {
            if ($scope.fields.eventcode) {
                $scope.fields.eventcode = $scope.fields.eventcode.toUpperCase();
            }
            var ecode = $scope.fields.eventcode;
            if (ecode && ecode.length >= 4)
                if ($scope.shouldCheckEventCode)
                    check_event_code_service.checkEventCode(ecode).then(function (response) {
                        if (response.is_unique) {
                            $scope.form.newEventForm.eventcode.$valid = true;
                            $scope.form.newEventForm.eventcode.$invalid = false;
                        }
                        else {
                            $scope.form.newEventForm.eventcode.$valid = false;
                            $scope.form.newEventForm.eventcode.$invalid = true;
                        }

                    });
                else
                    $scope.shouldCheckEventCode = true;
            else {
                $scope.form.newEventForm.eventcode.$valid = false;
                $scope.form.newEventForm.eventcode.$invalid = true;
            }

        };


        $scope.initDate = function () {
            var now = new Date();
            var coeff = 1000 * 60 * 5;
            var rounded = new Date(Math.ceil(now.getTime() / coeff) * coeff);
            $scope.fields.startdate = new Date(Math.ceil(now.getTime() / coeff) * coeff);
            $scope.fields.enddate = new Date(rounded.setHours(rounded.getHours() + 1));
        };
        $scope.initDate();
        $scope.showEventTip = function () {
            $ionicLoading.show({
                template: "<div>Event code can be alphanumeric and should be of length 4 to 12.<div>",
                noBackdrop: true,
                duration: 2000
            });
        };
        $scope.showAlert = function (data) {
            $scope.data = {
                host_code: data.host_code,
                user: data.user
            };
            $scope.confirmPopup = $ionicPopup.alert({
                title: '<div class="meetup-alert meetup-new-alert"></div>',
                cssClass: 'meetup-create-popup',
                templateUrl: 'templates/partials/meetup-confirmation.html',
                scope: $scope
            });
            $scope.confirmPopup.then(function (res) {
                $scope.confirmPopup.close();
                $scope.confirmPopup = undefined;
                $state.go('pgAsk');
            });
        };
        $scope.createDateAsUTC = function (date) {
            return new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds()));
        }
        //Making json
        var count = 0;
        $scope.addMeetup = function (fields) {
            count++;
            if (count === 1) {
                Analytics.sendEvent("PG Ask", 'Create event', 'NA', 'NA');
                fields.startdateTz = $scope.createDateAsUTC(fields.startdate);
                fields.enddateTz = $scope.createDateAsUTC(fields.enddate);
                IonicUtilsService.showLoadingWithTitle('Creating Event');
                CreateEventService.createEvent(fields).then(function (response) {
                    IonicUtilsService.hideLoading();
                    if (response.error) {
                        $ionicLoading.show({
                            template: "Error occured",
                            noBackdrop: true,
                            duration: 2000
                        });
                    }
                    else if (response.meetup) {
                        $scope.showAlert(response.meetup)
                    }

                });
            }
        };
        $scope.updateMeetup = function (fields) {
            Analytics.sendEvent("PG Ask", 'Update event', 'NA', 'NA');
            fields.up_startdateTz = $scope.createDateAsUTC(fields.startdate);
            fields.up_enddateTz = $scope.createDateAsUTC(fields.enddate);
            IonicUtilsService.showLoadingWithTitle('Updating Event');
            CreateEventService.updateEvent(fields, $scope.meetup_id).then(function (response) {
                IonicUtilsService.hideLoading();
                if (response.status = "meetup is successfully updated") {
                    $ionicHistory.removeBackView();
                    $state.go('pgAsk');
                }
            });
        };
        $scope.confirmDelete = function () {
            $scope.confirmPopup = $ionicPopup.confirm({
                title: '<div class="meetup-alert meetup-delete-alert"></div>',
                cssClass: 'meetup-delete-popup',
                template: '<div class="meetup-delete">Would you like to delete this event?</div>'
            });

            $scope.confirmPopup.then(function (res) {
                if (res) {
                    $scope.deleteMeetup()
                }
            });
        };
        $scope.deleteMeetup = function () {
            Analytics.sendEvent("PG Ask", 'Delete event', 'NA', 'NA');
            IonicUtilsService.showLoadingWithTitle('Removing Meetup');
            CreateEventService.deleteEvent($scope.meetup_id).then(function (response) {
                IonicUtilsService.hideLoading();
                if (response.status = "meetup is successfully updated") {
                    $scope.confirmPopup.close();
                    $scope.confirmPopup = undefined;
                    $ionicHistory.removeBackView();
                    $state.go('pgAsk');
                }
            });
        };
        if ($stateParams.meetup) {
            $scope.isEdit = true;
            $scope.shouldCheckEventCode = false;
            $scope.meetup_id = $stateParams.meetup.id;
            $scope.fields.title = $stateParams.meetup.title;
            $scope.fields.description = $stateParams.meetup.description;
            $scope.fields.timezone = $scope.selectableNames.find(function (timezone) {
                return timezone.value === $stateParams.meetup.time_zone;
            });
            if (!$scope.fields.timezone) {
                $scope.fields.timezone = {
                    name: "Select Timezone",
                    value: ""

                }
            }
            $scope.fields.startdate = $stateParams.meetup.start_at;
            $scope.fields.enddate = $stateParams.meetup.end_at;
            // $scope.fields.startdate = $scope.getZoneTime($stateParams.meetup.start_at, $stateParams.meetup.time_zone);
            // $scope.fields.enddate = $scope.getZoneTime($stateParams.meetup.end_at, $stateParams.meetup.time_zone);
            $scope.fields.eventcode = $stateParams.meetup.event_code;
            $scope.hostcode = $stateParams.meetup.host_code;
            $scope.fields.question = $stateParams.meetup.feedback_question;
        }
        $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
            if (angular.isDefined($scope.modal)) {
                $scope.modal.remove();
            }

            if (angular.isDefined($scope.confirmPopup)) {
                $scope.confirmPopup.close();
            }
            if ((fromState.name === "edit-meetup" || fromState.name === "create-meetup") && toState.name === "pgAsk.attended" ||
                (fromState.name === "edit-meetup" || fromState.name === "create-meetup") && toState.name === "pgAsk.created") {
                event.preventDefault();
                $ionicHistory.removeBackView();
                $state.go('pgAsk');
            }
        });

    }
    ]);


//pg ask controller ends

