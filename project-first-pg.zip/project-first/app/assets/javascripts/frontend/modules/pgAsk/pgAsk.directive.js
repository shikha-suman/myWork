angular.module('pgAsk.directives', [])
    .directive("limitTo", [function () {
        return {
            restrict: "A",
            link: function (scope, elem, attrs) {
                var limit = parseInt(attrs.limitTo);
                angular.element(elem).on("keypress", function (e) {
                    if (this.value.length == limit) e.preventDefault();
                });
            }
        }
    }])
    .directive("selectableText", function () {
        return {
            restrict: "A",
            template: function (element) {
                return '<input type="text" readonly value="' + element[0].textContent + '">';
            }
        }
    })

    .directive('formValidate', function ($ionicLoading) {
        return {
            restrict: 'A',
            controller: function ($scope, $ionicModal) {

                $scope.submit = function (fields, isEdit) {
                    var startDate = Date.parse($scope.fields.startdate);
                    var endDate = Date.parse($scope.fields.enddate);
                    $scope.CurrentDate = new Date();

                    if (!($scope.form.newEventForm.title.$valid)) {
                        $ionicLoading.show({
                            template: 'Title Required',
                            duration: 1000
                        });
                        //newEventForm.title.focus();
                    } else if (!($scope.form.newEventForm.description.$valid)) {
                        $ionicLoading.show({
                            template: 'Description Required',
                            duration: 1000
                        })
                    }

                    else if (!($scope.form.newEventForm.eventcode.$valid)) {
                        $ionicLoading.show({
                            template: 'Event Code Required',
                            duration: 1000
                        })
                    }
                    else if (!(fields.timezone && fields.timezone.value !== '')) {
                        $ionicLoading.show({
                            template: 'Timezone is Required',
                            duration: 1000
                        })
                    }

                    else if (!($scope.form.newEventForm.question.$valid)) {
                        $ionicLoading.show({
                            template: 'Feedback Question is Required',
                            duration: 1000
                        })
                    }
                    else if (startDate <= $scope.CurrentDate) {
                        $ionicLoading.show({template: 'Start time must be greater than current time', duration: 2000})
                    }
                    else if (endDate <= startDate) {
                        $ionicLoading.show({template: 'End time must be greater than start time', duration: 2000})
                    }
                    else {
                        if (!isEdit)
                            $scope.addMeetup(fields);
                        else
                            $scope.updateMeetup(fields);
                    }
                }
            }
        }
    });
