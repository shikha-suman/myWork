angular.module('pgAsk.services', [])
    .service('pgAskService', ['$http', '$log', '$q', 'APP_CONFIG', function ($http, $log, $q, APP_CONFIG) {
        var service = {};
        service.allMeetups = {};
        service.getAllMeetups = function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: APP_CONFIG.BASE_URL + 'meetups/'
            }).then(function successCallback(response) {
                $log.debug("Return from meetups API");
                service.allMeetups = response.data;
                deferred.resolve({allMeetups: service.allMeetups});
            }, function errorCallback(response) {
                $log.debug("Error: meetups API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        service.getFeedback = function (meetup_id) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: APP_CONFIG.BASE_URL + 'feedback-count?meetup_id=' + meetup_id
            }).then(function successCallback(response) {
                $log.debug("Return from getFeedback API");
                deferred.resolve(response.data);
            }, function errorCallback(response) {
                $log.debug("Error: getFeedback API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        service.getMeetupById = function (id) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: APP_CONFIG.BASE_URL + 'meetups/' + id
            }).then(function successCallback(response) {
                $log.debug("Return from meetups API");
                service.meetup = response.data;
                deferred.resolve(service.meetup);
            }, function errorCallback(response) {
                $log.debug("Error: meetups API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        service.blockQuestion = function (meetup_id, question_id) {
            var deferred = $q.defer();
            $http({
                method: 'PUT',
                url: APP_CONFIG.BASE_URL + 'meetups/' + meetup_id + '/questions/' + question_id + '/block_question'
            }).then(function successCallback(response) {
                $log.debug("Return from blockQuestion API");
                deferred.resolve(response.data);
            }, function errorCallback(response) {
                $log.debug("Error: blockQuestion API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        service.likeQuestion = function (meetup_id, question_id) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: APP_CONFIG.BASE_URL + 'meetups/' + meetup_id + '/questions/' + question_id + '/votes'
            }).then(function successCallback(response) {
                $log.debug("Return from likeQuestion API");
                deferred.resolve(response.data);
            }, function errorCallback(response) {
                $log.debug("Error: likeQuestion API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        service.unlikeQuestion = function (meetup_id, question_id, vote_id) {
            var deferred = $q.defer();
            $http({
                method: 'DELETE',
                url: APP_CONFIG.BASE_URL + 'meetups/' + meetup_id + '/questions/' + question_id + '/votes/' + vote_id
            }).then(function successCallback(response) {
                $log.debug("Return from unlikeQuestion API");
                deferred.resolve(response.data);
            }, function errorCallback(response) {
                $log.debug("Error: unlikeQuestion API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        service.askQuestion = function (meetup_id, question) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: APP_CONFIG.BASE_URL + 'meetups/' + meetup_id + '/questions/',
                data: {
                    question: question
                }
            }).then(function successCallback(response) {
                $log.debug("Return from askQuestion API");
                deferred.resolve(response.data);
            }, function errorCallback(response) {
                $log.debug("Error: askQuestion API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        service.meetupFeedback = function (meetup_id, rating) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: APP_CONFIG.BASE_URL + 'meetups/' + meetup_id + '/feedbacks/',
                data: {
                    rating: rating
                }
            }).then(function successCallback(response) {
                $log.debug("Return from meetupFeedback API");
                deferred.resolve(response.data);
            }, function errorCallback(response) {
                $log.debug("Error: meetupFeedback API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        service.answerMeetupQuestion = function (meetup_id, data, mode) {
            var deferred = $q.defer();
            var newdata;
            if (mode !== 'other') {
                newdata = {
                    answer: data.answer,
                    is_answered: data.is_answered
                }
            }
            else {
                newdata = {
                    answer: data.answer
                }
            }
            $http({
                method: 'PUT',
                url: APP_CONFIG.BASE_URL + 'meetups/' + meetup_id + '/questions/' + data.question.id,
                data: newdata
            }).then(function successCallback(response) {
                $log.debug("Return from answerMeetupQuestion API");
                deferred.resolve(response.data);
                service.getMeetupById(meetup_id); // newly added here
            }, function errorCallback(response) {
                $log.debug("Error: answerMeetupQuestion API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        service.joinEvent = function (key) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: APP_CONFIG.BASE_URL + 'meetups/join',
                params: {
                    key: key
                }
            }).then(function successCallback(response) {
                $log.debug("Return from joinEvent API");
                deferred.resolve(response.data);
            }, function errorCallback(response) {
                $log.debug("Error: joinEvent API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        return service;
    }])


    .service('CreateEventService', ['$http', '$log', '$q', 'APP_CONFIG', 'SESSION', function ($http, $log, $q, APP_CONFIG, SESSION) {
        var service = {};
        service.allMeetups = {};
        service.createEvent = function (fields) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: APP_CONFIG.BASE_URL + 'meetups/',
                data: {
                    title: fields.title,
                    description: fields.description,
                    start_at: fields.startdateTz,
                    end_at: fields.enddateTz,
                    time_zone: fields.timezone.value,
                    event_code: fields.eventcode,
                    feedback_question: fields.question,
                    user_id: SESSION.USER_ID
                }
            }).then(function successCallback(response) {
                $log.debug("Return from meetups API");
                deferred.resolve(response.data);

            }, function errorCallback(response) {
                $log.debug("Error: meetups API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        service.updateEvent = function (fields, id) {
            var deferred = $q.defer();
            $http({
                method: 'PUT',
                url: APP_CONFIG.BASE_URL + 'meetups/' + id,
                data: {
                    title: fields.title,
                    description: fields.description,
                    start_at: fields.up_startdateTz,
                    end_at: fields.up_enddateTz,
                    time_zone: fields.timezone.value,
                    event_code: fields.eventcode,
                    feedback_question: fields.question
                }
            }).then(function successCallback(response) {
                $log.debug("Return from meetups API");
                deferred.resolve(response.data);

            }, function errorCallback(response) {
                $log.debug("Error: meetups API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        service.deleteEvent = function (id) {
            var deferred = $q.defer();
            $http({
                method: 'DELETE',
                url: APP_CONFIG.BASE_URL + 'meetups/' + id,
                data: {
                    id: id
                }
            }).then(function successCallback(response) {
                $log.debug("Return from meetups API");
                deferred.resolve(response.data);

            }, function errorCallback(response) {
                $log.debug("Error: meetups API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        return service;
    }])

    .service('check_event_code_service', ['$http', '$log', '$q', 'APP_CONFIG', function ($http, $log, $q, APP_CONFIG) {


        var service = {};

        service.checkEventCode = function (ecode) {
            var deferred = $q.defer();
            $http({
                method: 'GET',


                //  http://localhost:3000/api/v1/check_event_code?event_code=test123
                url: APP_CONFIG.BASE_URL + 'check_event_code',

                params: {
                    event_code: ecode
                }

            }).then(function successCallback(response) {
                $log.debug("Return from check_event_code API");

                deferred.resolve({is_unique: response.data.is_unique});

            }, function errorCallback(response) {
                $log.debug("Error: check_event_code API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        return service;

    }]);


