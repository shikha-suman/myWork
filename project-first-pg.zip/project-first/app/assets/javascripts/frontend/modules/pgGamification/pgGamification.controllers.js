angular.module('pgGamification.controllers', [])

    //gamification open challenge detail page starts

    .controller('GameDetailCtrl', ['$rootScope','$scope', '$filter', '$state', '$stateParams', 'pastEventsDetailService','IonicUtilsService', function ($rootScope, $scope, $filter, $state, $stateParams, pastEventsDetailService, IonicUtilsService) {

        $scope.$on('$ionicView.beforeEnter', function () {
            IonicUtilsService.showLoadingWithTitle('Loading ...')
            pastEventsDetailService.getPastEventById($stateParams.id).then(function successCallback(response) {
                IonicUtilsService.hideLoading();
                $scope.pastEventDetails = response.data.data.challenge;
                //console.log($scope.pastEventDetails.winners)
                $scope.winners = $scope.pastEventDetails.winners;
                //console.log('caption of winners', $scope.winners.text);
            })
        })

        $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {

            if (angular.isDefined($rootScope.modalCtrl)) {
                $rootScope.modalCtrl.remove();
            }

            if (angular.isDefined($scope.confirmPopup)) {
                $scope.confirmPopup.close();
            }
            if (fromState.name === "GamePastEventsPage" && toState.name === "GameHomePage.pastentries") {
                event.preventDefault();
                $state.go('GameHomePage');
            }
        });

    }])

    //gamification home page starts
    .controller('GameHomePageCtrl', ['$rootScope','$scope', '$filter', '$state', '$ionicHistory', '$stateParams', '$timeout', '$log', 'IonicUtilsService', 'openChallengesService', 'pastChallengesService', 'myChallengesService', 'pastEventsDetailService', 'MyEventsDetailService', '$ionicLoading', '$ionicSlideBoxDelegate', function ($rootScope,$scope, $filter, $state, $ionicHistory, $stateParams, $timeout, $log, IonicUtilsService, openChallengesService, pastChallengesService, myChallengesService, pastEventsDetailService, MyEventsDetailService, $ionicLoading, $ionicSlideBoxDelegate) {

        // $ionicLoading.show({
        //     template: '<p>Loading123......</p><ion-spinner icon="ios"></ion-spinner>',
        //     duration: 1000
        // });

        $scope.myEntrydetailsById = function (id) {
            //console.log('id in controller', id);
            MyEventsDetailService.getMyEventById(id).then(function successCallback(response) {
                $scope.pastEventDetails = response.data;
            })
        }

        $scope.$on('$ionicView.beforeEnter', function () {

            IonicUtilsService.showLoadingWithTitle('Loading challenges');
            openChallengesService.openChallenges().then(function (response) {
                IonicUtilsService.hideLoading();
                $scope.openChallenges = response.data.challenges;
                $ionicSlideBoxDelegate.slide(0);
                $ionicSlideBoxDelegate.update();
                $scope.openChallengesPoints = response.data.points;
                $scope.redeem = $scope.openChallengesPoints.redeem;
                $scope.total = $scope.openChallengesPoints.total;

                if ($scope.redeem == null) {
                    $scope.redeem = 0;
                }
                if ($scope.total == null) {
                    $scope.total = 0;
                }
                $scope.redeemed = $scope.total + $scope.redeem;
                    $scope.openChallengesFaq = response.data.faq;
            }, function (resolve) {
                console.log("Error in open challenges", resolve);
            });

            // myChallengesService.myChallenges().then(function (response) {
            //     $scope.myChallenges = response.data.challenges;
            // }, function (resolve) {
            //     console.log("Error in open challenges", resolve);
            // });
        });

        // $scope.pastChallenges = function () {
        //     pastChallengesService.pastChallenges().then(function (response) {
        //         $scope.pastChallengesdata = response.data.challenges;
        //     }, function (resolve) {
        //         console.log("Error in open challenges", resolve);
        //     });
        // }

        // var history = $ionicHistory.viewHistory();
        // $scope.$on('$ionicView.beforeEnter', function () {
        //     $state.go('GameHomePage.myentries');
        // });
    }])


    //gamification open challenge detail page starts
    .controller('GameOpenDetailCtrl', ['$rootScope', '$scope', '$filter', '$state', '$ionicHistory', '$stateParams',
        '$timeout', '$log', '$ionicLoading', 'IonicUtilsService', 'openEventsDetailService', 'GamificationOpenService',
        'Analytics', 'UserService',
        function ($rootScope, $scope, $filter, $state, $ionicHistory, $stateParams, $timeout, $log, $ionicLoading,
                  IonicUtilsService, openEventsDetailService, GamificationOpenService, Analytics, UserService) {
        $scope.$on('$ionicView.beforeEnter', function () {
            //console.log('id in controller', $stateParams.id);
            IonicUtilsService.showLoadingWithTitle('Loading open challenges');
            openEventsDetailService.getOpenEventById($stateParams.id).then(function successCallback(response) {
                IonicUtilsService.hideLoading();
                $scope.openEventDetails = response.data.data.challenge;
            })
        });

        $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {

            if (angular.isDefined($rootScope.modalCtrl)) {
                $rootScope.modalCtrl.remove();
            }

            if (angular.isDefined($scope.confirmPopup)) {
                $scope.confirmPopup.close();
            }
            if (fromState.name === "GameOpenEventsPage" && toState.name === "GameHomePage.myentries") {
                event.preventDefault();
                $state.go('GameHomePage');
            }
        });



        // Resticting the Copy in textarea

        var  desc  =  document.getElementById('commentboxGame');
                if  (desc  !=  null)  {
                        desc.onpaste  =  function  (e)  {
                                //do some IE browser checking for e
                                var  max  = commentboxGame.getAttribute("maxlength");
                                e.clipboardData.getData('text/plain').slice(0,  max)
                        };
                }
             // toggling textarea
        $scope.shouldToggle = false;
        $scope.toggleAsk = function (shouldToggle) {
            if (shouldToggle)
                $scope.shouldToggle = true;
            else $scope.shouldToggle = false;
        };
        // open challenges Entry
        
        $scope.submit_entry = function (title, filedata_image, filedata_video, caption, type) {

            $scope.challenge_id = $stateParams.id;
            if (type == 'caption') {
                //console.log("Caption........",caption);
                if (caption != null) {
                    data = {
                        entry_text: title,
                        challenge_id: $scope.challenge_id,
                        caption_text: caption
                    }
                } else {
                    $ionicLoading.show({
                        template: '<p>Enter Caption</p>',
                        duration: 2000
                    });
                }
            }
            if (type == 'image') {
                //console.log("Image........",filedata_image);
                if (filedata_image != null) {
                    var imgfileSize = Math.round(filedata_image.size / 1024);
                    if (imgfileSize > 5120) {
                        $ionicLoading.show({
                            template: 'Image size should be less than 5MB',
                            duration: 2000
                        })
                        return;
                    }
                    else {
                        data = {
                            entry_text: title,
                            image: filedata_image,
                            challenge_id: $scope.challenge_id
                        }
                    }
                } else {
                    $ionicLoading.show({
                        template: '<p>Upload Image</p>',
                        duration: 2000
                    });
                }
            }
            if (type == 'video') {
                //console.log("Video........",filedata_video);
                if (filedata_video != null) {
                    data = {
                        entry_text: title,
                        video: filedata_video,
                        challenge_id: $scope.challenge_id
                    }
                } else {
                    $ionicLoading.show({
                        template: '<p>Upload Video</p>',
                        duration: 2000
                    });
                }
            }
            //if (data.entry_text != null) {
                // $ionicLoading.show({
                //     template: '<p>Submitting......</p><ion-spinner icon="android"></ion-spinner>',
                //     duration: 2000
                // });
                // data = {
                //     entry_text: title,
                //     image: filedata_image,
                //     video: filedata_video,
                //     challenge_id: $scope.challenge_id,
                //     caption_text: caption
                // }
                if(data != undefined) {
                    Analytics.sendEvent("Gamification", 'Submit entry', UserService.user.buildings[0].name, UserService.user.building_id);
                    GamificationOpenService.submitentry(data);
                }
                    // .then(function successCallback(res) {
                    //     IonicUtilsService.showLoadingWithTitle('Loading....');
                    //     console.log('Inside Submitting', data.challenge_id);
                        
                    //     //$state.go('MyEntriesEventsPage',{'id':data.challenge_id});
                    //     //$state.go(stateName, {'id': item.id});
                    //     $state.go('GameHomePage');
                    // }, function errorCallback(resolve) {
                    //     IonicUtilsService.showLoadingWithTitle('Loading....');
                    //     //console.log('Error in Submitting', resolve);
                    //     // IonicUtilsService.showLoadingWithTitle('Loading....');
                    //     $ionicLoading.hide();
                    //     //  $state.go('MyEntriesEventsPage',{'id':data.challenge_id});
                    //     $state.go('GameHomePage');
                    // });

            //}
        return false;
        }
        
    }])


    // my entries

    .controller('GameMyEntriesDetailCtrl', ['$rootScope', '$scope', '$filter', '$state', '$stateParams',
        'MyEventsDetailService', 'GamificationWithdrawService', 'IonicUtilsService', 'Analytics', 'UserService','$ionicHistory',
        function ($rootScope, $scope, $filter, $state, $stateParams, MyEventsDetailService,
                  GamificationWithdrawService, IonicUtilsService, Analytics, UserService , $ionicHistory) {

        $scope.$on('$ionicView.beforeEnter', function () {
            IonicUtilsService.showLoadingWithTitle('Loading ...')
            MyEventsDetailService.getMyEventById($stateParams.id).then(function successCallback(response) {
                IonicUtilsService.hideLoading();
                $scope.myEventDetails = response.data;
                $scope.eventcreated = response.data.challenge.entry;
            }, function errorCallback(resolve) {
                console.log('Error', resolve);
            })

        })

        $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
            if (angular.isDefined($rootScope.modalCtrl)) {
                $rootScope.modalCtrl.remove();
            }

            if (angular.isDefined($scope.confirmPopup)) {
                $scope.confirmPopup.close();
            }
            if ((fromState.name === "MyEntriesEventsPage" && toState.name === "GameViewAll.myentries") ) {
                event.preventDefault();
                $ionicHistory.removeBackView();
                $state.go('GameViewAll');
            }
        });

        var withdraw_id = $stateParams.id;
        $scope.withdrawentry = function (entryid) {
            Analytics.sendEvent("Gamification", "Withdraw entry", UserService.user.buildings[0].name, UserService.user.building_id);
            GamificationWithdrawService.withdrawentry(entryid, withdraw_id).then(function successCallback(response) {
                event.preventDefault();
                $state.go('GameHomePage');
            }, function errorCallback(error) {
                console.log("Error", error);
            });
        }
         //rotating image
               var angle= 0
            $scope.rotateImageHistory = function (){             
                var img = document.getElementById('imageRotate');
                 angle = (angle+90)%360;
                 img.className = "rotate"+angle;
            }

    }])


    //Score Page 

    .controller('GameScorePageCtrl', ['$rootScope','$scope', '$filter', '$state', '$stateParams', 'ScoreCardService', 'IonicUtilsService','openChallengesService',function ($rootScope,$scope, $filter, $state, $stateParams, ScoreCardService, IonicUtilsService,openChallengesService) {

        $scope.$on('$ionicView.beforeEnter', function () {
            IonicUtilsService.showLoadingWithTitle('Loading point details......');
            ScoreCardService.getScores().then(function successCallback(response) {
                $scope.scores = response.data.logs;
                IonicUtilsService.hideLoading();
                //console.log("Scores", $scope.scores);
            }, function errorCallback(resolve) {
                console.log('Error', resolve);
            });

             openChallengesService.openChallenges().then(function (response) {
                $scope.openChallenges = response.data.challenges;
                
                $scope.openChallengesPoints = response.data.points;
                $scope.redeem = $scope.openChallengesPoints.redeem;

                $scope.total = $scope.openChallengesPoints.total;
                if ($scope.redeem == null) {
                    $scope.redeem = 0;
                }
                if ($scope.total == null) {
                    $scope.total = 0;
                }
                 $scope.redeemed = $scope.total + $scope.redeem;
                $scope.openChallengesFaq = response.data.faq;
            }, function (resolve) {
                console.log("Error in open challenges", resolve);
            });

        })

        $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {

            if (angular.isDefined($rootScope.modalCtrl)) {
                $rootScope.modalCtrl.remove();
            }

            if (angular.isDefined($scope.confirmPopup)) {
                $scope.confirmPopup.close();
            }
            if (fromState.name === "GameScorePage" && toState.name === "GameHomePage.myentries") {
                event.preventDefault();
                $state.go('GameHomePage');
            }
        });
    }])

   // View all open challenges


    .controller('GameViewallCtrl', ['$rootScope','$scope', '$filter', '$state', '$stateParams', 'ScoreCardService', 'IonicUtilsService','openChallengesService',function ($rootScope,$scope, $filter, $state, $stateParams, ScoreCardService, IonicUtilsService,openChallengesService) {

        $scope.$on('$ionicView.beforeEnter', function () {
            IonicUtilsService.showLoadingWithTitle('Loading all challenges......');
            ScoreCardService.getScores().then(function successCallback(response) {
                $scope.scores = response.data.logs;
                IonicUtilsService.hideLoading();
                console.log("Scores", $scope.scores);
            }, function errorCallback(resolve) {
                console.log('Error', resolve);
            });

             openChallengesService.openChallenges().then(function (response) {

                $scope.openChallenges = response.data.challenges;
                
                $scope.openChallengesPoints = response.data.points;
                $scope.redeem = $scope.openChallengesPoints.redeem;
                $scope.total = $scope.openChallengesPoints.total;
                if ($scope.redeem == null) {
                    $scope.redeem = 0;
                }
                if ($scope.total == null) {
                    $scope.total = 0;
                }
                 $scope.redeemed = $scope.total + $scope.redeem;
                $scope.openChallengesFaq = response.data.faq;
            }, function (resolve) {
                console.log("Error in open challenges", resolve);
            });

        })

        $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {

            if (angular.isDefined($rootScope.modalCtrl)) {
                $rootScope.modalCtrl.remove();
            }

            if (angular.isDefined($scope.confirmPopup)) {
                $scope.confirmPopup.close();
            }
            if (fromState.name === "Viewall" && toState.name === "GameHomePage.myentries") {
                event.preventDefault();
                $state.go('GameHomePage');
            }
        });

    }])
//view all entries controller
  

 .controller('GameViewAllEntriesCtrl', ['$rootScope','$scope', '$filter', '$state', '$ionicHistory', '$stateParams', '$timeout', '$log', 'IonicUtilsService', 'openChallengesService', 'pastChallengesService', 'myChallengesService', 'pastEventsDetailService', 'MyEventsDetailService', '$ionicLoading', '$ionicSlideBoxDelegate','UserService', function ($rootScope,$scope, $filter, $state, $ionicHistory, $stateParams, $timeout, $log, IonicUtilsService, openChallengesService, pastChallengesService, myChallengesService, pastEventsDetailService, MyEventsDetailService, $ionicLoading, $ionicSlideBoxDelegate,UserService) {
    //    $ionicLoading.show({
    //         template: '<p>Loading......</p><ion-spinner icon="ios"></ion-spinner>',
    //         duration: 1000
    //     });

        $scope.myEntrydetailsById = function (id) {
            MyEventsDetailService.getMyEventById(id).then(function successCallback(response) {
                $scope.pastEventDetails = response.data;
            })
        }

        $scope.$on('$ionicView.beforeEnter', function () {


            // openChallengesService.openChallenges().then(function (response) {

            //     $scope.openChallenges = response.data.challenges;
            //     $ionicSlideBoxDelegate.update();
            //     $scope.openChallengesPoints = response.data.points;
            //     $scope.redeem = $scope.openChallengesPoints.redeem;
            //     $scope.total = $scope.openChallengesPoints.total;

            //     if ($scope.redeem == null) {
            //         $scope.redeem = 0;
            //     }
            //     if ($scope.total == null) {
            //         $scope.total = 0;
            //     }
            //     $scope.redeemed = $scope.total + $scope.redeem;
            //         $scope.openChallengesFaq = response.data.faq;
            // }, function (resolve) {
            //     console.log("Error in open challenges", resolve);
            // });
            IonicUtilsService.showLoadingWithTitle('Loading my entries')
            myChallengesService.myChallenges(UserService.user.building_id).then(function (response) {
                IonicUtilsService.hideLoading();
                $scope.myChallenges = response.data.challenges;
            }, function (resolve) {
                console.log("Error in open challenges", resolve);
            });
        });

        $scope.pastChallenges = function () {
            IonicUtilsService.showLoadingWithTitle('Loading past challenges')
            pastChallengesService.pastChallenges(UserService.user.building_id).then(function (response) {
                IonicUtilsService.hideLoading();
                $scope.pastChallengesdata = response.data.challenges;
            }, function (resolve) {
                console.log("Error in open challenges", resolve);
            });
        }

        
                    $scope.currentDate = new Date();
            //console.log('date',$scope.currentDate);

        var history = $ionicHistory.viewHistory();
        $scope.$on('$ionicView.beforeEnter', function () {
            $state.go('GameViewAll.myentries');
        });
    }])


