 angular.module('pgGamification.directives', [])

// File Input

 .directive("fileinputgame", [function() {
        return {
            scope: {
                fileinputgame: "="
            },
            link: function(scope, element, attributes) {
                element.bind("change", function(changeEvent) {
                    scope.fileinputgame = changeEvent.target.files[0];
                    var reader = new FileReader();
                    /*                    reader.onload = function(loadEvent) {
                     scope.$apply(function() {
                     scope.filepreview = loadEvent.target.result;
                     });
                     }*/
                    reader.readAsDataURL(scope.fileinputgame);
                });
            }
        }
    }])

// Limiting the characters in textbox

.directive("limitTo", [function () {
        return {
            restrict: "A",
            link: function (scope, elem, attrs) {
                var limit = parseInt(attrs.limitTo);
                angular.element(elem).on("keypress", function (e) {
                    if (this.value.length == limit) e.preventDefault();
                });
            }
        }
    }])

// Validating the file

    .directive('validFile', function () {
    return {
        require: 'ngModel',
        link: function (scope, el, attrs, ngModel) {
            ngModel.$render = function () {
                ngModel.$setViewValue(el.val());
            };

            el.bind('change', function () {
                scope.$apply(function () {
                    ngModel.$render();
                });
            });
        }
    };
}); 
