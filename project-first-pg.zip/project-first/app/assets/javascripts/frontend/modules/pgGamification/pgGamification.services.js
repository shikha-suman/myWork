
angular.module('pgGamification.services', [])
//Services for Gamification

//Open challenges

    .service("openChallengesService",['$log','$http', '$q' ,'APP_CONFIG', function ($log, $http, $q, APP_CONFIG) {
        var service = {};
        
        service.responseJSON=[];
        service.openChallenges = function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                 url : APP_CONFIG.BASE_URL + 'challenges/custom'
            })
            .then(function successCallback(response) {
               
              deferred.resolve({success: true, data: response.data});
               // console.log('Open Challenges Success', response.data);
            },
                function error(response) {
                    $log.debug("Open Challenges Error", response);
                });

                return deferred.promise;
            };
        return service;
    }])

//My Entries challenges

    .service("myChallengesService",['$log','$http', '$q' ,'APP_CONFIG', function ($log, $http, $q, APP_CONFIG) {
        var service = {};
        service.responseJSON=[];
        service.myChallenges = function (building_id) {
            //console.log('building_id.....',building_id);
            var deferred = $q.defer();
            $http({
                method: 'GET',
                //  url : APP_CONFIG.BASE_URL + 'challenges/open/participate' //add /participate if data is coming
                url : APP_CONFIG.BASE_URL +'challenges/'+ building_id+'/myrecords' //add /participate if data is coming 
            })
            .then(function successCallback(response) {
               // var open = response.data;
             //   var openChallenges = response.data.challenges;
//console.log('My Records',response.data);
              deferred.resolve({success: true, data: response.data});
               // console.log('MyChallenges Success', response);
            },
                function error(resolve) {
                    $log.debug("MyChallenges Error", resolve);
                });

                return deferred.promise;
            };
        return service;
    }])

//Past challenges

    .service("pastChallengesService",['$log','$http', '$q' ,'APP_CONFIG', function ($log, $http, $q, APP_CONFIG) {
        var service = {};
        service.responseJSON=[];
        service.pastChallenges = function (building_id) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                //  url : APP_CONFIG.BASE_URL + 'challenges/past'
                 url : APP_CONFIG.BASE_URL + 'challenges/'+building_id+'/allwinners'
            })
            .then(function successCallback(response) {
               // var open = response.data;
             //   var openChallenges = response.data.challenges;
              deferred.resolve({success: true, data: response.data});
              //console.log('Past Challenges Success', response.data);
            },
                function error(response) {
                    $log.debug("Past Challenges Error", response);
                });
                return deferred.promise;
            };
        return service;
    }])


//Past challenge Based on ID

    .service("pastEventsDetailService",['$log','$http', '$q' ,'APP_CONFIG', function ($log, $http, $q, APP_CONFIG) {
        var service = {};
        service.responseJSON=[];
        service.getPastEventById = function (id) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                 url : APP_CONFIG.BASE_URL + 'challenges/'+id
            })
            .then(function successCallback(response) {
              deferred.resolve({success: true, data: response});
               // console.log('Past Challenge Details Success', response);
            },
                function error(response) {
                    $log.debug("Past Challenge Details Error", response);
                });

                return deferred.promise;
            };
        return service;
    }])

//open challenges detail
  .service("openEventsDetailService",['$log','$http', '$q' ,'APP_CONFIG', function ($log, $http, $q, APP_CONFIG) {
        var service = {};
        service.responseJSON=[];
        service.getOpenEventById = function (id) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                 url : APP_CONFIG.BASE_URL + 'challenges/'+id
            })
            .then(function successCallback(response) {
               // var open = response.data;
             //   var openChallenges = response.data.challenges;
              deferred.resolve({success: true, data: response});
               // console.log('Open Challenge Details Success', response);
            },
                function error(response) {
                    $log.debug("Open Challenge Details Error", response);
                });

                return deferred.promise;
            };
        return service;
    }])



//My entries challenge Based on ID

    .service("MyEventsDetailService",['$log','$http', '$q' ,'APP_CONFIG', function ($log, $http, $q, APP_CONFIG) {
        var service = {};
        service.responseJSON=[];
        service.getMyEventById = function (id) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                 url : APP_CONFIG.BASE_URL + 'challenges/'+id
            })
            .then(function successCallback(response) {
              deferred.resolve({success: true, data: response.data});
                // console.log('My Challenge Details Success', response);
            },
                function error(response) {
                    $log.debug("My Challenge Details Error", response);
                });

                return deferred.promise;
            };
        return service;
    }])

    // Open challenge entry form

    .service('GamificationOpenService',['$q','$state','$http', '$log', 'APP_CONFIG','IonicUtilsService','$ionicLoading',function ($q,$state, $http, $log, APP_CONFIG,IonicUtilsService,$ionicLoading) {
        return ({
            submitentry: submitentry
        });

        function submitentry(data) {
            var submitMsg = "Submitting...";
            if(data.video != undefined){
                submitMsg = "It will take a while to upload video...";
            }

           IonicUtilsService.showLoadingWithTitle(submitMsg);
            var form_data = new FormData()
            //console.log(data.image)
            //console.log(data.video)
            //console.log(data.caption_text)
            if(data.image == undefined || data.video == undefined || data.caption_text == undefined){
                if(data.image != undefined){
                    form_data.append("challenge_entry[image]",data.image);
                }
                if(data.video != undefined){
                    form_data.append("challenge_entry[video]",data.video);
                }
                if(data.caption_text != undefined){
                    form_data.append("challenge_entry[caption_text]",data.caption_text);
                }
            }
            if(data.entry_text != undefined) {
                form_data.append("challenge_entry[entry_text]", data.entry_text)
            }
            // form_data.append("challenge_entry[image]",data.image)
            // form_data.append("challenge_entry[video]",data.video)
            // form_data.append("challenge_entry[caption_text]",data.caption_text)
            var  url = APP_CONFIG.BASE_URL  +'challenges/'+ data.challenge_id+'/entries' 
            //console.log(url);
            var  res = $http.post(url,  form_data,  {
                headers: {
                    'Content-Type':  undefined
                },
                transformRequest:  angular.identity
            })

                res.then(function  successCallback(response) {
                    //deferred.resolve({ success: true, data: response });
                    //$state.go('MyEntriesEventsPage',{'id':data.challenge_id});
                    $ionicLoading.hide();
                    $state.go('GameHomePage');
                return response;
                    //return (response);
            },function errorCallback(resolve) {
                console.log(resolve.data);
                $ionicLoading.hide();
                $state.go('GameHomePage');
            });
        }
    }])


   .service("GamificationWithdrawService",['$log','$http', '$q' ,'APP_CONFIG', 'IonicUtilsService', '$ionicLoading', function ($log, $http, $q, APP_CONFIG, IonicUtilsService,$ionicLoading) {
        var service = {};
        service.responseJSON=[];
        service.withdrawentry = function (entry_id,chall_id) {
            IonicUtilsService.showLoadingWithTitle('Withdrawing......');
            var deferred = $q.defer();
            $http({
                 method: 'DELETE',
                url: APP_CONFIG.BASE_URL + 'challenges/'+chall_id+'/entries/'+entry_id 
            })
            .then(function successCallback(response) {
              deferred.resolve({success: true, data: response.data});
                    $ionicLoading.hide();
                // console.log('Withdraw Success', response);
            },
                function error(response) {
                    $log.debug("Withdraw Error", response);
                });

                return deferred.promise;
            };
        return service;
    }])


// Service for Gamification Score card page

   .service("ScoreCardService",['$log','$http', '$q' ,'APP_CONFIG', 'IonicUtilsService', '$ionicLoading', function ($log, $http, $q, APP_CONFIG, IonicUtilsService, $ionicLoading) {
        var service = {};
        service.responseJSON=[];
        service.getScores = function () {
            //IonicUtilsService.showLoadingWithTitle('Loading point details......');
            var deferred = $q.defer();
            $http({
                method: 'GET',
                 url : APP_CONFIG.BASE_URL + 'activity_logs/'
            })
            .then(function successCallback(response) {
              deferred.resolve({success: true, data: response.data});
                    //$ionicLoading.hide();
                // console.log('Score card Success', response);
            },
                function error(response) {
                    $log.debug("Score card Error", response);
                });

                return deferred.promise;
            };
        return service;
    }])
