angular.module('sensing.controllers', [])

    .controller('pgsensingCtrl', ['$scope', '$filter', '$state', '$ionicHistory', '$ionicLoading', '$stateParams',
        'pgSensingService', 'IonicUtilsService',
        function ($scope, $filter, $state, $ionicHistory, $ionicLoading, $stateParams,
                  pgSensingService, IonicUtilsService) {

            $scope.pendingSurveys = {};
            $scope.$on('$ionicView.beforeEnter', function () {
                IonicUtilsService.showLoadingWithTitle('Getting surveys...');
                pgSensingService.getAllSurveys().then(function (response) {
                    IonicUtilsService.hideLoading();
                    $scope.showNoSurvey = true;
                    $scope.pendingSurveys = response;
                });

            });
            $scope.takeSurvey = function (surveyId) {
                $state.go('surveyDetail', {surveyId: surveyId})
            }


        }])
    .controller('surveyDetail', ['$scope', '$rootScope', '$ionicModal', '$filter', '$state', '$ionicHistory', '$ionicLoading', '$stateParams',
        'pgSensingService', 'IonicUtilsService', '$ionicPopup', 'UserService', 'Analytics',
        function ($scope, $rootScope, $ionicModal, $filter, $state, $ionicHistory, $ionicLoading, $stateParams,
                  pgSensingService, IonicUtilsService, $ionicPopup, UserService, Analytics) {

            $scope.feedback_question = "";
            $scope.id = "";
            $scope.form = {};
            $scope.$on('$ionicView.beforeEnter', function () {
                if ($stateParams.surveyId) {
                    IonicUtilsService.showLoadingWithTitle('Getting survey...');
                    pgSensingService.getSurveyById($stateParams.surveyId).then(function (response) {
                        IonicUtilsService.hideLoading();
                        if (response.survey) {
                            $scope.survey = response.survey;
                            $scope.questions = $scope.survey.questions;
                            if ($scope.survey.feedback_question && $scope.survey.feedback_question !== "") {
                                $scope.feedback_question = {
                                    type: "Feedback",
                                    id: $scope.survey.id + '_feedback',
                                    question: $scope.survey.feedback_question
                                };
                                $scope.questions.push($scope.feedback_question);
                            }
                            $scope.id = $scope.survey.id;
                        }
                    });
                }
            });
            var count = 0;
            $scope.submitSurvey = function () {
                count++;
                if (count === 1) {
                    Analytics.sendEvent("PG Sensing", 'Submit survey', UserService.user.buildings[0].name, UserService.user.building_id);
                    var response = {
                        survey_response: {
                            responses: []
                        }
                    };
                    response.survey_id = $scope.survey.id;
                    $scope.questions.forEach(function (question) {
                        if (question.type === "MCQ With Multiple Answers")
                            response.survey_response.responses.push({
                                question_id: question.id,
                                response: question.response
                            });
                        else if (question.type === "Feedback")
                            response.feedback_response = question.response;
                        else
                            response.survey_response.responses.push({
                                question_id: question.id,
                                response: [question.response]
                            })
                    });
                    if ($scope.validateSurvey(response.survey_response)) {
                        IonicUtilsService.showLoadingWithTitle('Sending survey...');
                        pgSensingService.postSurvey(response).then(function (response) {
                            IonicUtilsService.hideLoading();
                            $scope.surveyThankYou();
                        })
                    }
                }
            };
            $scope.validateSurvey = function (response) {
                for (var i = 0; i < response.responses.length; i++) {
                    if (!(response.responses[i].response && response.responses[i].response.length && response.responses[i].response[0])) {
                        $ionicLoading.show({
                            template: 'Question ' + (i + 1) + ' must be answered',
                            duration: 1000
                        });
                        return false
                    }
                }
                // if ($scope.survey.feedback_question && $scope.survey.feedback_question !== "") {
                //     if(!(response.feedback_response && response.feedback_response!=="")){
                //         $ionicLoading.show({
                //             template: 'Feedback question must be answered',
                //             duration: 1000
                //         });
                //         return false
                //     }
                // }
                return true
            };
            $scope.surveyThankYou = function () {
                $scope.confirmPopup = $ionicPopup.alert({
                    title: '<div class="meetup-alert sensing-alert-header"></div>',
                    cssClass: 'meetup-delete-popup',
                    template: '<div class="meetup-delete">Thank you for your valuable feedback</div>'
                });

                $scope.confirmPopup.then(function (res) {
                    if (res) {
                        $state.go('homeRedesign');
                    }
                });
            };
            $scope.updateQuestionValue = function (currentQuestion, response) {

                $scope.value = currentQuestion.response || [];
                var index = $scope.value.indexOf(response);
                if (index > -1) {
                    $scope.value.splice(index, 1);
                }
                else {
                    $scope.value.push(response);
                }
                currentQuestion.response = $scope.value;
                if (!currentQuestion.response.length) {
                    $scope.form.myForm.$valid = false;
                    $scope.form.myForm.$invalid = true;
                }
                else {
                    $scope.form.myForm.$valid = true;
                    $scope.form.myForm.$invalid = false;
                }
            };
            $scope.$on('$destroy', function () {
                if (angular.isDefined($scope.modal)) {
                    $scope.modal.remove();
                }

                if (angular.isDefined($scope.confirmPopup)) {
                    $scope.confirmPopup.close();
                }
            });
        }]);