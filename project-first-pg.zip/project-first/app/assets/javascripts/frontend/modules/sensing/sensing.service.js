angular.module('sensing.services', [])
    .service('pgSensingService', ['$http', '$log', '$q', 'APP_CONFIG', function ($http, $log, $q, APP_CONFIG) {
        var service = {};
        service.allMeetups = {};
        service.getAllSurveys = function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: APP_CONFIG.BASE_URL + 'surveys/'
            }).then(function successCallback(response) {
                $log.debug("Return from meetups API");
                deferred.resolve(response.data);
            }, function errorCallback(response) {
                $log.debug("Error: meetups API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });


            return deferred.promise;
        };
        service.getSurveyById = function (id) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: APP_CONFIG.BASE_URL + 'surveys/'+id
            }).then(function successCallback(response) {
                $log.debug("Return from meetups API");
                deferred.resolve(response.data);
            }, function errorCallback(response) {
                $log.debug("Error: meetups API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });


            return deferred.promise;
        };
        service.postSurvey = function (survey) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: APP_CONFIG.BASE_URL + 'survey_responses/',
                data: survey
            }).then(function successCallback(response) {
                $log.debug("Return from postSurvey API");
                deferred.resolve(response.data);

            }, function errorCallback(response) {
                $log.debug("Error: postSurvey API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };
        return service;
    }]);
