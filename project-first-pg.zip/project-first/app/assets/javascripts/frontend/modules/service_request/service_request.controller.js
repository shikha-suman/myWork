angular.module('serviceRequest.controllers', [])

//Service controller
//Create ticket
    .controller('ServiceCtrl', ['$scope', '$rootScope', '$http', 'SESSION', '$state', '$stateParams', '$timeout', '$log', '$ionicHistory',
        '$ionicNavBarDelegate', '$ionicLoading', 'IonicUtilsService', 'UserService', 'serviceRequestService', 'getLocationService', 'uploadService',
        'APP_CONFIG', 'Analytics','$ionicPopup',
        function ($scope, $rootScope, $http, SESSION, $state, $stateParams, $timeout, $log, $ionicHistory, $ionicNavBarDelegate, $ionicLoading,
                  IonicUtilsService, UserService, serviceRequestService, getLocationService, uploadService,
                  APP_CONFIG, Analytics , $ionicPopup) {

            // if ($ionicHistory.forwardView() && $ionicHistory.forwardView().stateName == "serviceTicket_details") {
            //
            //     $state.go("serviceRequests.tickethistory.open");
            //     $ionicHistory.forwardView().stateName = null;
            // }

            // toggle edit icon
            $scope.sendGACallAmbassador = function () {
                Analytics.sendEvent("Service Request", 'Call Ambassador', UserService.user.buildings[0].name, UserService.user.building_id);
            };

            $scope.sendGATicketslisting = function (status) {
                Analytics.sendEvent("Service Request", status + ' Tickets listing', UserService.user.buildings[0].name, UserService.user.building_id);
            };

            $scope.goToHistory = function (status) {
                $ionicHistory.removeBackView();
                $state.go('homeRedesign');
            };

            $scope.toggleGroup = function (group) {
                if ($scope.isGroupShown(group)) {
                    $scope.shownGroup = null;
                } else {
                    $scope.shownGroup = group;
                }
            };
            $scope.isGroupShown = function (group) {
                return $scope.shownGroup == group;
            };
            // tabs

            $scope.$on('$ionicView.beforeEnter', function () {
                document.getElementById('ticketHistoryTab').className = 'button button-block button-large barclass ';
                $state.go('serviceRequests.newticket');
                $scope.fetchServiceRequests();
            });

            // Listing all services
            $scope.fetchServiceRequests = function () {
                if (!$scope.fetched) {
                    $scope.fetched = true;
                    IonicUtilsService.showLoadingWithTitle('Loading.....');
                    serviceRequestService.populateServiceTickets().then(function (response) {

                        var ServiceTickets = response.data;

                        $scope.service_list = ServiceTickets.service_requests;
                        if (!$scope.service_list) {
                            $scope.service_list = []
                        }
                     //   getLocationService.callJSON().then(function (response) {
                            IonicUtilsService.hideLoading();
                            $log.debug('Success');

                            var new_region = sessionStorage.getItem("Region");
                            var new_country = sessionStorage.getItem("Country");
                            var new_building = sessionStorage.getItem("Building");
                            var new_floor = sessionStorage.getItem("Floor");

                            $scope.regions = $rootScope.local_regions;
                           // console.log('Regions scope in game controller',$scope.regions);
                            if (new_region == null || new_region == undefined) {

                                $scope.selectedRegionId = UserService.user.region_id;
                                $scope.selectedCountryId = UserService.user.country_id;
                                $scope.selectedBuildingId = UserService.user.building_id;
                                $scope.selectedFloorId = UserService.user.floor_id;

                            } else {
                                $scope.selectedRegionId = new_region;
                                $scope.selectedCountryId = new_country;
                                $scope.selectedBuildingId = new_building;
                                $scope.selectedFloorId = new_floor;
                            }

                            angular.forEach($scope.regions, function (oneRegion) {

                                if ($scope.selectedRegionId == oneRegion.id) {
                                    $scope.data.selectedRegion = oneRegion;
                                    // console.log("oneRegion" + oneRegion);
                                    angular.forEach(oneRegion.countries, function (oneCountry) {
                                        if ($scope.selectedCountryId == oneCountry.id) {
                                            $scope.data.selectedCountry = oneCountry;
                                            angular.forEach(oneCountry.buildings, function (oneBuilding) {
                                                if ($scope.selectedBuildingId == oneBuilding.id) {
                                                    $scope.data.selectedBuilding = oneBuilding;
                                                    $scope.building_name = oneBuilding.name;
                                                    angular.forEach(oneBuilding.floors, function (oneFloor) {

                                                        if ($scope.selectedFloorId == oneFloor.id) {
                                                            $scope.data.selectedFloor = oneFloor;
                                                            $scope.floor_name = oneFloor.name;
                                                            $scope.phoneNum = oneFloor.floor_ambassador_number;
                                                        }
                                                    })
                                                }
                                            })
                                        }
                                    })
                                }

                            });

                      //  })
                    });
                }
            };
            $scope.fetchServiceRequests();

            $scope.data = {};


            $scope.selectedRegion = function (shouldClear) {

                if (shouldClear) {
                    $scope.data.selectedBuildingId = null;
                    $scope.data.selectedFloorId = null;
                    $scope.data.selectedCountryId = null;
                    $scope.data.selectedCountryName = null;
                    $scope.data.selectedBuildingName = null;
                    $scope.data.selectedFloorName = null;
                    $scope.data.selectedCountry = null;
                    $scope.data.selectedBuilding = null;
                    $scope.data.selectedFloor = null;
                }

            };

            $scope.selectedCountry = function (shouldClear) {

                if (shouldClear) {
                    $scope.data.selectedBuildingId = null;
                    $scope.data.selectedFloorId = null;
                    $scope.data.selectedBuildingName = null;
                    $scope.data.selectedFloorName = null;
                    $scope.data.selectedBuilding = null;
                    $scope.data.selectedFloor = null;
                }

            };

            $scope.selectedBuilding = function (shouldClear) {
                if (shouldClear) {
                    $scope.data.selectedFloorId = null;
                    $scope.data.selectedFloorName = null;
                }

                angular.forEach($scope.buildings, function (building) {
                    if ($scope.data.selectedBuildingId == building.id) {
                        $scope.data.selectedBuildingName = building.name;
                        $scope.floors = building.floors;
                    }
                });
            };

            $scope.selectedFloor = function () {

                angular.forEach($scope.floors, function (floor) {
                    if ($scope.data.selectedFloorId == floor.id) {
                        $scope.data.selectedFloorId = floor.id;
                        $scope.data.selectedFloorName = floor.name;

                    }
                });

            };

            //Saving location data
            $scope.updateLocation = function (selectedRegion, selectedCountry, selectedBuilding, selectedFloor) {


                if (selectedRegion && selectedCountry && selectedBuilding && selectedFloor) {
                    Analytics.sendEvent("Service Request", 'Temp location change', 'NA', 'NA');
                    $ionicLoading.show({
                        template: 'Location Updated Succussfully',
                        duration: 1000
                    });
                    sessionStorage.setItem("Region", selectedRegion.id);
                    sessionStorage.setItem("Country", selectedCountry.id);
                    sessionStorage.setItem("Building", selectedBuilding.id);
                    sessionStorage.setItem("Floor", selectedFloor.id);
                    $scope.toggleGroup('group');
                    $scope.floor_name = selectedFloor.name;
                    $scope.building_name = selectedBuilding.name;
                    $scope.selectedRegionId = selectedRegion.id;
                    $scope.selectedCountryId = selectedCountry.id;
                    $scope.selectedBuildingId = selectedBuilding.id;
                    $scope.selectedFloorId = selectedFloor.id;
                }
                $scope.isGroupShown = function (group) {

                    return $scope.shownGroup == group;
                };

            };


            // refreshing tab
            var refreshingData = function () {
                serviceRequestService.populateServiceTickets().then(function (response) {
                    var ServiceTickets = response.data;
                    $scope.service_list = ServiceTickets.service_requests;
                });

                // refreshingData();
            };
            var desc = document.getElementById('ticket_dec');
            if (desc != null) {
                desc.onpaste = function (e) {
                    //do some IE browser checking for e
                    var max = ticket_dec.getAttribute("maxlength");
                    e.clipboardData.getData('text/plain').slice(0, max)
                };
            }
            //Create ticket
            var count = 0;
            $scope.uploadData = function (image, serviceTicket_description) {
                count++;
                if (count === 1) {
                    if (serviceTicket_description == null) {
                        $ionicLoading.show({
                            template: 'Description Required',
                            duration: 1000
                        })
                    }

                    else {
                        $scope.fetched = false;
                        var region = $scope.selectedRegionId;
                        var country = $scope.selectedCountryId;
                        var building = $scope.selectedBuildingId;
                        var floor = $scope.selectedFloorId;
                        var userid = SESSION.USER_ID;
                        if (image != null || image != undefined) {
                            var imgfileSize = Math.round(image.size / 1024);
                            if (imgfileSize > 5120) {
                                $ionicLoading.show({
                                    template: 'Image size should be less than 5MB',
                                    duration: 2000
                                })


                            }
                            else {
                                data = {
                                    region_id: region,
                                    country_id: country,
                                    building_id: building,
                                    floor_id: floor,
                                    user_id: userid,
                                    description: serviceTicket_description,
                                    hero_image: image
                                };
                                Analytics.sendEvent("Service Request", 'Raise ticket', UserService.user.buildings[0].name, UserService.user.building_id);
                                IonicUtilsService.showLoadingWithTitle('Submitting.....');
                                uploadService.upload(data).then(function (res) {
                                    // refreshingData();

                                    IonicUtilsService.hideLoading();

                                    $state.go("serviceRequests.tickethistory");

                                })
                            }

                        }
                        else {
                            data = {
                                region_id: region,
                                country_id: country,
                                building_id: building,
                                floor_id: floor,
                                user_id: userid,
                                description: serviceTicket_description
                            };
                            Analytics.sendEvent("Service Request", 'Raise ticket', UserService.user.buildings[0].name, UserService.user.building_id);
                            IonicUtilsService.showLoadingWithTitle('Submitting.....');
                            uploadService.upload(data).then(function (res) {
                                // refreshingData();

                                IonicUtilsService.hideLoading();

                                $state.go("serviceRequests.tickethistory");

                            })

                        }
                    }
                }
            };

            //Phone number integration
            $scope.callAmbassador = function (selectedFloor) {
                $scope.phoneNum = selectedFloor.floor_ambassador_number;

            };
            //rotating image
            var angle = 0
            $scope.rotateImage = function (){
                img = document.getElementById('imageRotate');
                 angle = (angle+90)%360;
                 img.className = "rotate"+angle;
            }
            
           
            // toggling textarea
            $scope.shouldToggle = false;
            $scope.toggleAsk = function (shouldToggle) {
                if (shouldToggle)
                    $scope.shouldToggle = true;
                else $scope.shouldToggle = false;
            };
            $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
                if (toState.resolve) {
                    IonicUtilsService.showLoadingWithTitle('Loading...');
                }
            });
            $scope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
                if (toState.resolve) {
                    IonicUtilsService.hideLoading();
                }
            });
            $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
                if (fromState.name === "serviceRequests.newticket" && toState.name === "serviceRequests.tickethistory") {
                    event.preventDefault();
                    $scope.fetched = false;
                    $state.go('serviceRequests.tickethistory.open');
                }
                if (fromState.name === "serviceRequests.tickethistory.resolved" && toState.name === "serviceRequests.tickethistory") {
                    event.preventDefault();
                    $state.go('serviceRequests.tickethistory.resolved');
                }
                if (fromState.name === "serviceRequests.tickethistory.open" && toState.name === "serviceRequests.tickethistory") {
                    event.preventDefault();
                    $state.go('serviceRequests.tickethistory.open');
                }
                if (fromState.name === "serviceRequests.tickethistory.inprogress" && toState.name === "serviceRequests.tickethistory") {
                    event.preventDefault();
                    $state.go('serviceRequests.tickethistory.inprogress');
                }
            });

            $scope.confirmCall = function () {
            $scope.confirmPopup = $ionicPopup.confirm({
                title: '<div class="confirmCall_popup"><h2>Confirm Location</h2></div>',
                cssClass: 'meetup-delete-popup',
                template: '<div style="text-align:left;">You are currently on <b>'+$scope.floor_name+'</b>; Click OK to proceed, otherwise, click Cancel and update your floor to reach the right floor ambassador.</div>'
            });

            $scope.confirmPopup.then(function (res) {
                if (res) {
                    document.location.href = "tel:"+$scope.phoneNum;
                }
            });
        };

        }])


    // Tickets Detail controllers
    .controller('tickerDetailCtrl', ['$scope', '$rootScope', '$http', 'SESSION', '$state', '$stateParams', '$timeout',
        '$log', '$ionicHistory', 'IonicUtilsService', 'UserService', 'uploadService', 'ticketDetailService',
        'openTicketService', 'APP_CONFIG', 'ticket_Details', '$ionicLoading', 'Analytics',
        function ($scope, $rootScope, $http, SESSION, $state, $stateParams, $timeout, $log, $ionicHistory,
                  IonicUtilsService, UserService, uploadService, ticketDetailService, openTicketService, APP_CONFIG,
                  ticket_Details, $ionicLoading, Analytics) {

            if (ticket_Details) {
                $scope.ticket_Details = ticket_Details.service_request;
                if ($scope.ticket_Details.hero_image_url === "http://placehold.it/640x360?text=hero-image%20(640x360)")
                    $scope.ticket_Details.hero_image_url = null
            }

            // Reopen ticket
            $scope.reopenTicket = function (ticket_Details) {
                Analytics.sendEvent("Service Request", 'Reopen ticket', UserService.user.buildings[0].name, UserService.user.building_id);
                IonicUtilsService.showLoadingWithTitle('Reopening Ticket...');
                openTicketService.changeStatusbyId(ticket_Details).then(function (response) {
                    IonicUtilsService.hideLoading();
                    $ionicLoading.show({
                        template: 'Ticket Reopened',
                        duration: 1000
                    });
                    $scope.ticket_Details = response.service_request;
                }, function (resolve) {

                });
            };
            // $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
            //     console.log(fromState.name,toState.name)
            //     if (fromState.name === "serviceTicket_details" && toState.name === "serviceRequests") {
            //         $ionicHistory.removeBackView();
            //         $state.go('serviceRequests.tickethistory.open');
            //     }
            // });

            $scope.goToHistory = function (status) {
                $ionicHistory.removeBackView();
                if (status === "OPEN")
                    $state.go('serviceRequests.tickethistory.open');
                else if (status === "IN_PROGRESS")
                    $state.go('serviceRequests.tickethistory.inprogress');
                else if (status === "RESOLVED")
                    $state.go('serviceRequests.tickethistory.resolved');

            }

            // //rotating image
               var angle= 0;
            $scope.rotateImageHistory = function (){             
                var img = document.getElementById('imageRotate');
                 angle = (angle+90)%360;
                 img.className = "rotate"+angle;
            }

//                 $scope.rotateImageHistory = function(degree)
// {
//     if(document.getElementById('imageRotate')){
//        var cContext = canvas.getContext('2d');
//        var cw = img.width, ch = img.height, cx = 0, cy = 0;

//        //   Calculate new canvas size and x/y coorditates for image
//        switch(degree){
//             case 90:
//                 cw = img.height;
//                 ch = img.width;
//                 cy = img.height * (-1);
//                 break;
//             case 180:
//                 cx = img.width * (-1);
//                 cy = img.height * (-1);
//                 break;
//             case 270:
//                 cw = img.height;
//                 ch = img.width;
//                 cx = img.width * (-1);
//                 break;
//        }

//         //  Rotate image            
//         canvas.setAttribute('width', cw);
//         canvas.setAttribute('height', ch);
//         cContext.rotate(degree * Math.PI / 180);
//         cContext.drawImage(img, cx, cy);
//     } else {
//         //  Use DXImageTransform.Microsoft.BasicImage filter for MSIE
//         switch(degree){
//             case 0: image.style.filter = 'progid:DXImageTransform.Microsoft.BasicImage(rotation=0)'; break;
//             case 90: image.style.filter = 'progid:DXImageTransform.Microsoft.BasicImage(rotation=1)'; break;
//             case 180: image.style.filter = 'progid:DXImageTransform.Microsoft.BasicImage(rotation=2)'; break;
//             case 270: image.style.filter =    'progid:DXImageTransform.Microsoft.BasicImage(rotation=3)'; break;
//         }
//     }
// }

        }]);