 angular.module('serviceRequest.directives', [])
 .directive("limitTo", [function () {
        return {
            restrict: "A",
            link: function (scope, elem, attrs) {
                var limit = parseInt(attrs.limitTo);
                angular.element(elem).on("keypress", function (e) {
                    if (this.value.length == limit) e.preventDefault();
                });
            }
        }
    }])

    .directive('validFile', function () {
    return {
        require: 'ngModel',
        link: function (scope, el, attrs, ngModel) {
            ngModel.$render = function () {
                ngModel.$setViewValue(el.val());
            };

            el.bind('change', function () {
                scope.$apply(function () {
                    ngModel.$render();
                });
            });
        }
    };
}); 
//  .directive('checkFileSize', function() {
//   return {
//     link: function(scope, elem, attr, ctrl) {
//       function bindEvent(element, type, handler) {
//         if (element.addEventListener) {
//           element.addEventListener(type, handler, false);
//         } else {
//           element.attachEvent('on' + type, handler);
//         }
//       }

//       bindEvent(elem[0], 'change', function() {
//           var filesize = this.files[0].size;
//           if(filesize > 5120){
//            $ionicLoading.show({
//                 template: '<p>Upload image size should be less than 5MB</p>',
//                 duration: 2000
//             });
//           }

//        // alert('File size:' + this.files[0].size);
//       });
//     }
//   }
// }); 
