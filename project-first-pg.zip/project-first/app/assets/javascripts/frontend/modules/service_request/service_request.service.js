angular.module('serviceRequest.services', [])
//Service Request Service

    .service('serviceRequestService', ['$log', '$q', '$http', 'APP_CONFIG', function ($log, $q, $http, APP_CONFIG) {
        var service = {};
        service.responseJSON = [];
        service.populateServiceTickets = function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',

                url: APP_CONFIG.BASE_URL + 'service_requests/'


            }).then(function successCallback(response) {
                    //  var selectedBuilding = response.data.building;
                    // service.selectedBuilding = selectedBuilding;
                    // deferred.resolve(selectedBuilding);

                    var service_tickets = response.data;

                    service.service_tickets = service_tickets;
                    deferred.resolve({success: true, data: service_tickets});
                    // deferred.resolve(selectedBuilding);

                },
                function errorCallback(response) {
                    $log.debug("ERROR persist serviceRequestService", response);
                    //TODO: Fix up all resolves into rejects!!!!
                    // deferred.reject({success: false, data: service.selectedBuilding});
                });

            return deferred.promise;
        };


        return service;
    }])

    /** Serveice to upload image */

    .service("uploadService", function ($http, $q, APP_CONFIG) {
// console.log("This is inside the upload service");
        return ({
            upload: upload
        });

        function upload(data) {

            var form_data = new FormData();
            form_data.append("service_request[region_id]", data.region_id);
            form_data.append("service_request[country_id]", data.country_id);
            form_data.append("service_request[floor_id]", data.floor_id);
            form_data.append("service_request[building_id]", data.building_id);
            form_data.append("service_request[user_id]", data.user_id);
            form_data.append("service_request[description]", data.description);
            form_data.append("service_request[hero_image]", data.hero_image);

            var url = APP_CONFIG.BASE_URL + 'service_requests/';
            var res = $http.post(url, form_data, {
                headers: {
                    'Content-Type': undefined
                },
                transformRequest: angular.identity
            });

            return res.then(handleSuccess, handleError);

        } // End upload service
        function handleError(response, data) {
            if (!angular.isObject(response.data) || !response.data.message) {
                return ($q.reject("An unknown error occurred."));
            }

            return ($q.reject(response.data.message));
        }

        function handleSuccess(response) {
            // console.log("Service Response" + response);
            return (response);
        }

    })


    /** Get Ticket details */

    .service("ticketDetailService", ['$log', '$http', '$q', 'APP_CONFIG', function ($log, $http, $q, APP_CONFIG) {
        var service = {};
        service.responseJSON = [];
        service.ticketDetails = function (ticket_id) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: APP_CONFIG.BASE_URL + 'service_requests/' + ticket_id

            }).then(function success(response) {
                    var details = response.data;
                    // console.log('Request detail based on id', details);
                    deferred.resolve(details);
                },
                function error(response) {
                    $log.debug("Error", response);
                });

            return deferred.promise;
        };
        return service;
    }])

    //dropdown location
    .service("getLocationService", ['$log', '$http', '$q', 'APP_CONFIG', function ($log, $http, $q, APP_CONFIG) {

        var service = {};
        service.responseJSON = [];

        service.callJSON = function () {
            var deferred = $q.defer();

            $http({
                method: 'GET',
                url: APP_CONFIG.BASE_URL + 'regions'
            }).then(function success(response) {
                $log.debug('callJSON', response);
                //Handle response
                // service.user = response;
                deferred.resolve({regions: response});

            });
            return deferred.promise;
            //BuildingService.buildings = response.data.user.buildings;
        }
        return service;
    }])

    //Service for reopening the ticket_id

    .service("openTicketService", ['$log', '$http', '$q', 'SESSION', 'APP_CONFIG', function ($log, $http, $q, SESSION, APP_CONFIG) {

        var service = {};
        service.responseJSON = [];

        service.changeStatusbyId = function (ticket_id) {
            var deferred = $q.defer();
            //Persist on backend
            $http({
                method: 'PUT',
                url: APP_CONFIG.BASE_URL + 'service_requests/' + ticket_id + '/reopen'


            }).then(function successCallback(response) {

                $log.debug("Ticket re-opened ", response);
                deferred.resolve(response.data);
            }, function errorCallback(response) {
                $log.debug("Error in re-opening the ticket", response);
                deferred.reject({success: false, data: response.data});
            });

            return deferred.promise;
        }
        return service;
    }])

// Service for updating the location of the user Important: Commented as of now , do not delete
//     .service("updateLocationService",['$log','$http', '$q' ,'SESSION','APP_CONFIG', function ($log, $http, $q,SESSION, APP_CONFIG) {

//   var service = {};
//     service.responseJSON=[];

// service.updateLocationByUserId = function (reg, con, build, floor) {
//             var deferred = $q.defer();
//             //Persist on backend
//             $http({
//                 method: 'PUT',
//                 url: APP_CONFIG.BASE_URL + 'users/' + SESSION.USER_ID,
//                 data: {
//                     user: {
//                         region_id: reg.id,
//                         country_id: con.id,
//                         building_id : build.id,
//                         floor_id :floor.id
//                     }
//                 }
//             }).then(function successCallback(response) {

//                 $log.debug("updateLocationByUserId " , response);

//                 //Returns updated user object
//                 //BuildingService.setSelectedBuildingById(response.data.user.building_id);

//                 deferred.resolve({success: true, data: response.data});
//             }, function errorCallback(response) {
//                 $log.debug("ERROR persist updateLocationByUserId", response);
//                 //TODO: Fix up all resolves into rejects!!!!
//                 //deferred.reject({success: false});
//             });

//             return deferred.promise;
//         }
//         return service;
// }])

