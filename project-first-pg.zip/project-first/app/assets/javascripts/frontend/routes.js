/**
 * My P&G Office - Routes
 */

angular.module('app.routes', []).config(function ($stateProvider, $urlRouterProvider) {

    // Ionic uses AngularUI Router which uses the concept of states
    // Learn more here: https://github.com/angular-ui/ui-router
    // Set up the various states which the app can be in.
    // Each state's controller can be found in controllers.js
    $stateProvider.state('home', {
        url: '/home-old',
        templateUrl: 'templates/home.html',
        controller: 'homeCtrl'
    })
        .state('homeRedesign', {
            url: '/home',
            templateUrl: 'templates/home-redesign.html',
            controller: 'homeRedesignCtrl'
        })
        .state('splash', {
            url: '/',
            templateUrl: 'templates/splash.html',
            controller: 'splashCtrl'
        })

        .state('onboarding', {
            url: '/onboarding',
            templateUrl: 'templates/onboarding.html',
            controller: 'onboardingCtrl'
        })

        /*
         .state('energy', {
         url: '/energy',
         templateUrl: 'templates/energyOMeter.html',
         controller: 'energyCtrl'
         })*/

        .state('buildingInfo', {
            url: '/building-info',
            templateUrl: 'templates/buildingInfo.html',
            controller: 'buildingInfoCtrl'
        })

        //Tabs on building Info screen
        .state('buildingInfo.amenities', {
            url: '/amenities',
            templateUrl: 'templates/partials/buildingInfo.amenities.html',
            controller: 'buildingInfoCtrl'
        })

        .state('amenities', {
            url: '/amenities',//was :type/:typeName/:icon
            params: {
                'type': null,
                'typeName': null,
                'icon': null
            },
            templateUrl: 'templates/amenities.html',
            controller: 'amenitiesCtrl'
        })

        .state('amenity', {
            url: '/amenity/:id',
            templateUrl: 'templates/amenityDetail.html',
            controller: 'amenityDetailCtrl',
            resolve: {
                amenity: function ($stateParams, BuildingService) {
                    return BuildingService.getAmenityById($stateParams.id);
                }
            }
        })

        .state('buildingInfo.contacts', {
            url: '/contacts',
            templateUrl: 'templates/partials/buildingInfo.contacts.html',
            controller: 'buildingInfoCtrl'
        })

        .state('contacts', {
            url: '/contacts',
            params: {
                'type': null,
                'typeName': null,
                'icon': null
            },
            templateUrl: 'templates/contacts.html',
            controller: 'contactsCtrl'
        })

        .state('vendors', {
            url: '/retailers',
            templateUrl: 'templates/vendors.html',
            controller: 'vendorsCtrl'
        })

        .state('vendorDetail', {
            url: '/retailer/:id',
            templateUrl: 'templates/vendorDetail.html',
            controller: 'vendorDetailCtrl',
            resolve: {
                vendor: function ($stateParams, BuildingService) {
                    return BuildingService.getVendorById($stateParams.id);
                }
            }
        })

        .state('dealsEvents', {
            url: '/deals-events',
            templateUrl: 'templates/dealsEvents.html',
            controller: 'dealsEventsCtrl',
            params: {
                'vendorId': null
            }
        })


        .state('deal', {
            url: '/deal/:id',
            templateUrl: 'templates/deal.html',
            controller: 'dealCtrl',
            resolve: {
                deal: function ($stateParams, BuildingService) {
                    return BuildingService.getDealById($stateParams.id);
                }
            }
        })

        .state('event', {
            url: '/event/:id',
            templateUrl: 'templates/event.html',
            controller: 'eventCtrl',
            resolve: {
                event: function ($stateParams, BuildingService) {
                    return BuildingService.getEventById($stateParams.id);
                }
            }
        })

        .state('vibrantLiving', {
            url: '/vibrant-living',
            templateUrl: 'templates/vibrantLiving.html',
            controller: 'vibrantLivingCtrl',
            params: {
                'selectedTab': 'deals'
            }
        })

        .state('roomFinder', {
            external: true,
            showAlert: false,
            externalServiceName: 'Room Finder',
            api_node: 'room_finder_url' //marked so they can be navigated from an excluded from some buildings buttons
        })

        .state('serviceRequests', {
            url: '/pg-services',
            templateUrl: 'templates/Servicelanding.html',
            controller: 'ServiceCtrl',
            cache: false,
            params: {
                'tab': null
            }

        })
        .state('serviceRequests.newticket', {
            url: '/newticket',
            templateUrl: 'templates/partials/newticket.html',
            controller: 'ServiceCtrl',
            cache: false


        })
        .state('serviceRequests.tickethistory', {
            url: '/tickethistory',
            templateUrl: 'templates/partials/tickethistory.html',
            controller: 'ServiceCtrl',
            cache: false


        })
        .state('serviceRequests.tickethistory.open', {
            url: '/open',
            templateUrl: 'templates/partials/openTicket.html',
            controller: 'ServiceCtrl',
            cache: false


        })
        .state('serviceRequests.tickethistory.inprogress', {
            url: '/inprogress',
            templateUrl: 'templates/partials/inprogressTicket.html',
            controller: 'ServiceCtrl',
            cache: false


        })
        .state('serviceRequests.tickethistory.resolved', {
            url: '/resolved',
            templateUrl: 'templates/partials/resolvedTicket.html',
            controller: 'ServiceCtrl',
            cache: false


        })
        .state('serviceTicket_details', {
            url: '/ticket_details/:id',
            templateUrl: 'templates/ticket-detail-page.html',
            controller: 'tickerDetailCtrl',
            params: {
                'ticket_Details': null
            },
            resolve: {
                ticket_Details: function ($stateParams, ticketDetailService) {
                    return ticketDetailService.ticketDetails($stateParams.id);
                }
            },
            cache: false
        })
        //.state('serviceRequests', {
        //external: true,
        // showAlert: false,
        // externalServiceName: 'Service Request',
        // api_node: 'service_requests_url' //marked so they can be navigated from an excluded from some buildings buttons
        // })

        .state('concur', {
            external: true,
            showAlert: false,
            externalServiceName: 'Concur',
            api_node: 'concur_url' //marked so they can be navigated from an excluded from some buildings buttons
        })

        .state('parkingTransport', {
            url: '/parking-and-transport',
            templateUrl: 'templates/parking.html',
            controller: 'parkingCtrl'
        })

        .state('location-map', {
            url: '/parking-and-transport/location-map',
            templateUrl: 'templates/location-map.html',
            controller: 'parkingCtrl'
        })

        .state('getting-here', {
            url: '/parking-and-transport/getting-here',
            templateUrl: 'templates/parking.transport.html',
            controller: 'parkingCtrl'
        })

        .state('parking-nearby', {
            url: '/parking-and-transport/parking-nearby',
            templateUrl: 'templates/parking.nearby.html',
            controller: 'parkingCtrl'
        })

        .state('parking-onsite', {
            url: '/parking-and-transport/parking-onsite',
            templateUrl: 'templates/parking.onsite.html',
            controller: 'parkingCtrl'
        })

        .state('parking-carcharging', {
            url: '/parking-and-transport/car-charging',
            templateUrl: 'templates/parking.carcharging.html',
            controller: 'parkingCtrl'
        })

        .state('parking-bikeracks', {
            url: '/parking-and-transport/bike-racks',
            templateUrl: 'templates/parking.bikeracks.html',
            controller: 'parkingCtrl'
        })

        .state('taxicabs', {
            url: '/taxicabs',
            templateUrl: 'templates/taxicabs.html',
            controller: 'taxicabsCtrl'
        })

        .state('dining', {
            url: '/dining',
            templateUrl: 'templates/dining.html',
            controller: 'diningCtrl'
        })

        .state('announcements', {
            url: '/announcements',
            templateUrl: 'templates/announcements.html',
            controller: 'announcementsCtrl'
        })

        .state('announcement', {
            url: '/announcement/:id',
            templateUrl: 'templates/announcement.html',
            controller: 'announcementCtrl',
            resolve: {
                announcement: function ($stateParams, BuildingService) {
                    return BuildingService.getAnnouncementByID($stateParams.id);
                }
            }
        })

        .state('settings', {
            url: '/settings',
            templateUrl: 'templates/settings.html',
            controller: 'settingsCtrl'
        })

        .state('information', {
            url: '/information',
            templateUrl: 'templates/information.html',
            controller: 'informationCtrl'
        })

        .state('about-app', {
            url: '/information',
            templateUrl: 'templates/information.about-app.html',
            controller: 'informationCtrl'
        })

        .state('about-png', {
            url: '/information',
            templateUrl: 'templates/information.about-png.html',
            controller: 'informationCtrl'
        })

        .state('privacy-policy', {
            url: '/privacy-policy',
            templateUrl: 'templates/privacy.html',
            controller: 'informationCtrl'
        })  //pg ask  home starts

        .state('pgAsk', {
            url: '/pg-ask',
            templateUrl: 'templates/pgAsk.html',
            controller: 'PgAskHomeCtrl',
            cache: false
        })


        //Tabs on pg ask home screen
        .state('pgAsk.created', {
            url: '/created',
            templateUrl: 'templates/partials/pgAsk.created.html',
            controller: 'PgAskHomeCtrl',
            cache: false
        })


        .state('pgAsk.attended', {
            url: '/attended',
            templateUrl: 'templates/partials/pgAsk.attended.html',
            controller: 'PgAskHomeCtrl',
            cache: false
        })

        .state('create-meetup', {
            url: '/pg-ask/create',
            templateUrl: 'templates/create-event-pgask.html',
            controller: 'CreateEvent',
            params: {
                meetup: null
            },
            cache: false
        })
        .state('edit-meetup', {
            url: '/pg-ask/edit',
            templateUrl: 'templates/create-event-pgask.html',
            controller: 'CreateEvent',
            params: {
                meetup: null
            },
            cache: false
        })

        .state('meetupDetail', {
            url: '/pg-ask/:id',
            templateUrl: 'templates/meetup-detail.html',
            controller: 'MeetupDetailCtrl',
            resolve: {
                meetup: function ($stateParams, pgAskService) {
                    return pgAskService.getMeetupById($stateParams.id);
                }
            },
            params: {
                meetupDetails: null,
                key: null,
                type: null
            },
            cache: false
        })
        .state('meetupPresentation', {
            url: '/pg-ask/presentation/:id',
            templateUrl: 'templates/meetup-presentation.html',
            controller: 'MeetupDetailCtrl',
            resolve: {
                meetup: function ($stateParams, pgAskService) {
                    return pgAskService.getMeetupById($stateParams.id);
                }
            },
            params: {
                meetupDetails: null,
                key: null,
                type: null
            },
            cache: false
        })
        .state('pgSensing', {
            url: '/pg-sensing',
            templateUrl: 'templates/pg-sensing.html',
            controller: 'pgsensingCtrl',
            cache: false
        })
        .state('surveyDetail', {
            url: '/survey',
            templateUrl: 'templates/survey-detail.html',
            controller: 'surveyDetail',
            params: {
                surveyId: null
            },
            cache: false
        })
        //gamification home page starts

        .state('GameHomePage', {
            url: '/gamification-home-page',
            templateUrl: 'templates/GameHomePage.html',
            controller: 'GameHomePageCtrl'
        })

        .state('GameHomePage.myentries', {
            url: '/myentries',
            templateUrl: 'templates/partials/GameHomePage.myentries.html',
            controller: 'GameHomePageCtrl'
        })


        .state('GameHomePage.pastentries', {
            url: '/pastentries',
            templateUrl: 'templates/partials/GameHomePage.pastentries.html',
            controller: 'GameHomePageCtrl'
        })

        .state('GameScorePage', {
            url: '/gamification-score-page',
            templateUrl: 'templates/GamePointsDetailPage.html',
            controller: 'GameScorePageCtrl'
        })

        //gamification past events page starts

        .state('GamePastEventsPage', {
            url: '/gamification-past-events-page',
            templateUrl: 'templates/GamePastEventsPage.html',
            controller: 'GameDetailCtrl',
            params: {
                'id': null
            }
        })

        .state('GameOpenEventsPage', {
            url: '/gamification-open-events-page',
            templateUrl: 'templates/GameOpenChalngDetail.html',
            controller: 'GameOpenDetailCtrl',
            params: {
                'id': null
            }
        })


        .state('MyEntriesEventsPage', {
            url: '/gamification-open-events-page',
            templateUrl: 'templates/GameWithdrawEntryPage.html',
            controller: 'GameMyEntriesDetailCtrl',
            params: {
                'id': null
            }
        })

        .state('Viewall', {
            url: '/gamification-viewall',
            templateUrl: 'templates/gamification_viewall.html',
            controller: 'GameViewallCtrl'
        })
        //gamification view all entries and winners
        .state('GameViewAll', {
            url: '/gamification-viewallEntries-page',
            templateUrl: 'templates/GameViewAllEntries.html',
            controller: 'GameViewAllEntriesCtrl'
        })
         .state('GameViewAll.myentries', {
            url: '/myentries',
            templateUrl: 'templates/partials/GameViewAll.myentries.html',
            controller: 'GameViewAllEntriesCtrl'
        })


        .state('GameViewAll.pastentries', {
            url: '/pastentries',
            templateUrl: 'templates/partials/GameViewAll.pastentries.html',
            controller: 'GameViewAllEntriesCtrl'
        });


    //https://scotch.io/tutorials/3-simple-tips-for-using-ui-router

    //$stateProvider.state("otherwise", {
    //  url: "*path",
    //  template: "",
    //  controller: ['$state',
    //    function($state) {
    //      $state.go('splash');
    //    }]
    //});

    $urlRouterProvider.otherwise('/');

});
