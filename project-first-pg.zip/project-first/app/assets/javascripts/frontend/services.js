/**
 * My P&G Office - Services
 */

angular.module('app.services', [])

    .service('UserService', ['$q', '$http', '$log', '$window', 'APP_CONFIG', 'SESSION', 'BuildingService', function ($q, $http, $log, $window, APP_CONFIG, SESSION, BuildingService) {

        var service = {};

        service.user = undefined;

        //Building is selected and available, User is loaded and has building set
        service.isAllDataLoaded = function () {
            return angular.isDefined(service.user) && angular.isDefinedAndNotNull(service.user.building_id) && angular.isDefinedAndNotNull(service.user.floor_id) && angular.isDefined(BuildingService.selectedBuilding);
        };

        //Has user has mobile number updated?
        service.isMobileNumberUpdated = function () {
            return angular.isDefined(service.user) && angular.isDefinedAndNotNull(service.user.phone);
        };

        //User has a building selected and has completed onboarding
        service.isOnboardingComplete = function () {
            return angular.isDefined(service.user) && angular.isDefinedAndNotNull(service.user.building_id) && angular.isDefinedAndNotNull(service.user.floor_id) && service.user.onboarding_complete == true;
        };

        /*
         User Object server example return
         user:{
         //These fields are update-able and return the updated user object
         building_id:1
         email:"mypgoffice.im@pg.com"
         onboarding_complete:true
         phone:"+441235166821"
         send_sms_announcements:true,
         preferences:"",
         //These following fields are related and are dealt with by their own separate API calls
         deal_redemptions:Array[2]      --> [{deal_id:2},{deal_id:4}...] (only create)
         announcement_views:Array[8]    --> [{announcement_id:2},{announcement_id:4}...] (only create)
         event_attendances:Array[4]     --> [{event_id:2},{event_id:4}...] (can create + delete)
         vendor_likes                   --> [{vendor_id:2},{vendor_id:4}...] (can create + delete)
         }
         */

        service.getUser = function () {

            var deferred = $q.defer();

            var userEndPt = APP_CONFIG.BASE_URL + 'users/' + SESSION.USER_ID;

            $http({
                method: 'GET',
                url: userEndPt
            }).then(function success(response) {
                $log.debug('getUser', response);
                //Handle response
                service.user = response.data.user;
                if (service.user.phone)
                    service.user.phone = parseInt(service.user.phone);
                BuildingService.buildings = response.data.user.buildings;

                //Select building if its set!
                if (angular.isDefined(service.user) && angular.isDefinedAndNotNull(service.user.building_id)) {
                    BuildingService.setSelectedBuildingById(service.user.building_id);
                }

                deferred.resolve({user: response.data.user});

            }, function error(response) {
                $log.debug("ERROR User");
                $log.warn(response);
                deferred.reject({error: response});
            });

            return deferred.promise;

        };

        service.updateSelectedBuildingById = function (regionID, countryID, userBuildingId, floorID) {
            var deferred = $q.defer();

            //Persist on backend
            $http({
                method: 'PUT',
                url: APP_CONFIG.BASE_URL + 'users/' + SESSION.USER_ID,
                data: {
                    user: {
                        building_id: userBuildingId,
                        region_id: regionID,
                        country_id: countryID,
                        floor_id: floorID
                    }
                }
            }).then(function successCallback(response) {

                $log.debug("updateSelectedBuildingById ", response);

                //Returns updated user object
                BuildingService.setSelectedBuildingById(response.data.user.building_id);

                deferred.resolve({success: true, data: response.data});
            }, function errorCallback(response) {
                $log.debug("ERROR persist updateSelectedBuildingById", response);
                //TODO: Fix up all resolves into rejects!!!!
                deferred.reject({success: false, data: service.selectedBuilding});
            });

            return deferred.promise;
        };
        service.callJSON = function () {
            var deferred = $q.defer();

            $http({
                method: 'GET',
                url: APP_CONFIG.BASE_URL + 'regions'
            }).then(function success(response) {
                $log.debug('callJSON', response);
                if (response.data.regions) {
                    var regions = response.data.regions;
                    response.data.regions = regions.filter(function (region) {
                        return region.is_active === true
                    });
                }
                //Handle response
                // service.user = response;
                deferred.resolve({regions: response});

            });
            return deferred.promise;
            //BuildingService.buildings = response.data.user.buildings;
        };
        /**
         * Returns both users and all buildings - redundant code as user now returns nested buildings array
         * @returns {promise}
         */
        /*
         service.getBuildingsAndUser = function () {

         var userEndPt = APP_CONFIG.BASE_URL + 'users/' + SESSION.USER_ID;
         var buildingsEndPt = APP_CONFIG.BASE_URL + 'buildings';

         function getUser() {
         return $http({method: 'GET', url: userEndPt});
         }

         function getBuildings() {
         return $http({method: 'GET', url: buildingsEndPt});
         }

         var promises = {
         user: getUser(),
         buildings: getBuildings()
         };

         // //If you provide promises as an array, then the values will be available as an array with the same corresponding order of the promises array.

         var deferred = $q.defer();

         $q.all(promises).then(
         function (response) {
         // success
         $log.debug('getBuildingsAndUser', response);
         //Handle response
         service.user = response.user.data.user;
         BuildingService.buildings = response.buildings.data.buildings;
         //Select building if its set!
         if (angular.isDefined(service.user) && angular.isDefinedAndNotNull(service.user.building_id)) {
         BuildingService.setSelectedBuildingById(service.user.building_id);
         }

         //Log out user
         $log.debug(response.user.data.user);

         deferred.resolve({user: response.user.data.user, buildings: response.buildings.data.buildings});
         },
         function (errors) {
         // error
         $log.warn(errors);
         deferred.reject(errors.statusText + " [" + errors.status + "]");
         }
         );

         return deferred.promise;

         };
         */


        /**
         * Refreshes current user and building
         * @returns {promise}
         */
        /*

         Out of scope so not being used
         service.refreshUserAndBuilding = function () {

         var deferred = $q.defer();

         var buildingURL = APP_CONFIG.BASE_URL + 'buildings/' + BuildingService.selectedBuilding.id;
         var userURL = APP_CONFIG.BASE_URL + 'users/' + SESSION.USER_ID;

         //then(successCallback, errorCallback)

         $http.get(buildingURL).then(function (result) {

         //Update building
         BuildingService.selectedBuilding = result.data.building;

         $http.get(userURL).then(function (response) {
         //Update User
         service.user = response.data.user;
         deferred.resolve({
         success: true,
         message: response.status,
         building: result.data.building,
         user: response.data.user
         });
         }, function (error) {
         $log.warn(error);
         deferred.reject({
         success: false,
         message: "An error occurred accessing the API. Status: " + error.status + " " + error.statusText
         });
         });

         }, function (error) {
         $log.warn(error);
         deferred.reject({
         success: false,
         message: "An error occurred accessing the API. Status: " + error.status + " " + error.statusText
         });
         });


         return deferred.promise;

         };
         */

        service.setOnboardingComplete = function () {
            //window.localStorage['didOnboarding'] = true; - set as done
            if (service.user.onboarding_complete) {
                var deferred = $q.defer();
                deferred.resolve({success: false, message: 'Onboarding already marked as completed'});
                return deferred.promise;
            }
            ;

            //Persist on backend
            var dataObj = {
                user: {
                    onboarding_complete: true
                }
            };

            return service.callAPI(dataObj, 'onboarding completed');
        };

        service.subscribeForSMS = function (number, subscribe) {

            // //Blank out number if not subscribing
            // if (!subscribe) {
            //     number = '';
            // }

            //Persist on backend
            var dataObj = {
                user: {
                    building_id: BuildingService.selectedBuilding.id,
                    send_sms_announcements: subscribe,
                    phone: number
                }
            };

            return service.callAPI(dataObj, 'SMS subscription');
        };

        service.updateMobileNumber = function (number, subscribe) {
            var dataobj;
            if (!subscribe) {
                dataObj = {
                    user: {
                        building_id: BuildingService.selectedBuilding.id,
                        phone: number
                    }

                };
            } else {
                dataObj = {
                    user: {
                        building_id: BuildingService.selectedBuilding.id,
                        send_sms_announcements: subscribe,
                        phone: number
                    }
                };
            }

            return service.callAPI(dataObj, 'Profile');
        };

        /**
         * Checks if a user has liked a vendor already
         * @param vendorId
         * @returns {boolean}
         */
        service.getUserLikesVendorId = function (vendorId) {
            var likes = service.user.vendor_likes;// returns array of vendor like objects [{vendor_id:1},{vendor_id:3}]

            for (var i = 0; i < likes.length; i++) {
                if (likes[i].vendor_id == vendorId) {
                    return true;
                }
            }
            return false;
        };

        service.likeVendor = function (like, vendor) {

            //No user return
            var method = like ? 'POST' : 'DELETE';
            var dataObj = {
                vendor_like: {
                    vendor_id: vendor.id
                }
            };

            if (like) {
                service.user.vendor_likes.push({vendor_id: vendor.id});
            } else {
                for (var i = 0; i < service.user.vendor_likes.length; i++) {
                    if (service.user.vendor_likes[i].vendor_id == vendor.id) {
                        service.user.vendor_likes.splice(i, 1);
                    }
                }
            }

            return service.callAPI(dataObj, 'Like vendor', method, '/vendor_like');
        };

        service.updatePreferences = function (buttonOrder) {
            //Persist on backend
            var dataObj = {
                user: {
                    building_id: BuildingService.selectedBuilding.id,
                    preferences: {
                        homeButtons: buttonOrder
                    }
                }
            };

            return service.callAPI(dataObj, 'User preferences');
        };

        // service.attendEvent = function (willAttend, event_id) {

        //     $log.debug("service.attendEvent", willAttend, event_id);

        //     //Check if attending already if you want to attend
        //     if (willAttend && service.isAttendingEventWithId(event_id)) {
        //         var deferred = $q.defer();
        //         deferred.resolve({success: false, message: 'Already attending event'});
        //         return deferred.promise;
        //     }

        //     //Persist on backend
        //     var method = willAttend ? 'POST' : 'DELETE';
        //     var dataObj = {
        //         event_attendance: {
        //             event_id: event_id
        //         }
        //     };

        //     return service.callAPI(dataObj, 'Event attendance', method, '/event_attendance');
        // };

          service.attendEvent = function (event_id) {
          
            $log.debug("service.attendEvent", event_id);
            // for(var i=0; i< event_id.length;i++)
            // {
            // //         // Check if attending already if you want to attend
            // // if (willAttend && service.isAttendingEventWithId(event_id[i])) {
            // //     var deferred = $q.defer();
            // //     deferred.resolve({success: false, message: 'Already attending event'});
            // //     return deferred.promise;
            // // }
            // }
           
            //Persist on backend
            var method = 'POST';
            var dataObj = {
                event_attendance: {
                    event_id: event_id
                }
            };
           
            return service.callAPI(dataObj, 'Event attendance', method, '/event_attendance');
        };
         service.unattendEvent = function (event_id) {
          
            $log.debug("service.attendEvent", event_id);
      
           
            //Persist on backend
            var method = 'DELETE';
            var dataObj = {
                event_attendance: {
                    event_id: event_id
                }
            };
           
            return service.callAPI(dataObj, 'Event attendance', method, '/event_attendance');
        };

        service.updateEventAttendingState = function () {
            var events = BuildingService.selectedBuilding.events;
            for (var i = 0; i < events.length; i++) {

                var e = events[i];
                var isAttending = service.isAttendingEventWithId(e.id);

                e.attending = isAttending;


            }

        };


        service.isAttendingEventWithId = function (eventId) {
         
            var events = service.user.event_attendances;// returns array of event ids as objects [{event_id:2},{event_id:4}...]
               
            $log.debug('isAttendingEvent eventID', eventId, events);

            for (var i = 0; i < events.length; i++) {

                
                    if (events[i].event_id == eventId) {
                        return true;
                    }
                
                
            }
            return false;

        };

        service.isAttendingEventRecurring = function (eventId) {
            var deferred = $q.defer();
            //http://localhost:3000/api/v1/events/23/attending
            $http({
                method: 'GET',
                url: APP_CONFIG.BASE_URL + 'events/' + eventId +'/attending'
            }).then(function successCallback(response) {
                $log.debug("Return from attending API");
                service.attendstatus = response.data;
                deferred.resolve(service.attendstatus);
            }, function errorCallback(response) {
                $log.debug("Error: attendance API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        }
        
      service.recurEvent = function() {
           var deferred = $q.defer();
            $http({
                method:'GET',
                url: APP_CONFIG.BASE_URL + 'events'
               
            }).then(function successCallback(response){
              // console.log("serviceResponse" +response.data);
                 deferred.resolve({success: true, data: response.data});
            },function errorCallback(response) {
                $log.debug("ERROR Event Recurring");
                $log.warn(response);
                deferred.resolve({success: false, message: 'Error in Event recurring ' + response});
            });
            
            return deferred.promise;
      };
        service.downloadICS = function (calendarIDs) {
            console.log('calender array'+calendarIDs);

            var deferred = $q.defer();

            $http({
                method: 'GET',
               url: APP_CONFIG.BASE_URL + 'events/calendars?event_ids='+ calendarIDs,
              
            }).then(function successCallback(response) {
                $log.debug("OK ICS");
                deferred.resolve({success: true, data: response.data});
            }, function errorCallback(response) {
                $log.debug("ERROR ICS download");
                $log.warn(response);
                deferred.resolve({success: false, message: 'Error downloading ICS - ' + response});
            });

            return deferred.promise;
        };

        service.redeemDeal = function (deal) {

            if (service.getDealHasBeenRedeemed(deal.id)) {
                var deferred = $q.defer();
                deferred.resolve({success: false, message: 'Deal already redeemed'});
                return deferred.promise;
            }

            //Mark as redeemed locally
            deal.redeemed = true;

            var method = 'POST';
            var dataObj = {
                deal_redemption: {
                    deal_id: deal.id
                }
            };

            return service.callAPI(dataObj, 'Redeem deal', method, '/deal_redemption');
        };

        service.updateDealsState = function () {
            var deals = BuildingService.selectedBuilding.deals;
            for (var i = 0; i < deals.length; i++) {
                var d = deals[i];
                var isRedeemed = service.getDealHasBeenRedeemed(d.id);
                d.redeemed = isRedeemed;
            }
        };

        service.getDealHasBeenRedeemed = function (dealId) {
            var deals = service.user.deal_redemptions;// returns array of vendor like objects [{vendor_id:1},{vendor_id:3}]
            for (var i = 0; i < deals.length; i++) {
                if (deals[i].deal_id == dealId) {
                    return true;
                }
            }
            return false;
        };
        service.updateProfile = function (regionID, countryID, userBuildingId, floorID, number, subscribe) {
            var deferred = $q.defer();
            var dataObj = {
                user: {
                    building_id: userBuildingId,
                    region_id: regionID,
                    country_id: countryID,
                    floor_id: floorID,
                    send_sms_announcements: subscribe,
                    phone: number
                }
            };
            //Persist on backend
            $http({
                method: 'PUT',
                url: APP_CONFIG.BASE_URL + 'users/' + SESSION.USER_ID,
                data: dataObj
            }).then(function successCallback(response) {

                $log.debug("update profile ", response);

                //Returns updated user object
                BuildingService.setSelectedBuildingById(response.data.user.building_id);

                deferred.resolve({success: true, data: response.data});
            }, function errorCallback(response) {
                $log.debug("ERROR persist update profile", response);
                //TODO: Fix up all resolves into rejects!!!!
                deferred.reject({success: false, data: service.selectedBuilding});
            });

            return deferred.promise;
        };
        service.callAPI = function (dataObj, updateType, method, path) {
            

            updateType = updateType || 'unknown';

            method = method || 'PUT';

            path = path || '';

            var deferred = $q.defer();
              
            $http({
                method: method,
                url: APP_CONFIG.BASE_URL + 'users/' + SESSION.USER_ID + path,
                data: dataObj
            }).then(function successCallback(response) {
                $log.debug("OK user.callAPI");
                $log.debug("callAPI :"+response);
                console.log(response);
                // //If it contains a user object then update now
                // $log.debug(response.data.user);
                // if (!angular.isUndefinedOrNull(response.data.user)) {

                //     // Copy in the new user model values
                //     angular.forEach(response.data.user, function (value, key) {
                //         if (angular.isDefined(service.user[key])) {
                //             service.user[key] = value;
                //         }
                //     });

                // } else {
                //     $log.debug("No user node for " + updateType);
                // }
                // service.user = response.data.user;

                var event_attendances_count = null;

                // Messy check to account for sub-property related to event attendance counts
                if (response.hasOwnProperty('data') &&
                    response.data.hasOwnProperty('event_attendance') &&
                    response.data.event_attendance.hasOwnProperty('event_attendances_count')) {
                    event_attendances_count = response.data.event_attendance.event_attendances_count;
                    //alert(event_attendances_count);
                    console.log(response.data);
                }

                deferred.resolve({
                    success: true,
                    message: 'User ' + updateType + ' updated OK',
                    likes: response.data.vendor_likes_count,
                    event_attendances_count: event_attendances_count

                });
            }, function errorCallback(response) {
                $log.debug("ERROR user.callAPI " + updateType);
                $log.warn(response);
                //TODO - refactor this to be a reject app-wide!

                // $log.debug('actualResponse', response);

                deferred.resolve({
                    success: false,
                    message: 'Error updating user - ' + updateType,
                    errors: response.data.errors
                });
            });

            return deferred.promise;
        };

        service.logOut = function () {

            //GET /shibboleth/Logout
            //Redirect to https://federation.ext.pg.com/responses/PGLoggedout.htm
            $http({
                method: 'GET',
                url: '/shibboleth/Logout'
            }).then(function successCallback(response) {
                $log.debug("Logged user out");
                $log.debug(response);
                $window.open('https://federation.ext.pg.com/responses/PGLoggedout.htm', '_self');

            }, function errorCallback(response) {
                $log.debug("Error logging user out");
                $log.debug(response);
            });

        };

        service.popup_mark_seen = function () {
            var deferred = $q.defer();
            var dataObj = {
                user: {
                    popup_seen : true
                }
            };
            //Persist on backend
            $http({
                method: 'PUT',
                url: APP_CONFIG.BASE_URL + 'users/' + SESSION.USER_ID,
                data: dataObj
            }).then(function successCallback(response) {

                $log.debug("update profile ", response);

                deferred.resolve({success: true, data: response.data.user.popup_seen});
            }, function errorCallback(response) {
                $log.debug("ERROR persist update profile", response);

            });

            return deferred.promise;
        }

        return service;

    }])

    .service('IonicUtilsService', ['$state', '$ionicPopup', '$window', '$log', '$ionicHistory', '$ionicLoading', 'UserService', 'Analytics', 'BuildingService', 'APP_CONFIG', function ($state, $ionicPopup, $window, $log, $ionicHistory, $ionicLoading, UserService, Analytics, BuildingService, APP_CONFIG) {

        var service = {};

        service.showExternalLinkPrompt = function (url, externalServiceName, target) {
            target = target || '_blank';

            var confirmPopup = $ionicPopup.confirm({
                title: 'Opening External Link',
                template: 'Thanks for using ' + APP_CONFIG.TITLE + '. You are about to leave this app and be sent to a third party external site ' + (externalServiceName ? 'for the ' + externalServiceName + ' service' : '') + '.'
            });

            confirmPopup.then(function (res) {
                if (res) {
                    Analytics.sendEvent('openExternalLink', url, BuildingService.selectedBuilding.name, BuildingService.selectedBuilding.id);
                    $window.open(url, target);
                } else {
                    confirmPopup.close();
                }
            });
        };

        service.showLogOutPrompt = function () {

            var confirmPopup = $ionicPopup.confirm({
                title: 'Log out?',
                template: 'Thanks for using ' + APP_CONFIG.TITLE + '. Are you sure you want to log out?'
            });

            confirmPopup.then(function (res) {
                if (res) {
                    Analytics.sendEvent('log-out-prompt', 'OK', BuildingService.selectedBuilding.name, BuildingService.selectedBuilding.id);
                    UserService.logOut();
                } else {
                    Analytics.sendEvent('log-out-prompt', 'Cancel', BuildingService.selectedBuilding.name, BuildingService.selectedBuilding.id);
                    confirmPopup.close();
                }
            });
        };

        service.showAlert = function (title, message) {

            var alertPopup = $ionicPopup.alert({
                title: title,
                template: message
            });

            alertPopup.then(function (result) {
                $log.debug('Alert was dismissed');
            });

        };

        service.gotoPage = function (stateName, params, disableBackbutton, clearHistory) {

            // workaround for undesirable behavior when Ionic is showing the back button when we don't want it to
            if (disableBackbutton) {
                $ionicHistory.nextViewOptions({
                    disableBack: true
                });
            }

            if (clearHistory) {
                $ionicHistory.clearHistory();
            }

            $state.go(stateName, params || {});
        };

        service.showLoadingWithTitle = function (title) {
            //returns a promise
            return $ionicLoading.show({
                template: '<p>' + title + '</p><ion-spinner icon="ios"></ion-spinner>',
                animation: 'fade-in',
                showBackdrop: true
            });
        };

        service.hideLoading = function () {
            return $ionicLoading.hide();//returns a promise
        };

        /**
         * Work out optimum image to pull in based on devicePixelRatio
         * Should return 1, 2, or 3 ONLY
         * building.hero_image_x{{dpr}}
         * On desktop default to 2
         */
        service.getDevicePixelResolution = function () {
            if (ionic.Platform.isBrowser()) {
                return 2;
            }
            return Math.clamp(Math.floor(window.devicePixelRatio), 1, 3);
        };


        return service;
    }])

    /**
     * Service to store state for menu buttons on home screen
     * Each
     */
    .service('MenuButtonService', ['$log', '$state', '$filter', '$q', 'BuildingService', 'UserService', 'APP_CONFIG', function ($log, $state, $filter, $q, BuildingService, UserService, APP_CONFIG) {

        var service = {};

        service.availableButtons = []; //all default buttons excluding ones that aren't available in this building in the default order
        service.buttons = [];//What is actually displayed - the JSON array of only menu buttons that are available and visible in the order defined by user or defaults

        /**
         * Get available buttons and use user prefs if they exist
         */
        service.init = function () {
            service.setAvailableButtons();
            service.getUserButtonPrefs();
            service.hackVibrantLiving();
            return service.getVisibleButtons();
        };

        service.errorCheck = function (methodName) {
            if (service.buttons.length == 0) {
                $log.error("MenuButtonService init method has not been called! [" + methodName + "]");
            }
        };

        /**
         * From defaults and selected building get the set of default menu buttons in order
         */
        service.setAvailableButtons = function () {

            //Get a copy of the default buttons
            var defaultButtons = angular.copy(APP_CONFIG.MENU_BUTTON_DEFAULTS);

            //Remove any that aren't in the selected building - these are marked in routes with api_node - service_requests_url room_finder_url
            var availableButtons = [];
            var features = BuildingService.selectedBuilding.features;
            for (var i = 0; i < defaultButtons.length; i++) {
                var button = defaultButtons[i];
                var isHidden = true;
                //Check if state name is external and use api_node to check value
                features.forEach(function (feature) {
                    if (button.title === feature.name)
                        isHidden = false;
                });
                if (!isHidden && $state.get(button.state).external) {
                    //Check a value exists?
                    var apiNode = $state.get(button.state).api_node;
                    isHidden = angular.isUndefinedOrNull(BuildingService.selectedBuilding[apiNode]);
                }
                if (!isHidden) {
                    availableButtons.push(button);
                }
            }

            //Save all available buttons in default order and all visible
            service.availableButtons = angular.copy(availableButtons);
            service.resetDefaultButtons();

            //Use default available buttons in default order
            service.buttons = angular.copy(service.availableButtons);
        };

        /**
         * I truly hate myself for this, but I don't see what choice I have.
         * @author Afraid To Say. Probably James Anslow.
         *
         */
        service.hackVibrantLiving = function () {
            var buildingId = BuildingService.selectedBuilding.id;
            var campaign_name = BuildingService.selectedBuilding.campaign_name;
            for (var i = 0; i < service.buttons.length; i++) {
                var button = service.buttons[i];

                if (button.state == 'vibrantLiving') {
                    button.title = campaign_name;
                }
            }
        };

        /**
         * Check if the user has a preference set and use that to display order and visibility
         */
        service.getUserButtonPrefs = function () {

            if (angular.checkNestedValueExists(UserService.user, 'preferences', 'homeButtons')) {
                //service.setVisibleAndSortByUser(UserService.user.preferences.homeButtons);

                //Compare user list with the default buttons
                var userButtons = UserService.user.preferences.homeButtons;
                var defaultButtons = angular.copy(service.availableButtons);

                //1. Set visible as per user
                for (var i = 0; i < defaultButtons.length; i++) {
                    var db = defaultButtons[i];
                    for (var n = 0; n < userButtons.length; n++) {
                        var ub = userButtons[n];
                        //Check if it exists
                        if (ub.id == db.id) {
                            //Set visible flag
                            db.visible = ub.visible;
                        }
                    }
                }

                //2. Set order
                //Get out array of homeButtons that are visible and an array of order
                var userOrder = [];
                for (var i = 0; i < userButtons.length; i++) {
                    userOrder.push(userButtons[i].id);
                }

                defaultButtons.sort(function (a, b) {
                    return userOrder.indexOf(a.id) - userOrder.indexOf(b.id);
                });

                //3. Use as order and visible
                service.buttons = angular.copy(defaultButtons);
            }
        };

        /**
         * Return just visible buttons
         * @returns {Array.<T>}
         */
        service.getVisibleButtons = function () {
            service.errorCheck('getVisibleButtons');
            return service.buttons.filter(function (button) {
                return (button.visible == true);
            });
        };


        /**
         * Return all default buttons in default order
         * @returns {*}
         */
        service.getDefaultButtons = function () {
            service.errorCheck('getDefaultButtons');
            var temp = angular.copy(service.availableButtons);
            //Reset default buttons
            temp.sort(function (a, b) {
                return APP_CONFIG.MENU_BUTTON_DEFAULT_ORDER.indexOf(a.id) - APP_CONFIG.MENU_BUTTON_DEFAULT_ORDER.indexOf(b.id)
            });
            temp.forEach(function (b) {
                b.visible = true;
            });
            return temp;
        };

        /**
         * Reset available buttons to default order and all visible
         * @returns {Array|*|visibleButtons}
         */
        service.resetDefaultButtons = function () {
            //Reset default buttons in default order and all visible
            service.availableButtons.sort(function (a, b) {
                return APP_CONFIG.MENU_BUTTON_DEFAULT_ORDER.indexOf(a.id) - APP_CONFIG.MENU_BUTTON_DEFAULT_ORDER.indexOf(b.id)
            });
            service.availableButtons.forEach(function (b) {
                b.visible = true;
            });
            service.buttons = angular.copy(service.availableButtons);
            return service.buttons;
        };

        /**
         * Create a stripped back server friendly version of buttons object to persist
         * @param buttonsArr
         * @returns {Array}
         */
        service.saveButtonOrderArray = function (buttonsArr) {
            //Loop through and just persist id and visibility (& title for sanity)
            var temp = [];
            for (var i = 0; i < buttonsArr.length; i++) {
                var b = buttonsArr[i];
                var button = {id: b.id, visible: b.visible, title: b.title};
                temp.push(button);
            }
            ;
            return temp;
        };

        return service;
    }])

    /**
     * WeatherIconService
     * Returns a class name (or charcode) for each weather condition at http://openweathermap.org/weather-conditions
     * Use to map to another weather icon font or class name i.e. https://erikflowers.github.io/weather-icons/
     * Usage:
     * <i class="wi wi-night-sleet"></i>
     */
    .service('WeatherIconService', [function () {
        var service = {};

        //Enum in JS!
        var iconStyles = {};
        iconStyles['01d'] = 'wi-day-sunny';//clear sky day
        iconStyles['01n'] = 'wi-night-clear';//clear sky night
        iconStyles['02d'] = 'wi-day-cloudy';//few clouds day
        iconStyles['02n'] = 'wi-night-alt-cloudy';//few clouds night
        iconStyles['03d'] = 'wi-cloud';//scattered clouds day
        iconStyles['03n'] = 'wi-cloud';//scattered clouds night
        iconStyles['04d'] = 'wi-cloudy';//broken clouds day
        iconStyles['04n'] = 'wi-cloudy';//broken clouds night
        iconStyles['09d'] = 'wi-day-showers';//shower rain day
        iconStyles['09n'] = 'wi-night-showers';//shower rain night
        iconStyles['10d'] = 'wi-day-rain';//rain day
        iconStyles['10n'] = 'wi-night-alt-rain-wind';//rain night
        iconStyles['11d'] = 'wi-day-thunderstorm';//thunderstorm day
        iconStyles['11n'] = 'wi-night-thunderstorm';//thunderstorm night
        iconStyles['13d'] = 'wi-snow';//snow
        iconStyles['50d'] = 'wi-fog';//mist

        service.getIconClassNameByWeatherCode = function (code) {
            return iconStyles[code];
        };

        return service;
    }])

    .service('AnnouncementsService', ['$q', '$log', '$http', 'BuildingService', 'UserService', 'APP_CONFIG', 'SESSION', function ($q, $log, $http, BuildingService, UserService, APP_CONFIG, SESSION) {

        var service = {};

        //When we set notifications compare with Users list (announcement_view) and mark as read internally
        service.markAnnouncementAsRead = function (notification) {

            var deferred = $q.defer();

            //Persist to server (if not already)
            if (!service.checkIfAnnouncementRead(notification.id) && notification.read != true) {

                $http.post(
                    APP_CONFIG.BASE_URL + 'users/' + SESSION.USER_ID + '/announcement_view',
                    {announcement_view: {announcement_id: notification.id}}
                ).then(function successCallback(response) {
                    $log.debug("announcement_view persisted OK");
                    $log.debug(response);

                    // Update the notification and user object
                    notification.read = true;
                    UserService.user.announcement_views.push(notification.id);

                    //Update read count
                    service.getUnReadCount();

                    deferred.resolve({success: true});

                }, function errorCallback(response) {
                    // TODO: Account for the announcement already being marked as read
                    $log.debug("ERROR announcement_view persist");
                    $log.debug(response);
                    deferred.reject({success: false});
                });

            } else {
                deferred.resolve({success: true});
            }

            return deferred.promise;

        };

        service.checkIfAnnouncementRead = function (announcement_id) {
            var announcement_views = UserService.user.announcement_views;// returns array of vendor like objects [{announcement_id:1},{announcement_id:3}]
            for (var i = 0; i < announcement_views.length; i++) {
                if (announcement_views[i].announcement_id == announcement_id) {
                    return true;
                }
            }
            return false;
        };

        service.getUnReadCount = function () {

            var announcements = BuildingService.selectedBuilding.announcements;

            var unreadCount = 0;
            angular.forEach(announcements, function (announcement) {

                if (service.checkIfAnnouncementRead(announcement.id)) {
                    announcement.read = true;
                    //If we manually marked it as read then leave it else check it
                } else if (announcement.read !== true) {
                    announcement.read = false;
                    unreadCount++;
                }
            });

            return unreadCount;
        };


        return service;

    }])

    .service('BuildingService', ['$q', '$log', '$http', '$filter', '$window', 'APP_CONFIG', 'SESSION', function ($q, $log, $http, $filter, $window, APP_CONFIG, SESSION) {

        var service = {};

        service.selectedBuilding;
        service.buildings = [];

        service.hasSelectedBuilding = function () {
            return angular.isDefined(service.selectedBuilding);
        };

        service.setSelectedBuildingById = function (userBuildingId) {
            angular.forEach(service.buildings, function (building) {
                if (building.id == userBuildingId) {
                    service.selectedBuilding = building;
                }
            });
            $log.debug('Selected building', service.selectedBuilding);
            //$log.debug(angular.toJson(service.selectedBuilding, true));
        };

        service.getBuildingByIdFromRemote = function (buildingId) {

            var deferred = $q.defer();

            $http({
                method: 'GET',
                url: APP_CONFIG.BASE_URL + 'buildings/' + buildingId,
            }).then(function successCallback(response) {
                $log.debug("getBuildingByIdFromRemote: ", response);
                //FIXME: Add a check for null and  redirect to login
                var selectedBuilding = response.data.building;
                service.selectedBuilding = selectedBuilding;
                deferred.resolve(selectedBuilding);

            }, function errorCallback(response) {
                $log.debug("Error: getBuildingByIdFromRemote API");
                $log.debug(response);
                deferred.reject({
                    success: false,
                    message: "An error occurred accessing the API. Status: " + response.status + " " + response.statusText,
                    data: response.data
                });
            });

            return deferred.promise;
        };

        service.getBuildings = function () {

            var deferred = $q.defer();

            $http({
                method: 'GET',
                url: APP_CONFIG.BASE_URL + 'buildings',
                //headers: {
                //  'Authorization': 'Token token=' + APP_CONFIG.SUPERTOKEN,
                //  'Content-Type': 'application/x-www-form-urlencoded'
                //}
            }).then(function successCallback(response) {
                // this callback will be called asynchronously
                // when the response is available
                $log.debug("Return from buildings API");

                var buildings = response.data.buildings;
                service.buildings = buildings;
                //service.selectedBuilding = buildings[0];//set default
                //$log.debug("Selected Building");
                //$log.debug(service.selectedBuilding);
                deferred.resolve({success: true, data: buildings});

            }, function errorCallback(response) {
                // called asynchronously if an error occurs
                // or server returns response with an error status.
                $log.debug("Error: Buildings API");
                $log.debug(response);
                deferred.resolve({
                    success: false,
                    message: "An error occurred accessing the API. " + response.data + " Status: " + response.status + " " + response.statusText
                });
            });

            return deferred.promise;
        };

        service.getSelectedBuilding = function () {
            var deferred = $q.defer();
            //If no building call service
            if (angular.isUndefined(service.selectedBuilding)) {
                service.getBuildings().then(function () {
                    deferred.resolve(service.selectedBuilding);
                });
            } else {
                deferred.resolve(service.selectedBuilding);
            }
            return deferred.promise;
        };

        service.getBuildingAddressForGMapsAPI = function (escaped) {
            escaped = escaped || false;
            var b = service.selectedBuilding;
            //Leave out any blank fields so we don't get 11 North Buona Vista Drive #21-07 The Metropolis Tower 2,,Singapore,138589,
            var fields = [b.address, b.street, b.state, b.city, b.zip, b.country];
            var addressArr = [];
            for (var i = 0; i < fields.length; i++) {
                if (!angular.isUndefinedOrNull(fields[i])) {
                    addressArr.push(fields[i]);
                }
            }
            var address = addressArr.join(',');
            var requestURL = "https://maps.google.com/maps?daddr=" + (escaped ? window.encodeURIComponent(address) : address);
            return requestURL;
        };

        service.getGoogleStaticMapURI = function () {
            var API_KEY = 'AIzaSyDtW63sKEMAq0XXjvRTuQiZxByNP8yO_gA';
            var longlat = service.selectedBuilding.latitude + ',' + service.selectedBuilding.longitude;
            //Request correct image
            var w = $window.innerWidth || 320;
            var h = $window.innerHeight || 568;
            var size = w + "x" + h;
            return "https://maps.googleapis.com/maps/api/staticmap?center=" + longlat + "&markers=color:red|" + longlat + "&zoom=16&scale=2&size=" + size + "&maptype=roadmap&key=" + API_KEY;
        };

        service.getUnreadNotificationCount = function () {
            var count = 0;
            angular.forEach(service.selectedBuilding.announcements, function (notification) {
                //if(notification.read){
                count++;
                // }
            });
            return count;
        };

        service.getAvailableBuildingInfoTypes = function () {

            //Only return amenity types or contact types which are in the current building
            function makeUpAvailable(type) {
                var availableTypes = [];
                var ids = [];
                var allTypes = type == 'amenities' ? APP_CONFIG.AMENITY_TYPES : APP_CONFIG.CONTACT_TYPES;
                angular.forEach(service.selectedBuilding[type], function (record) {
                    //Loop through all contact types and create array of amenity types which exist
                    for (var i = 0; i < allTypes.length; i++) {
                        var currentType = allTypes[i];
                        if (ids.indexOf(currentType.id) == -1 && record.type == currentType.type) {
                            ids.push(currentType.id);
                            availableTypes.push(angular.copy(currentType));
                            break;
                        }
                    }
                });
                return availableTypes;
            }

            var amenityTypes = makeUpAvailable('amenities');
            var contactTypes = makeUpAvailable('contacts');
            var returnObj = {amenityTypes: amenityTypes, contactTypes: contactTypes};

            return returnObj;

        };

        service.getAnnouncementByID = function (id) {
            return service.getItemByIdAndFieldName(id, 'announcements');
        };

        service.getVendorById = function (id) {
            return service.getItemByIdAndFieldName(id, 'vendors');
        };

        service.getContactById = function (id) {
            return service.getItemByIdAndFieldName(id, 'contacts');
        };

        service.getAmenityById = function (id) {
            return service.getItemByIdAndFieldName(id, 'amenities');
        };

        service.getDealById = function (id) {
            return service.getItemByIdAndFieldName(id, 'deals');
        };

        service.getEventById = function (id) {
            return service.getItemByIdAndFieldName(id, 'events');
        };

        service.getBuildingById = function (id) {
            $log.warn("getBuildingById: " + id);
            angular.forEach(service.buildings, function (building) {
                if (building.id == id) {
                    return building;
                }
            });
        };

        // Refactor above functions to look up by this instead
        service.getItemByIdAndFieldName = function (id, fieldName) {
            var deferred = $q.defer();
            //$log.debug("getItemByIdAndFieldName " + id + " " + fieldName);
            angular.forEach(service.selectedBuilding[fieldName], function (item) {
             
                if (item.id == id) {
                    deferred.resolve(item);
                }
            });
            return deferred.promise;
        };

        service.getInternalVendors = function () {

            var iv = service.selectedBuilding.vendors.filter(function (vendor) {
                return (vendor.in_house == true && vendor.type == 'dining');
            });

            return iv;
        };

        return service;

    }])

    .service('VendorSortFilterService', ['$log', function ($log) {
        /*
         Maintains state of filters and sort in Vendors list
         */
        var service = {};
        service.orderByValue;
        service.filterOn;
        service.setOrderByValue = function (val) {
            service.orderByValue = val;
        };
        service.getOrderByValue = function () {
            return service.orderByValue;
        };
        service.setFilterOnValue = function (val) {
            service.filterOn = val;
        };
        service.getFilterOnValue = function () {
            return service.filterOn;
        };
        return service;
    }])

    .service('Analytics', ['$log', '$window', 'SESSION', function ($log, $window, SESSION) {
        var service = {};

        //https://developers.google.com/analytics/devguides/collection/analyticsjs/pages
        service.sendPageView = function (url, name) {
            if ($window.ga) {
                ga('set', {
                    page: url,
                    title: name
                });

                ga('send', 'pageview');
            }

            if (SESSION.ENVIRONMENT != "production")
                $log.debug('Send pageview: ' + url + ' ' + name);
        };

        //https://developers.google.com/analytics/devguides/collection/analyticsjs/events
        /*
         eventCategory	text	yes	Typically the object that was interacted with (e.g. 'Video')
         eventAction	text	yes	The type of interaction (e.g. 'play')
         eventLabel	text	no	Useful for categorizing events (e.g. 'Fall Campaign')
         eventValue	integer	no	A numeric value associated with the event (e.g. 42)
         */
        service.sendEvent = function (category, action, label, value) {
            if ($window.ga) {
                ga('send', {
                    hitType: 'event',
                    eventCategory: category,//Typically the object that was interacted with
                    eventAction: action,//The type of interaction (e.g. 'play')
                    eventLabel: label,//Useful for categorizing events (e.g. 'Fall Campaign')
                    eventValue: value//A numeric value associated with the event (e.g. 42)
                });
            }

            if (SESSION.ENVIRONMENT != "production")
                $log.debug('Analytics.sendEvent ' + category, action, label, value);
        };

        return service;
    }])

    /**
     * Service to store selected Tab data for Deals & Events
     */
    .service('DealsAndEventsTabService', ['$log', function ($log) {
        var service = {};
        service.defaultTab = "deals";
        service.selectedTab = service.defaultTab;
        service.resetDefaultTab = function () {
            service.selectedTab = service.defaultTab;
        };
        service.setTab = function (tabName) {
            service.selectedTab = tabName;
        };
        service.getTab = function () {
            return service.selectedTab;
        };

        return service;
    }])

    /**
     * Unused Services
     **/

    .service('WelcomeMessageService', [function () {
        var service = {};
        service.getMessage = function () {

            var h = new Date().getHours(); // Date.prototype.getHours() Returns the hour (0-23) in the specified date according to local time.

            if (h >= 0 && h < 12) {
                return "Good Morning";
            }

            if (h >= 12 && h <= 18) {
                return "Good Afternoon";
            }

            if (h > 18) {
                return "Good Evening";
            }

            return "No message returned";
        };

        return service;
    }]);
