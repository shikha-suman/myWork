(function() {
    var $;

    $ = jQuery;
    $(document).on("click", "#list input.toggle", function() {
        return $("#list [name='bulk_ids[]']").prop("checked", $(this).is(":checked"));
    });

    $(document).on('click', '.pjax', function(event) {
        if (event.which > 1 || event.metaKey || event.ctrlKey) {

        } else if ($.support.pjax) {
            event.preventDefault();
            return $.pjax({
                container: $(this).data('pjax-container') || '[data-pjax-container]',
                url: $(this).data('href') || $(this).attr('href'),
                timeout: 2000
            });
        } else if ($(this).data('href')) {
            return window.location = $(this).data('href');
        }
    });

    $(document).on('submit', '.pjax-form', function(event) {
        if ($.support.pjax) {
            event.preventDefault();
            return $.pjax({
                container: $(this).data('pjax-container') || '[data-pjax-container]',
                url: this.action + (this.action.indexOf('?') !== -1 ? '&' : '?') + $(this).serialize(),
                timeout: 2000
            });
        }
    });

    $(document).on('pjax:start', function() {
        return $('#loading').show();
    }).on('pjax:end', function() {
        return $('#loading').hide();
    });

    $(document).on('click', '[data-target]', function() {
        if (!$(this).hasClass('disabled')) {
            if ($(this).has('i.icon-chevron-down').length) {
                $(this).removeClass('active').children('i').toggleClass('icon-chevron-down icon-chevron-right');
                return $($(this).data('target')).select(':visible').hide('slow');
            } else {
                if ($(this).has('i.icon-chevron-right').length) {
                    $(this).addClass('active').children('i').toggleClass('icon-chevron-down icon-chevron-right');
                    return $($(this).data('target')).select(':hidden').show('slow');
                }
            }
        }
    });

    $(document).on('click', '.form-horizontal legend', function() {
        if ($(this).has('i.icon-chevron-down').length) {
            $(this).siblings('.control-group:visible').hide('slow');
            return $(this).children('i').toggleClass('icon-chevron-down icon-chevron-right');
        } else {
            if ($(this).has('i.icon-chevron-right').length) {
                $(this).siblings('.control-group:hidden').show('slow');
                return $(this).children('i').toggleClass('icon-chevron-down icon-chevron-right');
            }
        }
    });

    $(document).on('click', 'form .tab-content .tab-pane a.remove_nested_one_fields', function() {
        return $(this).children('input[type="hidden"]').val($(this).hasClass('active')).siblings('i').toggleClass('icon-check icon-trash');
    });

    $(document).ready(function() {
        return $(document).trigger('rails_admin.dom_ready');
    });

    $(document).on('pjax:end', function() {
        return $(document).trigger('rails_admin.dom_ready');
    });

    $(document).on('rails_admin.dom_ready', function() {

        /* Disable animation of progress bars */
        $('.animate-width-to').each(function() {
            var length, width;
            length = $(this).data("animate-length");
            width = $(this).data("animate-width-to");
            return $(this).animate({
                width: width
            }, 0);
        });
        $('.form-horizontal legend').has('i.icon-chevron-right').each(function() {
            return $(this).siblings('.control-group').hide();
        });
        $(".table").tooltip({
            selector: "th[rel=tooltip]"
        });
        return $('[formnovalidate]').on('click', function() {
            return $(this).closest('form').attr('novalidate', true);
        });
    });

    $(document).on('click', '#fields_to_export label input#check_all', function() {
        var elems;
        elems = $('#fields_to_export label input');
        if ($('#fields_to_export label input#check_all').is(':checked')) {
            return $(elems).prop('checked', true);
        } else {
            return $(elems).prop('checked', false);
        }
    });

    $(document).on('pjax:popstate', function() {
        $(document).one('pjax:end', function(event) {
            $(event.target).find('script').each(function() {
                $.globalEval(this.text || this.textContent || this.innerHTML || '');
            });
        });
    });

    $(document).on('click', "#remove_filter", function(event) {
        event.preventDefault();
        $("#filters_box").html("");
        $("hr.filters_box").hide();
        $(this).parent().siblings("input[type='search']").val("");
        return $(this).parents("form").submit();
    });

    $(document).on('click', 'button[type=submit]', function(event) {
        $('form').find('select').each(function(i, e) {
            $(e).removeAttr('required');
        });
    });


    $(document).ready(function() {
        if(window.location.pathname.slice(-12)==="building/new"){
            $('#building_feature_ids_field a.ra-multiselect-item-add-all').click()
        }
        if($('#event_is_recurring:checked').length == 0 ) {
            $('#event_recurring_id_field').hide();
            hideWeek();
            hideDays();
        }
        else {
            $('#event_recurring_id_field').show();
            if($('#event_recurring_id :selected').text() == "Monthly"){
                showWeek();
                showDays();
            }
            else if($('#event_recurring_id :selected').text() == "Weekly"){
                hideWeek();
                showDays();
            }
            else {
                hideDays();
                hideWeek();
            }
        }

    });

    $(document).on('change', '#event_is_recurring_field', function() {
        if($('#event_is_recurring:checked').length == 0 ) {
            $('#event_recurring_id_field').hide();
            hideDays();
            hideWeek();
        }
        else {
            $('#event_recurring_id_field').show();
            check_Recurring();
        }
    });

    function check_Recurring() {
        if($('#event_is_recurring:checked').length > 0 && $('#event_recurring_id :selected').text() == "Monthly"){
            showWeek();
            showDays();
        }
        else if($('#event_is_recurring:checked').length > 0 && $('#event_recurring_id :selected').text() == "Weekly"){
            hideWeek();
            showDays();
        }
        else {
            hideWeek();
            hideDays();
        }
    }
    $(document).on('change', '#event_recurring_id', function() {
        check_Recurring();
    });

    function showDays(){
        $('#event_monday_field').show();
        $('#event_tuesday_field').show();
        $('#event_wednesday_field').show();
        $('#event_thursday_field').show();
        $('#event_friday_field').show();
        $('#event_saturday_field').show();
        $('#event_sunday_field').show();
    }

    function hideDays(){
        $('#event_monday_field').hide();
        $('#event_tuesday_field').hide();
        $('#event_wednesday_field').hide();
        $('#event_thursday_field').hide();
        $('#event_friday_field').hide();
        $('#event_saturday_field').hide();
        $('#event_sunday_field').hide();
    }

    function showWeek() {
        $('#event_first_field').show();
        $('#event_second_field').show();
        $('#event_third_field').show();
        $('#event_fourth_field').show();
        $('#event_last_field').show();
    }

    function hideWeek() {
        $('#event_first_field').hide();
        $('#event_second_field').hide();
        $('#event_third_field').hide();
        $('#event_fourth_field').hide();
        $('#event_last_field').hide();
    }

$(document).ready(function () {
//image rotate for service request
// $('.sr-hero').parent().next('dd').append('<button id="buttonAdminRotate">rotate</button>');
    // $("#buttonAdminRotate").on('click', function () {
    //       var img = $('.well img');
    //     if (img.hasClass('img-thumbnail')) {
    //         img.attr('class', 'west');
    //     } else if (img.hasClass('west')) {
    //         img.attr('class', 'south');
    //     } else if (img.hasClass('south')) {
    //         img.attr('class', 'east');
    //     } else if (img.hasClass('east')) {
    //         img.attr('class', 'eastt');
    //     }
    //     else if (img.hasClass('eastt')) {
    //         img.attr('class', 'west');
    //     }
    // });
//             if (!String.prototype.startsWith) {
//     String.prototype.startsWith = function(searchString, position){
//       return this.substr(position || 0, searchString.length) === searchString;
//   };
// }

String.prototype.myStartsWith = function(str){
 if(this.indexOf(str)===0){
  return true;
 }else{
   return  false;
 }
};
 $("#survey_feedback_question_field").hide();
if($("#survey_question_survey_question_type_id option:selected").text().myStartsWith("MCQ"))
    {

   showOptions();
        }
        else {
            hideOptions();
        }


       
        // if($("#survey_question_survey_question_type_id option:selected").text().startsWith("MCQ")) {
        //     showOptions();
        // }
        // else {
        //     hideOptions();
        // }
    });

    $(document).on('pjax:end', function() {
        url = window.location.href;
        if( url.indexOf("/survey_question") !== -1 && (url.indexOf("/new") !== -1 || url.indexOf("/edit") !== -1)){
            checkOptions();
        }
    });

    $(document).on('blur', '#challenge_short_description_field', function(event) {
        url = window.location.href;
        if( url.indexOf("/challenge") !== -1 && (url.indexOf("/new") !== -1 || url.indexOf("/edit") !== -1)){
            console.log($("#challenge_short_description").val());
            if($("#challenge_short_description").val().length > 100) {
                $("#100_char_check").remove();
                $("#challenge_short_description_field").append("<label id='100_char_check' style='color:red; padding-left:18%'> Cannot be greater than 100 Characters </label>");
            }
            else {
                $("#100_char_check").remove();
            }
        }
    });

    $(document).ready(function() {
        checkOptions();
    });
    var count = 0;

    $(document).on('shown.bs.modal', '#modal', function(event) {
        // console.log("??????????????????");
        // console.log($.browser);

        url = window.location.href;
        if( url.indexOf("/survey") !== -1 && (url.indexOf("/new") !== -1 || url.indexOf("/edit") !== -1)){
            // console.log("!!!!!!!!!!!!!!!!!!!!!!!");
            $(".modal-body").bind("DOMNodeInserted", function(){
                console.log(count);
                count += 1;
                // if($("#survey_question_survey_question_type_id  option:selected").text().startsWith("MCQ")) {
                //     count = 0;
                // }
                if(count == 4) {
                    if(navigator.userAgent.search("Chrome") > 0 ) {
                        // console.log("<<<<<<<<<<<<");
                        // count = 0;
                        $("#survey_question_survey_id_field").hide();
                        if($("#survey_question_survey_question_type_id  option:selected").text().myStartsWith("MCQ")) {
                            showOptions();
                        }
                        else {
                            hideOptions();
                        }
                    }
                }

                if(count == 82 || count >= 65) {
                    // console.log(">>>>>>>>>>>>>");
                    // count = 0;
                    $("#survey_question_survey_id_field").hide();
                    if($("#survey_question_survey_question_type_id  option:selected").text().myStartsWith("MCQ")) {
                        showOptions();
                    }
                    else {
                        hideOptions();
                    }
                }
            });
        }
    });

    $(document).on('shown.bs.modal', '#modal', function(event) {
        if( url.indexOf("/survey") !== -1 && (url.indexOf("/new") !== -1 || url.indexOf("/edit") !== -1)){
            count = 0;
        }
    });

    $(document).on('change', '#survey_question_survey_question_type_id', function(event) {

        if($("#survey_question_survey_question_type_id  option:selected").text().myStartsWith("MCQ")) {
            showOptions();
        }
        else {
            hideOptions();
        }
    });

    $(document).on('change', '#survey_is_feedback_required', function(event) {
        if($('#survey_is_feedback_required:checked').length > 0) {
            $("#survey_feedback_question_field").show();
        }
        else {
            $("#survey_feedback_question_field").hide();
        }
    });



    function checkOptions(){

        if($('#survey_is_feedback_required:checked').length > 0) {
            $("#survey_feedback_question_field").show();
        }
        else {
            $("#survey_feedback_question_field").hide();
        }

        if($("#survey_question_survey_question_type_id option:selected").text().myStartsWith("MCQ")) {
            showOptions();
        }
        else {
            hideOptions();
        }
    }

    function showOptions() {
        $("#survey_question_choice_1_field").show();
        $("#survey_question_choice_2_field").show();
        $("#survey_question_choice_3_field").show();
        $("#survey_question_choice_4_field").show();
        $("#survey_question_choice_5_field").show();
    }

    function hideOptions() {
        $("#survey_question_choice_1_field").hide();
        $("#survey_question_choice_2_field").hide();
        $("#survey_question_choice_3_field").hide();
        $("#survey_question_choice_4_field").hide();
        $("#survey_question_choice_5_field").hide();
    }
//rotate button service request admin and challenges admin
 $(document).on("click","#buttonAdminRotate",function(){
          var img = $('.well img');
        if (img.hasClass('img-thumbnail')) {
            img.attr('class', 'west');
        } else if (img.hasClass('west')) {
            img.attr('class', 'south');
        } else if (img.hasClass('south')) {
            img.attr('class', 'east');
        } else if (img.hasClass('east')) {
            img.attr('class', 'eastt');
        }
        else if (img.hasClass('eastt')) {
            img.attr('class', 'west');
        }
    })
}).call(this);