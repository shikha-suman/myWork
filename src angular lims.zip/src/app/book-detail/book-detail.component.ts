import {Http} from '@angular/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-detail',
  templateUrl: './book-detail.component.html',
  styleUrls: ['./book-detail.component.css']
})
export class BookDetailComponent implements OnInit {
datas;
  constructor(private http:Http) { 
    this.http.get('assets/data/data.json')
                .subscribe(res => this.datas = res.json());
  }

  ngOnInit() {
    
  }

}
