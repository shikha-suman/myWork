import {Http} from '@angular/http';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
datas;
  constructor(private http:Http) { 
     this.http.get('assets/data/data.json')
                .subscribe(res => this.datas = res.json());
  }

  ngOnInit() {
  }

}
