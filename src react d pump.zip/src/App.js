// landing page
import React, { Component } from 'react';
import './App.css';

import { connect } from 'react-redux';
import { fetchData, fetchMap } from './actions';
import { BrowserRouter, Route, Redirect, Switch } from 'react-router-dom';

// import geoJSON from './assets/topojson-world.json';
import BasicMap from './components/basicmap.js';
import Toolbar from './components/toolbar.js';
import ImgSlider from './components/image-slider.js';
import SidePanel from './components/side-panel.js';
import LandingPage from './components/landing-page.js';

var brand = 'ariel';
var changedBrand = "";
var data = 'all';
var dataSrc = "";

class App extends Component {
  constructor(props) {
    super(props);

    this.triggerBrandChange = this.triggerBrandChange.bind(this);
    this.changeSourceData = this.changeSourceData.bind(this);
  }

  componentDidMount() {
    console.log(data);
    this.props.fetchData(data, brand);
    this.props.fetchMap(data, brand);
  }

  changeSourceData(data, brand) {
    // console.log(data);
    dataSrc = data;
    this.props.fetchData(data, changedBrand);
    this.props.fetchMap(data, changedBrand);
  }

  triggerBrandChange(data, brand) {
    changedBrand = brand;
    dataSrc = "all";
    // console.log(brand);
    this.props.fetchData(data, brand);
    this.props.fetchMap(data, brand);
  }

  render() {
    if (this.props.brand.length !== 0) {
      // console.log(this.props);
    }

    return (
      <div>
        <Toolbar />
        <ImgSlider defaultBrand={brand} activeBrand={changedBrand} updateBrand={this.triggerBrandChange} />
        <SidePanel data={dataSrc} brand={brand} updateBrand={this.changeSourceData} />
        <BrowserRouter>
          <div>
            <Switch>
              <Route exact path="/" render={(props) => <LandingPage {...props} weekWise={this.props.brand.weekWiseData} brandIndex={this.props.brand.finalBrandIndex} productAttribute={this.props.brand.finalProductAttrIndex} pqi={this.props.brand.finalPQI} priceIndex={this.props.brand.finalPriceIndex} qualityIndex={this.props.brand.finalQualityIndex} brandName={changedBrand} src={dataSrc} />} />
              <Route path="/analytics" render={(props) => <BasicMap {...props} mapData={this.props.mapData} brandName={changedBrand} dataSrc={dataSrc} />} />
              <Redirect from="**" to="/" />
            </Switch>
          </div>
        </BrowserRouter>
      </div>
    );
  }
}


// mapping the state changes in redux side as props in component
function mapStateToProps(state) {
  return {
    brand: state.brand,
    mapData: state.mapData
  }
}

export default connect(mapStateToProps, { fetchData, fetchMap  })(App);
