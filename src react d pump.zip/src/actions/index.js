// twitter data
import DownyTwitData from '../assets/sources/twitter/output-downy.json';
import ArielTwitData from '../assets/sources/twitter/output-ariel.json';
import FebrezeTwitData from '../assets/sources/twitter/output-febreze.json';
import JoyTwitData from '../assets/sources/twitter/output-joy.json';

// p and g data
import DownyPGData from '../assets/sources/png/output-downy-png.json';
import ArielPGData from '../assets/sources/png/output-ariel-png.json';
import FebrezePGData from '../assets/sources/png/output-febreze-png.json';
import JoyPGData from '../assets/sources/png/output-joy-png.json';

// newspaper data
import ArielNewsData from '../assets/sources/newspaper/output-ariel-newspaper.json';
import DownyNewsData from '../assets/sources/newspaper/output-downy-newspaper.json';
import FebrezeNewsData from '../assets/sources/newspaper/output-febreze-newspaper.json';

export const FETCH_DATA = 'fetch_data';
export const FETCH_MAP = 'fetch_map';
//export const FETCH_PANEL = 'fetch_panel';

// function to fetch the data from downy json
export function fetchData(data, brand) {
    let state = [];
    // mainData = brand;
    // console.log(data, brand);
    if (brand === 'downy' && data === 'all') {
        state[0] = DownyTwitData;
        state[1] = DownyPGData;
        state[2] = DownyNewsData;
    } else if (brand === 'downy' && data === 'twitter') {
        state[0] = DownyTwitData;
    } else if (brand === 'downy' && data === 'png') {
        state[1] = DownyPGData;
    } else if (brand === 'downy' && data === 'newspaper') {
        state[2] = DownyNewsData;
    } else if (brand === 'ariel' && data === 'all') {
        state[0] = ArielTwitData;
        state[1] = ArielPGData;
        state[2] = ArielNewsData;
    } else if (brand === 'ariel' && data === 'twitter') {
        state[0] = ArielTwitData;
    } else if (brand === 'ariel' && data === 'png') {
        state[1] = ArielPGData;
    } else if (brand === 'ariel' && data === 'newspaper') {
        state[2] = ArielNewsData;
    } else if (brand === 'febreze' && data === 'all') {
        state[0] = FebrezeTwitData;
        state[1] = FebrezePGData;
        state[2] = FebrezeNewsData;
    } else if (brand === 'febreze' && data === 'twitter') {
        state[0] = FebrezeTwitData;
    } else if (brand === 'febreze' && data === 'png') {
        state[1] = FebrezePGData;
    } else if (brand === 'febreze' && data === 'newspaper') {
        state[2] = FebrezeNewsData;
    } else if (brand === 'joy' && data === 'all') {
        state[0] = JoyTwitData;
        state[1] = JoyPGData;
    } else if (brand === 'joy' && data === 'twitter') {
        state[0] = JoyTwitData;
    } else if (brand === 'joy' && data === 'png') {
        state[1] = JoyPGData;
    } else {
        state[0] = DownyTwitData;
        state[1] = DownyPGData;
        state[2] = DownyNewsData;
    }

    return {
        type: FETCH_DATA,
        payload: state
    }
}

// function to fetch map data 
export function fetchMap(data, brand) {
    let state = [];
    console.log(data);
    console.log(brand);

    if (brand === 'downy' && data === 'all') {
        state[0] = DownyTwitData;
        state[1] = DownyPGData;
        state[2] = DownyNewsData;
    } else if (brand === 'downy' && data === 'twitter') {
        state[0] = DownyTwitData;
    } else if (brand === 'downy' && data === 'png') {
        state[1] = DownyPGData;
    } else if (brand === 'downy' && data === 'newspaper') {
        state[2] = DownyNewsData;
    } else if (brand === 'ariel' && data === 'all') {
        state[0] = ArielTwitData;
        state[1] = ArielPGData;
        state[2] = ArielNewsData;
    } else if (brand === 'ariel' && data === 'twitter') {
        state[0] = ArielTwitData;
    } else if (brand === 'ariel' && data === 'png') {
        state[1] = ArielPGData;
    } else if (brand === 'ariel' && data === 'newspaper') {
        state[2] = ArielNewsData;
    } else if (brand === 'febreze' && data === 'all') {
        state[0] = FebrezeTwitData;
        state[1] = FebrezePGData;
        state[2] = FebrezeNewsData;
    } else if (brand === 'febreze' && data === 'twitter') {
        state[0] = FebrezeTwitData;
    } else if (brand === 'febreze' && data === 'png') {
        state[1] = FebrezePGData;
    } else if (brand === 'febreze' && data === 'newspaper') {
        state[2] = FebrezeNewsData;
    } else if (brand === 'joy' && data === 'all') {
        state[0] = JoyTwitData;
        state[1] = JoyPGData;
    } else if (brand === 'joy' && data === 'twitter') {
        state[0] = JoyTwitData;
    } else if (brand === 'joy' && data === 'png') {
        state[1] = JoyPGData;
    } else {
        state[0] = DownyTwitData;
        state[1] = DownyPGData;
        state[2] = DownyNewsData;
    }

    console.log(state);

    return {
        type: FETCH_MAP,
        payload: state
    }
}