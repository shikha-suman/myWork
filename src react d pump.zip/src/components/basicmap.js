// world map component
import React, { Component } from "react";
import {
    ComposableMap,
    ZoomableGroup,
    Geographies,
    Geography
} from "react-simple-maps";
import { Motion, spring } from "react-motion";

import attributeActiveImg from '../assets/images/attribute-active.png';
import attributeInactiveImg from '../assets/images/attribute_inactive.png';
import phoneActiveImg from '../assets/images/phone-active.png';
import phoneInactiveImg from '../assets/images/phone_inactive.png';
import priceActiveImg from '../assets/images/price-active.png';
import priceInactiveImg from '../assets/images/price_inactive.png';
import mapActiveImg from '../assets/images/map-active.png';
import mapInactiveImg from '../assets/images/map_inactive.png';
import homeImg from '../assets/images/home.png';
import locationImg from '../assets/images/location.png';

const wrapperStyles = {
    width: "100%",
    maxWidth: 980,
    margin: "0 auto",
}

class BasicMap extends Component {
    constructor() {
        super()
        this.state = {
            center: [0, 20],
            zoom: 1
        }

        this.handleClick = this.handleClick.bind(this);
        this.handleReset = this.handleReset.bind(this);
    }

    componentDidMount() {

    }

    handleClick(e) {
        console.log(e.geometry.coordinates['0']['0']);
        this.setState({
            zoom: 1.5
        })
    }

    handleReset() {
        this.setState({
            center: [0, 20],
            zoom: 1,
        })
    }

    render() {
        console.log(this.props);

        if (!this.props.mapData) {
            return <div>Loading...</div>;
        }

        let selectedStyle = {
            default: {
                fill: "#CFD8DC",
                stroke: "#607D8B",
                strokeWidth: 0.75,
                outline: "none",
            },
            hover: {
                fill: "#FF5722",
                stroke: "#607D8B",
                strokeWidth: 0.75,
                outline: "none",
            },
            pressed: {
                fill: "#FF5722",
                stroke: "#607D8B",
                strokeWidth: 0.75,
                outline: "none",
            },
        };

        let defaultStyle = {
            default: {
                fill: "#000000",
                stroke: "#607D8B",
                strokeWidth: 0.75,
                outline: "none",
            },
            hover: {
                fill: "#CFD8DC",
                stroke: "#607D8B",
                strokeWidth: 0.75,
                outline: "none",
            },
            pressed: {
                fill: "#FF5722",
                stroke: "#607D8B",
                strokeWidth: 0.75,
                outline: "none",
            },
        };

        let countryData = {};

        if (this.props.mapData) {
            // console.log(this.props.mapData.length);
            let mapFinal = this.props.mapData;
            mapFinal.map((item) => {
                countryData[item.country] = item.color;
            });
        }

        // console.log(countryData);

        return (
            <div className="boundary-area">
                <div className="outer-area">
                    <div className="map-world" style={wrapperStyles}>
                        <p className="country-selected"> PHILIPPINES</p>
                        <img alt="attri-act" className="attributeAct-img" src={attributeInactiveImg} />
                        <img alt="phone-act" className="phoneAct-img" src={phoneInactiveImg} />
                        <img alt="price-act" className="priceAct-img" src={priceInactiveImg} />
                        <img alt="map-act" className="mapAct-img" src={mapActiveImg} />
                        <img alt="home-img" className="home-img" src={homeImg} />
                        <img alt="location-img" className="location-img" src={locationImg} onClick={this.handleReset} />

                        <div className="third-screen">
                        <div class="dropdown twitter-dropdown">
                            <button class="btn btn-primary dropdown-toggle btn-twitter" type="button" data-toggle="dropdown">TWITTER
                            <span class="caret twitter-caret"></span></button>
                            <ul class="dropdown-menu menu-twitter">
                                <li><a href="#">HTML</a></li>
                                <li><a href="#">CSS</a></li>
                                <li><a href="#">JavaScript</a></li>
                            </ul>
                        </div>

                        <div class="dropdown fb-dropdown">
                            <button class="btn btn-primary dropdown-toggle btn-fb" type="button" data-toggle="dropdown">FACEBOOK
                            <span class="caret fb-caret"></span></button>
                            <ul class="dropdown-menu menu-fb">
                                <li><a href="#">HTML</a></li>
                                <li><a href="#">CSS</a></li>
                                <li><a href="#">JavaScript</a></li>
                            </ul>
                        </div>

                        <div class="dropdown blog-dropdown">
                            <button class="btn btn-primary dropdown-toggle btn-blog" type="button" data-toggle="dropdown">BLOG
                            <span class="caret blog-caret"></span></button>
                            <ul class="dropdown-menu menu-blog">
                                <li><a href="#">HTML</a></li>
                                <li><a href="#">CSS</a></li>
                                <li><a href="#">JavaScript</a></li>
                            </ul>
                        </div>
                        </div>


                        <Motion
                            defaultStyle={{
                                zoom: 1,
                                x: 0,
                                y: 20,
                            }}
                            style={{
                                zoom: spring(this.state.zoom, { stiffness: 210, damping: 20 }),
                                x: spring(this.state.center[0], { stiffness: 210, damping: 20 }),
                                y: spring(this.state.center[1], { stiffness: 210, damping: 20 }),
                            }}
                        >
                            {({ zoom, x, y }) => (
                                <ComposableMap
                                    projectionConfig={{ scale: 190 }}
                                    width={990}
                                    height={440}
                                    style={{
                                        width: "100%",
                                        height: "auto",
                                        position: "relative",
                                        display: "inline-block",
                                    }}
                                >
                                    <ZoomableGroup center={[x, y]} zoom={zoom}>
                                        <Geographies geographyUrl="/world-110m.json">
                                            {(geographies, projection) =>
                                                geographies.map((geography, i) =>
                                                    geography.id !== "010" && (
                                                        <Geography
                                                            onClick={(e) => this.handleClick(e)}
                                                            key={i}
                                                            geography={geography}
                                                            projection={projection}
                                                            style={(countryData.hasOwnProperty(geography.properties.name) === true ? {
                                                                default: {
                                                                    fill: countryData[geography.properties.name],
                                                                    stroke: "#607D8B",
                                                                    strokeWidth: 0.75,
                                                                    outline: "none",
                                                                },
                                                                hover: {
                                                                    fill: "#FF5722",
                                                                    stroke: "#607D8B",
                                                                    strokeWidth: 0.75,
                                                                    outline: "none",
                                                                },
                                                                pressed: {
                                                                    fill: "#FF5722",
                                                                    stroke: "#607D8B",
                                                                    strokeWidth: 0.75,
                                                                    outline: "none",
                                                                },
                                                            } : defaultStyle)}
                                                        />
                                                    ))}
                                        </Geographies>
                                    </ZoomableGroup>
                                </ComposableMap>
                            )}
                        </Motion>
                    </div>
                </div>
            </div>
        )
    }
}

export default BasicMap;