import React, { Component } from 'react';
import { Sparklines, SparklinesLine } from 'react-sparklines';

class Trend extends Component {
    render() {
        return (
            <Sparklines data={this.props.data}>
                <SparklinesLine color="#fe7b23" />
            </Sparklines>
        );
    }
}

export default Trend;