// vertical navbar for brands
import React, { Component } from 'react';
import Slider from 'react-slick';
import '../App.css';
import tideImg from '../assets/images/tide.png';
import arielImg from '../assets/images/Ariel.png';
import joyImg from '../assets/images/Joy.png';
import frebrezeImg from '../assets/images/frebreze.png';
import surfImg from '../assets/images/surf-excel.png';
import downyImg from '../assets/images/downy.png';


class ImgSlider extends Component {

    brandChange(props, data, brand) {
        // console.log('Clicked brand ', brand);
        this.props.updateBrand(data, brand);
    }

    render() {
        var settings = {
            vertical: true,
            infinite: false,
            speed: 500,
            slidesToShow: 8,
            slidesToScroll: 1,
            centerMode: true
        }

        // console.log(this.props);

        return (
            <div className="toolbar-position">
               
                <Slider {...settings}>
                       <a href="#" className="arrowUp-icon"><i className="glyphicon glyphicon-menu-up"></i></a>
                    <div style={(this.props.activeBrand === "downy" ? { opacity: 1 } : { opacity: 0.5 })}>
                        <img alt="downy" className="brand-img" src={downyImg} onClick={() => this.brandChange(this.props, 'all', 'downy')} />
                           <p className="slider-border"></p>
                    </div>
                 
                    <div style={(this.props.activeBrand === "ariel" ? { opacity: 1 } : { opacity: 0.5 })}>
                        <img alt="ariel" className="brand-img" src={arielImg} onClick={() => this.brandChange(this.props, 'all', 'ariel')} />
                           <p className="slider-border"></p>
                    </div>
                 
                    <div style={(this.props.activeBrand === "joy" ? { opacity: 1 } : { opacity: 0.5 })}>
                        <img alt="joy" className="brand-img" src={joyImg} onClick={() => this.brandChange(this.props, 'all', 'joy')} />
                          <p className="slider-border"></p>
                    </div>
                  
                    <div style={(this.props.activeBrand === "febreze" ? { opacity: 1 } : { opacity: 0.5 })}>
                        <img alt="febreze" className="brand-img" src={frebrezeImg} onClick={() => this.brandChange(this.props, 'all', 'febreze')} />
                          <p className="slider-border"></p>
                    </div>
                  
                    <div>
                        <img alt="surf" className="brand-img" src={surfImg} />
                         <p className="slider-border"></p>
                    </div>
                   
                    <div style={(this.props.activeBrand === "tide" ? { opacity: 1 } : { opacity: 0.5 })}>
                        <img alt="tide" className="brand-img" src={tideImg} onClick={() => this.brandChange(this.props, 'all', 'tide')} />
                           <p className="slider-border"></p>
                    </div>
                      <a href="#" className="arrowDown-icon"><i className="glyphicon glyphicon-menu-down"></i></a>
                </Slider>
            </div>

        );
    }
}

export default ImgSlider;