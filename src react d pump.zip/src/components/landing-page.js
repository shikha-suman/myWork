import React, { Component } from 'react';
import '../App.css';
import { Slider } from 'primereact/components/slider/Slider';

import Trend from '../components/brand-trend.js';
// import graphWinImg from '../assets/images/graph-window.png';

class LandingPage extends Component {
    constructor() {
        super();
        this.state = {
            brandVal : 6        };

        this.onChangeSlider4 = this.onChangeSlider4.bind(this);
    }

    componentDidMount() {
        this.setState({ brandVal: this.props.brandIndex });
    }

    navigateToMap() {
        // console.log(this.props);
        // console.log('Clicked card');
        this.props.history.push({
            pathname: '/analytics'
        });
    }

    onChangeSlider4(e) {
        this.setState({ brandVal: this.props.weekWise[e.value] });
        // console.log(this.props);
        // console.log(this.state.brandVal);
    }

    render() {
        console.log(this.props);

        let color1;
        let title1;
        let value1;
        let color2;
        let title2;
        let value2;
        let color3;
        let title3;
        let value3;
        let color4;
        let title4;
        let value4;

        if (this.props.pqi === 0) {
            color1 = "#827f82";
            title1 = "#d0d1d2";
            value1 = "#d0d1d2";
        } else if (this.props.pqi > 0 && this.props.pqi <= 3) {
            color1 = "#fe3d50";
            title1 = "#fefdfa";
            value1 = "#fefdfa";
        } else if (this.props.pqi > 3 && this.props.pqi <= 5) {
            color1 = "#e3868f";
            title1 = "#fefdfa";
            value1 = "#fefdfa";
        } else {
            color1 = "#00eeba";
            title1 = "#01b48d";
            value1 = "#01b48d";
        }

        if (this.props.productAttribute === 0) {
            color2 = "#827f82";
            title2 = "#d0d1d2";
            value2 = "#d0d1d2";
        } else if (this.props.productAttribute > 0 && this.props.productAttribute <= 3) {
            color2 = "#fe3d50";
            title2 = "#fefdfa";
            value2 = "#fefdfa";
        } else if (this.props.productAttribute > 3 && this.props.productAttribute <= 5) {
            color2 = "#e3868f";
            title2 = "#fefdfa";
            value2 = "#fefdfa";
        } else {
            color2 = "#00eeba";
            title2 = "#01b48d";
            value2 = "#01b48d";
        }

        if (this.props.priceIndex === 0) {
            color3 = "#827f82";
            title3 = "#d0d1d2";
            value3 = "#d0d1d2";
        } else if (this.props.priceIndex > 0 && this.props.priceIndex <= 3) {
            color3 = "#fe3d50";
            title3 = "#fefdfa";
            value3 = "#fefdfa";
        } else if (this.props.priceIndex > 3 && this.props.priceIndex <= 5) {
            color3 = "#e3868f";
            title3 = "#fefdfa";
            value3 = "#fefdfa";
        } else {
            color3 = "#00eeba";
            title3 = "#01b48d";
            value3 = "#01b48d";
        }

        if (this.props.productAttribute === 0) {
            color4 = "#827f82";
            title4 = "#d0d1d2";
            value4 = "#d0d1d2";
        } else if (this.props.productAttribute > 0 && this.props.productAttribute <= 3) {
            color4 = "#fe3d50";
            title4 = "#fefdfa";
            value4 = "#fefdfa";
        } else if (this.props.productAttribute > 3 && this.props.productAttribute <= 5) {
            color4 = "#e3868f";
            title4 = "#fefdfa";
            value4 = "#fefdfa";
        } else {
            color4 = "#00eeba";
            title4 = "#01b48d";
            value4 = "#01b48d";
        }

        if(!this.props.weekWise) {
            return <div>Loading</div>;
        }

        return (
            <div className="bg-color">

                <div className="container backdropp">

                    <div className="row">

                        <div className="col-lg-6 column-1">
                            <p className="brand-trend"> BRAND TREND </p>
                            {/* <p className="brand-value">{this.state.brandVal}</p>
                            <div className="slider-brandInd">
                            <Slider style={{ width: '200px' }} onChange={this.onChangeSlider4} step={1} max={this.props.weekWise.length - 1} animate={true} />
                            </div> */}
                            <div className="graph_win">
                            <Trend data={this.props.weekWise}/>
                            </div>
                        </div>
                        <div className="col-lg-6 boxes">

                            <div className="row">
                                <div className="col-lg-6">
                                    <div className="card box1" style={{ background: color1 }} onClick={() => this.navigateToMap()}>
                                        <div className="card-block">
                                            <p className="card-title1" style={{ color: title1 }}>PERCEIVED QUALITY</p>
                                            <p className="card-title2" style={{ color: title1 }}>INDEX</p>
                                            <p className="card-value1" style={{ color: value1 }}>{this.props.pqi}</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="card box2" style={{ background: color2 }} onClick={() => this.navigateToMap()}>
                                        <div className="card-block">
                                            <p className="card-title1" style={{ color: title2 }}>ATTRIBUTE</p>
                                            <p className="card-title2" style={{ color: title2 }}>INDEX</p>
                                            <p className="card-value1" style={{ color: value2 }}>{this.props.productAttribute}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-lg-6">
                                    <div className="card box3" style={{ background: color3 }} onClick={() => this.navigateToMap()}>
                                        <div className="card-block">
                                            <p className="card-title3" style={{ color: title3 }}>PRICE &</p>
                                            <p className="card-title4" style={{ color: title3 }}>QUALITY</p>
                                            <p className="card-value2" style={{ color: value3 }}>{this.props.priceIndex}</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="card box4" style={{ background: color4 }} onClick={() => this.navigateToMap()}>
                                        <div className="card-block">
                                            <p className="card-title5" style={{ color: title4 }}>PRODUCT ATTRIBUTE</p>
                                            <p className="card-title6" style={{ color: title4 }}>INDEX</p>
                                            <p className="card-value3" style={{ color: value4 }}>{this.props.productAttribute}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default LandingPage;