import React, { Component } from 'react';
import SlidingPane from 'react-sliding-pane';
import 'react-sliding-pane/dist/react-sliding-pane.css';
import '../App.css';
import allImg from '../assets/images/all.png';
import facebookImg from '../assets/images/facebook.png';
import twitterImg from '../assets/images/twitter.png';
import youtubeImg from '../assets/images/youtube.png';
import blogImg from '../assets/images/blog.png';
import enewsImg from '../assets/images/enews.png';

import brandImg from '../assets/images/brand.png';
import channelImg from '../assets/images/channel.png';
import instaImg from '../assets/images/instagram.png';
import messengerImg from '../assets/images/messenger.png';
import retailerImg from '../assets/images/retailer.png';

class SidePanel extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isPaneOpen: false,
            isPaneOpenLeft: false
        };
    }

    changePanelData(props, data) {
        // console.log('Clicked source ', data);
        this.props.updateBrand(data, this.props.brand);
    }

    render() {
        // console.log(this.props);
        return <div>
            <span onClick={() => this.setState({ isPaneOpen: true })} className="side-arrow glyphicon glyphicon-menu-left arrowleft"></span>
            <SlidingPane
                className='some-custom-class'

                isOpen={this.state.isPaneOpen}
                onRequestClose={() => {
                    // triggered on "<" on left top click or on outside click
                    this.setState({ isPaneOpen: false });
                }}>
                <div>
                    <img alt="all" className="all-img " src={allImg} style={(this.props.data === "all" ? { opacity: 1 } : { opacity: 0.5 })} onClick={() => this.changePanelData(this.props, 'all')} />
                </div>
                <div>
                    <img alt="fb" className="fb-img" src={facebookImg} style={(this.props.data === "facebook" ? { opacity: 1 } : { opacity: 0.5 })} onClick={() => this.changePanelData(this.props, 'facebook')} />
                </div>
                <div>
                    <img alt="twitter" className="twitter-img" src={twitterImg} style={(this.props.data === "twitter" ? { opacity: 1 } : { opacity: 0.5 })}
                    onClick={() => this.changePanelData(this.props, 'twitter')} />
                </div>
                <div>
                    <img alt="youtube" className="youtube-img" src={youtubeImg} style={(this.props.data === "youtube" ? { opacity: 1 } : { opacity: 0.5 })} onClick={() => this.changePanelData(this.props, 'youtube')} />
                </div>
                <div>
                    <img alt="blog" className="blog-img" src={blogImg} style={(this.props.data === "png" ? { opacity: 1 } : { opacity: 0.5 })} onClick={() => this.changePanelData(this.props, 'png')} />
                </div>
                <div>
                    <img alt="enews" className="enews-img" src={enewsImg} style={(this.props.data === "newspaper" ? { opacity: 1 } : { opacity: 0.5 })} onClick={() => this.changePanelData(this.props, 'newspaper')} />
                </div>
                  <div>
                    <img alt="brand" className="brands-img" src={brandImg} style={(this.props.data === "brand" ? { opacity: 1 } : { opacity: 0.5 })} onClick={() => this.changePanelData(this.props, 'brand')} />
                </div>
                
                 <div>
                    <img alt="channel" className="channel-img" src={channelImg} style={(this.props.data === "channel" ? { opacity: 1 } : { opacity: 0.5 })} onClick={() => this.changePanelData(this.props, 'channel')} />
                </div>
                 <div>
                    <img alt="insta" className="insta-img" src={instaImg} style={(this.props.data === "insta" ? { opacity: 1 } : { opacity: 0.5 })} onClick={() => this.changePanelData(this.props, 'insta')} />
                </div>
                 <div>
                    <img alt="messenger" className="messenger-img" src={messengerImg} style={(this.props.data === "messenger" ? { opacity: 1 } : { opacity: 0.5 })} onClick={() => this.changePanelData(this.props, 'messenger')} />
                </div>
                 <div>
                    <img alt="retailer" className="retailer-img" src={retailerImg} style={(this.props.data === "retailer" ? { opacity: 1 } : { opacity: 0.5 })} onClick={() => this.changePanelData(this.props, 'retailer')} />
                </div>
            </SlidingPane>
        </div>;
    }
}

export default SidePanel;
