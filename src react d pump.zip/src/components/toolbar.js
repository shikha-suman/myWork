// search bar on top
import React, { Component } from 'react';

class Toolbar extends Component {
    render() {
        // return <div>Toolbar</div>;
        return (
            <div className="navbar navbar-default" id="top-menu" role="navigation">
                <div className="container-fluid">
                    <div className="navbar-header">
                        <a href="#" className="info-icon"><i className=" glyphicon glyphicon-info-sign"></i></a>
                    </div>
                </div>
            </div>

        );
    }
}

export default Toolbar;