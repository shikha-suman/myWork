import { combineReducers } from 'redux';

import BrandReducer from './reducer-data';
import MapReducer from './reducer-map';

// combines all the reducers where state changes occur so as to pass on through a singular file
const rootReducers = combineReducers({
    brand: BrandReducer,
    mapData: MapReducer
});

export default rootReducers;