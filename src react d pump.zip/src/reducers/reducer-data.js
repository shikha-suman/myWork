import { FETCH_DATA } from '../actions';

// returns the brands values
export default (state = {}, action) => {
    switch (action.type) {
        case FETCH_DATA:
            let mainObj = [];
            let stateObj = {};
            action.payload.map((mainItem) => {
                let weeks = []; // stores number of weeks
                let stateObj = {};  // calculates overall state data for mapping
                let sources = [];   // total sources
                let countries_PriceQuality = [];    // countries for price and quality
                let countries_ProductAttribute = [];    // countries for product attribute
                let countries_UserAttribute = [];   // countries as per user attribute

                stateObj.rawData = mainItem;

                // calculate number of isolated weeks
                mainItem.map((item) => {
                    weeks.push(item.tweet_week_wise);
                    sources.push(item.source_name);
                    if ((item.Tweet_on_fabric === "TRUE" || item.Tweet_on_odour === "TRUE") && item.country !== "") {
                        countries_ProductAttribute.push(item.country);
                    }
                    if ((item.Tweet_on_price === "TRUE" || item.Tweet_on_quality === "TRUE") && item.country !== "") {
                        countries_PriceQuality.push(item.country);
                    }
                    if (((item.source_name === "Twitter for Android") || (item.source_name === "Twitter for iPhone") || (item.source_name === "Twitter for iPad") || (item.source_name === "Twitter Web Client") || (item.source_name === "Twitter Lite")) && item.country !== "") {
                        countries_UserAttribute.push(item.country);
                    }
                    return weeks;
                });

                stateObj.countries_PriceQuality = Array.from(new Set(countries_PriceQuality));
                stateObj.countries_ProductAttribute = Array.from(new Set(countries_ProductAttribute));
                stateObj.countries_UserAttribute = Array.from(new Set(countries_UserAttribute));

                // calculate number of weeks
                weeks = Array.from(new Set(weeks));

                // calculate number of sources (non-duplicate)
                sources = Array.from(new Set(sources));
                stateObj.sources = sources;

                // calculate negative, positive and neutral sentiment count for all the week based data
                let neutral = 0;
                let positive = 0;
                let negative = 0;
                let positiveOdour = 0;
                let negativeOdour = 0;
                let neutralOdour = 0;
                let positiveFabric = 0;
                let negativeFabric = 0;
                let neutralFabric = 0;
                let positivePrice = 0;
                let negativePrice = 0;
                let neutralPrice = 0;
                let neutralQuality = 0;
                let positiveQuality = 0;
                let negativeQuality = 0;
                let weekPQI;    // calculate week wise PQI
                let weekPriceIndex; // week wise price index
                let weekOdourIndex;  // week wise odour index
                let weekFabricIndex;  // week wise fabric index
                let weekQualityIndex;  // week wise quality index
                let overallPQI = 0; // calculate overall PQI
                let overallPriceIndex = 0;  // calculate overall price index
                let overallProductAttrIndex = 0; // calculate overall product attribute index
                let overallQualityIndex = 0;    //calculate overall quality index
                let overallBrandIndex = 0;  // calculate overall brand index
                let weekArray = []; // stores week wise data

                // calculate sentiments type and 
                weeks.map((item) => {
                    let weekObj = {};
                    neutral = 0;
                    positive = 0;
                    negative = 0;
                    neutralOdour = 0;
                    positiveOdour = 0;
                    negativeOdour = 0;
                    neutralFabric = 0;
                    positiveFabric = 0;
                    negativeFabric = 0;
                    neutralPrice = 0;
                    positivePrice = 0;
                    negativePrice = 0;
                    neutralQuality = 0;
                    positiveQuality = 0;
                    negativeQuality = 0;

                    mainItem.map((object) => {
                        // overall tweet values
                        if (object.tweet_week_wise === item) {
                            if (object.sentiment.toLowerCase() === "neutral") {
                                neutral = neutral + 1;
                            } else if (object.sentiment.toLowerCase() === "positive") {
                                positive = positive + 1;
                            } else {
                                negative = negative + 1;
                            }
                        }

                        // odour tweet count
                        if (object.tweet_week_wise === item && object.Tweet_on_odour === "TRUE") {
                            if (object.sentiment.toLowerCase() === "neutral") {
                                neutralOdour = neutralOdour + 1;
                            } else if (object.sentiment.toLowerCase() === "positive") {
                                positiveOdour = positiveOdour + 1;
                            } else {
                                negativeOdour = negativeOdour + 1;
                            }
                        }

                        // fabric tweet count
                        if (object.tweet_week_wise === item && object.Tweet_on_fabric === "TRUE") {
                            if (object.sentiment.toLowerCase() === "neutral") {
                                neutralFabric = neutralFabric + 1;
                            } else if (object.sentiment.toLowerCase() === "positive") {
                                positiveFabric = positiveFabric + 1;
                            } else {
                                negativeFabric = negativeFabric + 1;
                            }
                        }

                        // price tweet count
                        if (object.tweet_week_wise === item && object.Tweet_on_price === "TRUE") {
                            if (object.sentiment.toLowerCase() === "neutral") {
                                neutralPrice = neutralPrice + 1;
                            } else if (object.sentiment.toLowerCase() === "positive") {
                                positivePrice = positivePrice + 1;
                            } else {
                                negativePrice = negativePrice + 1;
                            }
                        }

                        // quality tweet count
                        if (object.tweet_week_wise === item && object.Tweet_on_quality === "TRUE") {
                            if (object.sentiment.toLowerCase() === "neutral") {
                                neutralQuality = neutralQuality + 1;
                            } else if (object.sentiment.toLowerCase() === "positive") {
                                positiveQuality = positiveQuality + 1;
                            } else {
                                negativeQuality = negativeQuality + 1;
                            }
                        }
                        return object;
                    });

                    weekPQI = ((positive - negative) / (positive + neutral + negative)) * 10;
                    weekOdourIndex = ((positiveOdour - negativeOdour) / (positiveOdour + neutralOdour + negativeOdour)) * 10;
                    weekFabricIndex = ((positiveFabric - negativeFabric) / (positiveFabric + neutralFabric + negativeFabric)) * 10;
                    weekPriceIndex = ((positivePrice - negativePrice) / (positivePrice + neutralPrice + negativePrice)) * 10;
                    weekQualityIndex = ((positiveQuality - negativeQuality) / (positiveQuality + neutralQuality + negativeQuality)) * 10;

                    // round off for week wise PQI
                    if (weekPQI < 0) {
                        weekObj.PQI = 0;
                    } else if (weekPQI > 10) {
                        weekObj.PQI = 10;
                    } else {
                        weekObj.PQI = ~~weekPQI;
                    }

                    // round off for week wise odour attribute
                    if (weekOdourIndex < 0) {
                        weekObj.odourIndex = 0;
                    } else if (weekOdourIndex > 10) {
                        weekObj.odourIndex = 10;
                    } else {
                        weekObj.odourIndex = ~~weekOdourIndex;
                    }

                    // round off for week wise fabric attribute
                    if (weekFabricIndex < 0) {
                        weekObj.fabricIndex = 0;
                    } else if (weekFabricIndex > 10) {
                        weekObj.fabricIndex = 10;
                    } else {
                        weekObj.fabricIndex = ~~weekFabricIndex;
                    }

                    // round off for week wise price attribute
                    if (weekPriceIndex < 0) {
                        weekObj.priceIndex = 0;
                    } else if (weekPriceIndex > 10) {
                        weekObj.priceIndex = 10;
                    } else {
                        weekObj.priceIndex = ~~weekPriceIndex;
                    }

                    // round off for week wise price attribute
                    if (weekQualityIndex < 0) {
                        weekObj.qualityIndex = 0;
                    } else if (weekQualityIndex > 10) {
                        weekObj.qualityIndex = 10;
                    } else {
                        weekObj.qualityIndex = ~~weekQualityIndex;
                    }

                    weekObj.productAttrIndex = ~~((weekObj.fabricIndex + weekObj.odourIndex) / 2);

                    weekObj.brandIndex = weekObj.priceIndex + weekObj.qualityIndex + weekObj.PQI + weekObj.productAttrIndex;

                    weekObj.week = item;
                    weekObj.neutral = neutral;
                    weekObj.positive = positive;
                    weekObj.negative = negative;
                    weekObj.neutralOdour = neutralOdour;
                    weekObj.positiveOdour = positiveOdour;
                    weekObj.negativeOdour = negativeOdour;
                    weekObj.neutralFabric = neutralFabric;
                    weekObj.positiveFabric = positiveFabric;
                    weekObj.negativeFabric = negativeFabric;
                    weekObj.neutralPrice = neutralPrice;
                    weekObj.positivePrice = positivePrice;
                    weekObj.negativePrice = negativePrice;
                    weekObj.neutralQuality = neutralQuality;
                    weekObj.positiveQuality = positiveQuality;
                    weekObj.negativeQuality = negativeQuality;

                    weekArray.push(weekObj);
                    return weekArray;
                });

                let weekMapObj = [];

                // calculating overall data
                weekArray.map((item) => {
                    weekMapObj.push(item.brandIndex);
                    overallPQI += item.PQI;
                    overallPriceIndex += item.priceIndex;
                    overallProductAttrIndex += item.productAttrIndex;
                    overallQualityIndex += item.qualityIndex;
                    overallBrandIndex += item.brandIndex;
                    return item;
                });

                // assigning to state object
                stateObj.weekPQI_data = weekArray;
                stateObj.overallPQI = ~~(overallPQI / weekArray.length);
                stateObj.overallPriceIndex = ~~(overallPriceIndex / weekArray.length);
                stateObj.overallProductAttrIndex = ~~(overallProductAttrIndex / weekArray.length);
                stateObj.overallQualityIndex = ~~(overallQualityIndex / weekArray.length);
                stateObj.overallBrandIndex = ~~(overallBrandIndex / weekArray.length);
                stateObj.weekWiseData = weekMapObj;
                // console.log(stateObj);
                mainObj.push(stateObj);
            });

            let finalObj = {};
            finalObj.allData = mainObj;

            let finalBrandIndex = 0;
            let finalPQI = 0;
            let finalPriceIndex = 0;
            let finalQualityIndex = 0;
            let finalProductAttrIndex = 0;
            let weekWiseData = [];

            mainObj.map((item) => {
                finalBrandIndex += item.overallBrandIndex;
                finalPQI += item.overallPQI;
                finalPriceIndex += item.overallPriceIndex;
                finalQualityIndex += item.overallQualityIndex;
                finalProductAttrIndex += item.overallProductAttrIndex;
                weekWiseData.push(item.overallBrandIndex);
            });

            finalObj.finalBrandIndex = ~~(finalBrandIndex / mainObj.length);
            finalObj.finalPQI = ~~(finalPQI / mainObj.length);
            finalObj.finalPriceIndex = ~~(finalPriceIndex / mainObj.length);
            finalObj.finalQualityIndex = ~~(finalQualityIndex / mainObj.length);
            finalObj.finalProductAttrIndex = ~~(finalProductAttrIndex / mainObj.length);
            finalObj.weekWiseData = weekWiseData;

            return finalObj;
        default:
            return state;
    }
}