import { FETCH_MAP } from '../actions';

export default (state = [], action) => {
    switch (action.type) {
        case FETCH_MAP:

            let countries = [];

            // getting countries data
            if (action.payload.length > 1) {
                // s.log("multiple");
                action.payload.map((item) => {
                    item.map((finalObj) => {
                        // console.log(finalObj);
                        if (finalObj.country) {
                            countries.push(finalObj.country);
                        }
                    });
                })
            } else {
                action.payload.map((item) => {
                    item.map((finalObj) => {
                        if (finalObj.country !== "") {
                            countries.push(finalObj.country);
                        }
                    });
                })
            }

            let tweets = [];
            let news = [];
            let comments = [];
            let positive = 0;
            let negative = 0;
            let neutral = 0;
            let pqi = 0;

            countries = Array.from(new Set(countries));
            // s.log(countries);

            let countryArray = [];

            // creating country based objects
            countries.map((countryData) => {
                let countryObj = {};
                positive = 0;
                negative = 0;
                neutral = 0;
                countryObj.country = countryData;
                if (action.payload.length > 1) {
                    // s.log("multiple");
                    action.payload.map((item) => {
                        item.map((finalObj) => {
                            if (countryData === finalObj.country && finalObj.country) {
                                if (finalObj.News) {
                                    news.push(finalObj.News);
                                } else if (finalObj.text) {
                                    tweets.push(finalObj.text);
                                } else if (finalObj.Comment) {
                                    comments.push(finalObj.Comment);
                                } else if (finalObj.sentiment === "Positive") {
                                    positive += 1;
                                } else if (finalObj.sentiment === "Negative") {
                                    negative += 1;
                                } else {
                                    neutral += 1;
                                }
                            }
                        });
                    })
                } else {
                    // s.log("single");
                    action.payload.map((item) => {
                        item.map((finalObj) => {
                            if (finalObj.News) {
                                news.push(finalObj.News);
                            } else if (finalObj.text) {
                                tweets.push(finalObj.text);
                            } else if (finalObj.Comment) {
                                comments.push(finalObj.Comment);
                            } else if (finalObj.sentiment === "Positive") {
                                positive += 1;
                            } else if (finalObj.sentiment === "Negative") {
                                negative += 1;
                            } else {
                                neutral += 1;
                            }
                        });
                    })
                }

                pqi = ~~(((positive - negative) / (positive + negative + neutral)) * 10);

                if (pqi > 10) {
                    pqi = 10;
                } else if (pqi < 0) {
                    pqi = 0;
                }

                let color;

                // color code
                if (pqi === 0) {
                    color = "#827f82";
                } else if (pqi > 0 && pqi <= 3) {
                    color = "#fe3d50";
                } else if (pqi > 3 && pqi <= 5) {
                    color = "#e3868f";
                } else {
                    color = "#00eeba";
                }

                countryObj.tweets = tweets;
                countryObj.news = news;
                countryObj.comments = comments;
                countryObj.pqi = pqi;
                countryObj.color = color;

                countryArray.push(countryObj);
            });

            // s.log(countryArray);

            // let finalColObj = {};

            // countryArray.map((item) => {
            //     finalColObj[item.country] = item.color;
            // });

            // countryArray.push(finalColObj);

            return countryArray;
        default:
            return state;
    }
}